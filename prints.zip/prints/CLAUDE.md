# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Comandos principais

```bash
# Desenvolvimento local
npm start                  # Servidor de dev em localhost:4200

# Build
npm run build:local        # Build local (carrega .env e executa o script)
npm run build              # Build de produção completo (cobertura + Angular + pós-build)

# Testes
npm test                   # Executa todos os testes com Jest
npm run test:watch         # Jest em modo watch
npm run test:coverage      # Gera relatório de cobertura

# Qualidade de código
npm run lint:all           # Executa ESLint + Prettier
npm run lint               # ESLint com auto-fix em src/**/*.{js,jsx,ts,tsx,html}
npm run format             # Prettier em src/**/*.{js,jsx,ts,tsx,html,css,scss}
```

Para rodar um único teste:

```bash
npm run test -- "nome-do-arquivo.spec.ts"
npx jest --testPathPattern="nome-do-arquivo.spec.ts"
```

## Arquitetura

### Stack e versões relevantes

- **Angular 20** com standalone components (sem NgModules)
- **TypeScript 5.9** com strict mode
- **Jest 30** + jest-preset-angular para testes
- **Autenticação**: `angular-auth-oidc-client` para OIDC + `@azure/msal-*` para integração Azure AD

### Estrutura de rotas e lazy loading

Todas as páginas são standalone components carregados via `loadComponent()`. As rotas protegidas usam dois guards:

- `authGuard` — bloqueia usuários não autenticados; em modo bypass local, verifica `localStorage`
- `guestGuard` — bloqueia usuários já autenticados de acessar `/login`; em modo bypass local, redireciona se já "logado"

Cada rota declara `data: { roles: string[] }`, consumido pelo `LayoutPrincipalComponent` para filtrar o menu de navegação.

```
/login               (guestGuard)
/callback            (OIDC callback)
/app                 (authGuard + LayoutPrincipalComponent)
  ├─ /upload         roles: ['Edit_pricing']
  ├─ /dashboard      roles: ['Edit_pricing']
  └─ /publicacoes    roles: ['Approve_cycle']
```

> Rotas `/detalhes` e `/controle-acessos` estão comentadas em `app.routes.ts` — não remover sem acordo.

### Gerenciamento de estado

**Sem NgRx.** Estado via Signals e RxJS:

- `AuthService` expõe `isAuthenticatedSignal`, `accessTokenSignal`, `currentUserProfile` como Signals via `toSignal()`
- Demais services usam BehaviorSubjects ou Observables simples
- `NotificationService` usa `Subject` para sistema de toasts (success / error / info / warning)
- Componentes usam `takeUntil(destroy$)` para unsubscribe

### Camada HTTP

Dois interceptors registrados em `app.config.ts` via `withInterceptors([...])`:

1. **`authInterceptor`** — injeta `Authorization: Bearer <token>` em cada request
2. **`errorInterceptor`** — trata 400/401/403/404/5xx com toast; 401 faz logout e redireciona

A URL base do BFF é injetada via `NG_BASE_BFF_URL`. Em dev local, `proxy.conf.json` redireciona `/api` → `http://localhost:8091`.

Todas as respostas de API seguem o wrapper `ResponseAPI<T>`:

```typescript
interface ResponseAPI<T> {
  status: string;
  message: string;
  data: T;
}
```

### Padrão de modais

A diretiva `BaseModal` (`src/app/shared/directives/base-modal.ts`) fornece comportamento reutilizável: fechar com ESC, clique fora, e bloqueio de scroll via `ScrollLockService`. Modais estendem `BaseModal` e chamam `open()`/`close()`.

### Padrão de testes

Testes usam `TestBed` com serviços mockados via `jest.fn()`:

```typescript
const mockService = { metodo: jest.fn().mockReturnValue(of(dadosMock)) };
TestBed.configureTestingModule({
  providers: [{ provide: MinhaService, useValue: mockService }],
});
```

Mocks reutilizáveis ficam em `src/app/shared/mocks/`. Nomes de teste escritos em português (ex.: `'deve retornar erro quando...'`). A cobertura mínima exigida é:

```
lines: 80%  |  branches: 80%  |  functions: 80%  |  statements: 80%
```

Arquivos excluídos da cobertura: `*.module.ts`, `*.mock.ts`, `mocks/`, `environments/`.

### Design System global (`src/styles/`)

Todas as classes globais usam o prefixo `cruz-`. **Nunca use estilos inline ou crie classes locais para o que já existe aqui.**

**Tipografia** (`_typography.scss`):

| Classe                   | Uso                                                                            |
| ------------------------ | ------------------------------------------------------------------------------ |
| `.cruz-page-title`       | Container de título de página; use `__title` e `__subtitle` como elementos BEM |
| `.cruz-section-title`    | Título de seção (1rem, cor secundária)                                         |
| `.cruz-section-subtitle` | Subtítulo de seção (0.875rem, cor secundária)                                  |

**Utilitários** (`_utilities.scss`):

| Classe              | Uso                                                                         |
| ------------------- | --------------------------------------------------------------------------- |
| `.cruz-link-btn`    | Botão com aparência de link (sem borda/fundo)                               |
| `.cruz-badge`       | Badge arredondado; modificador `--danger` disponível                        |
| `.cruz-empty-state` | Container de estado vazio com ícone e descrição (`__icon`, `__description`) |

**Modal** (`_modal.scss`):

| Classe                                | Uso                                                                                            |
| ------------------------------------- | ---------------------------------------------------------------------------------------------- |
| `.cruz-modal-overlay`                 | Overlay fixo; modificador `--drawer` para painéis laterais                                     |
| `.cruz-modal-box`                     | Caixa do modal (max 600px); modificador `--drawer` para painel lateral (640px, fixo à direita) |
| `.cruz-modal-header`                  | Cabeçalho com título e botão de fechar                                                         |
| `.cruz-modal-body`                    | Corpo do modal                                                                                 |
| `.cruz-modal-footer`                  | Rodapé alinhado à direita para botões de ação                                                  |
| `.cruz-icon-btn` + `.cruz-close-icon` | Botão de ícone (ex.: fechar modal)                                                             |

**Variáveis CSS** (`_colors.scss`) — use sempre via `var()`, nunca valores hardcoded:

```
Texto:      --color-text | --color-text-strong | --color-text-secondary | --color-text-light | --color-text-disabled | --color-text-muted
Fundo:      --color-bg-subtle | --color-surface | --color-border | --color-border-subtle
Primário:   --color-primary-action | --color-primary-medium | --color-primary-strong | --color-primary-soft
Sucesso:    --color-success-strong | --color-success-soft
Perigo:     --color-danger-strong | --color-danger-medium | --color-danger-dark | --color-danger-soft | --color-danger-border
Info:       --color-info-strong | --color-info-active | --color-info-soft
Modal:      --color-overlay | --shadow-modal | --shadow-soft
Tag:        --color-tag-bg | --color-tag-text
```

### Aliases de importação (tsconfig)

```
@app/*    → src/app/*
@core/*   → src/app/core/*
@shared/* → src/app/shared/*
@env/*    → src/environments/*
```

### Variáveis de ambiente

Injetadas no build via `@ngx-env/builder` (prefixo `NG_` ou `ENV_`). O arquivo `src/environments/environment.ts` expõe:

- `NG_BASE_BFF_URL`, `NG_BASE_URL`, `NG_PRODUCTION`
- `NG_LOCAL_AUTH_BYPASS` — bypass de autenticação para desenvolvimento local (ver seção abaixo)
- `NG_AUTH_TENANT_ID`, `NG_AUTH_CLIENT_ID`, `NG_AUTH_API_CLIENT_ID`
- Objeto `endpoints` com os paths da API (`/api/v1/ciclos/...`, `/api/v1/grupo-ads`, `/api/v1/user`)

Crie um `.env` na raiz para desenvolvimento local (não commitar). Use `.env.example` como base.

### Bypass de autenticação local (`NG_LOCAL_AUTH_BYPASS`)

O login via Azure AD não funciona em `http://localhost` (URL não cadastrada no app registration). Para desenvolver localmente sem precisar modificar código:

1. Defina `NG_LOCAL_AUTH_BYPASS=true` no `.env` local
2. A tela de login é exibida normalmente
3. Ao clicar "Entre com Office", a aplicação chama `GET /api/v1/user` no BFF local e persiste um flag em `localStorage`
4. Em refreshes subsequentes, o perfil é restaurado automaticamente sem novo login
5. Logout limpa o `localStorage` e redireciona para `/login`

Métodos relevantes em `AuthService` (`src/app/core/services/auth/auth.service.ts`):

- `bypassLogin()` — persiste flag e chama `getUserProfile()`
- `isLocalBypassAuthenticated()` — lê o flag do `localStorage`
- `logout()` — limpa o flag quando bypass está ativo

### Detalhes não óbvios

- **`AlertTableService`** retorna dados hardcoded (mock) — não há endpoint real por trás.
- **`DashboardService`** tem `delay(1000)` e `delay(1500)` intencionais para staging de UX.
- **Formato de ID de ciclo**: `YYYY.SEMESTRE` (ex.: `2024.1`).
- **Controle de acesso no menu**: `LayoutPrincipalComponent` filtra itens do menu comparando `User.grupos` com `route.data.roles`.
- O perfil do usuário é carregado via `APP_INITIALIZER` no bootstrap da aplicação. Em modo bypass, o `APP_INITIALIZER` chama `getUserProfile()` diretamente se o flag do `localStorage` estiver presente.
- **`src/env.d.ts`** declara `ImportMeta.env`, `process` e `_NGX_ENV_` como globais — não remover.

### CI/CD

Azure Pipelines (`azure-pipelines.yml`) com deploy para três ambientes:

- **DEV** — branch `develop`
- **HML** — branch `homolog`
- **PRD** — branch `main`

### Convenções de código

- **Commits**: Conventional Commits (commitlint configurado)
- **Estilo**: Prettier com 100 chars/linha, single quotes, 2 espaços — rode `npm run lint:all` antes de commitar
- **Husky**: pre-commit hook em `.husky/pre-commit`
