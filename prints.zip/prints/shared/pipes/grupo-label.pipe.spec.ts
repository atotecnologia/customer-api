import { GrupoLabelPipe, grupoLabel, LABEL_TO_ID } from './grupo-label.pipe';

describe('grupoLabel', () => {
  it('deve mapear ID interno para o label correto', () => {
    expect(grupoLabel('admin_geral')).toBe('Administrador');
    expect(grupoLabel('analista_aprovador')).toBe('Aprovador');
    expect(grupoLabel('analista_precificacao')).toBe('Analista');
    expect(grupoLabel('leitor_basico')).toBe('Visualizador');
  });

  it('deve mapear display name para o label correto', () => {
    expect(grupoLabel('Administrador Geral')).toBe('Administrador');
    expect(grupoLabel('Analista Aprovador')).toBe('Aprovador');
    expect(grupoLabel('Analista de Precificação')).toBe('Analista');
    expect(grupoLabel('Visualizador Base')).toBe('Visualizador');
  });

  it('deve retornar o próprio valor quando não há mapeamento (fallback)', () => {
    expect(grupoLabel('grupo_novo')).toBe('grupo_novo');
    expect(grupoLabel('qualquer_outro')).toBe('qualquer_outro');
  });

  it('deve retornar string vazia quando receber string vazia (fallback)', () => {
    expect(grupoLabel('')).toBe('');
  });
});

describe('LABEL_TO_ID', () => {
  it('deve mapear labels em minúsculo para os IDs internos corretos', () => {
    expect(LABEL_TO_ID['administrador']).toBe('admin_geral');
    expect(LABEL_TO_ID['aprovador']).toBe('analista_aprovador');
    expect(LABEL_TO_ID['analista']).toBe('analista_precificacao');
    expect(LABEL_TO_ID['visualizador']).toBe('leitor_basico');
  });
});

describe('GrupoLabelPipe', () => {
  let pipe: GrupoLabelPipe;

  beforeEach(() => {
    pipe = new GrupoLabelPipe();
  });

  it('deve ser criado', () => {
    expect(pipe).toBeTruthy();
  });

  it('deve delegar para grupoLabel e retornar o label correto', () => {
    expect(pipe.transform('leitor_basico')).toBe('Visualizador');
    expect(pipe.transform('analista_precificacao')).toBe('Analista');
  });

  it('deve retornar o próprio valor para entradas desconhecidas', () => {
    expect(pipe.transform('grupo_inexistente')).toBe('grupo_inexistente');
  });
});
