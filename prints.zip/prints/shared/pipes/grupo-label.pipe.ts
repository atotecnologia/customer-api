import { Pipe, PipeTransform } from '@angular/core';

const LABELS: Record<string, string> = {
  admin_geral: 'Administrador',
  analista_aprovador: 'Aprovador',
  analista_precificacao: 'Analista',
  leitor_basico: 'Visualizador',
  'Administrador Geral': 'Administrador',
  'Analista Aprovador': 'Aprovador',
  'Analista de Precificação': 'Analista',
  'Visualizador Base': 'Visualizador',
};

export const LABEL_TO_ID: Record<string, string> = {
  administrador: 'admin_geral',
  aprovador: 'analista_aprovador',
  analista: 'analista_precificacao',
  visualizador: 'leitor_basico',
};

export function grupoLabel(value: string): string {
  return LABELS[value] ?? value;
}

@Pipe({ name: 'grupoLabel', standalone: true })
export class GrupoLabelPipe implements PipeTransform {
  transform(value: string): string {
    return grupoLabel(value);
  }
}
