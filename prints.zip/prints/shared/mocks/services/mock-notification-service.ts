/// <reference types="jest" />

export class MockNotificationService {
  success = jest.fn();
  error = jest.fn();
  info = jest.fn();
  warning = jest.fn();
}
