import { MinhasPublicacoes, StatusPublicacao } from '@app/shared/models/publicacao.model';
import { Importacoes } from '@app/shared/models/importacoes.model';
import { ResponseAPI } from '@app/shared/models/response-api.model';

export function obterStatusPublicacaoResponse(): ResponseAPI<StatusPublicacao> {
  return {
    status: '200 OK',
    message: 'Status de publicação retornado com sucesso',
    data: {
      importacaoId: 1,
      cicloId: '2024.1',
      nomeArquivo: 'precos.xlsx',
      status: 'PENDENTE',
      totalSkus: 100,
      dataImportacao: '2024-01-15T10:00:00Z',
      dataPublicacao: null,
      realizadoPor: 'Usuário Teste',
      realizadoPorOid: 'oid-usuario-teste',
      erros: [],
    },
  };
}

export function obterStatusPublicacaoNuloResponse(): ResponseAPI<null> {
  return {
    status: '200 OK',
    message: 'Nenhuma publicação em andamento',
    data: null,
  };
}

export function publicarCicloResponse(): ResponseAPI<StatusPublicacao> {
  return {
    status: '200 OK',
    message: 'Ciclo publicado com sucesso',
    data: {
      importacaoId: 1,
      cicloId: '2024.1',
      nomeArquivo: 'precos.xlsx',
      status: 'EM_PUBLICACAO',
      totalSkus: 100,
      dataImportacao: '2024-01-15T10:00:00Z',
      dataPublicacao: null,
      realizadoPor: 'Usuário Teste',
      realizadoPorOid: 'oid-usuario-teste',
      erros: [],
    },
  };
}

export function statusPublicacaoComStatus(
  status: StatusPublicacao['status']
): ResponseAPI<StatusPublicacao> {
  const base = obterStatusPublicacaoResponse();
  return { ...base, data: { ...base.data, status } };
}

export function obterImportacoesResponse(): ResponseAPI<Importacoes[]> {
  return {
    status: '200 OK',
    message: 'Importações retornadas com sucesso',
    data: [
      {
        importacaoId: 1,
        cicloId: '2024.1',
        nomeArquivo: 'precos.xlsx',
        status: 'PUBLICADO',
        data: '2024-01-15T10:00:00Z',
        realizadoPor: 'Usuário Teste',
      },
      {
        importacaoId: 2,
        cicloId: '2024.2',
        nomeArquivo: 'precos-2.xlsx',
        status: 'PENDENTE',
        data: '2024-06-01T09:00:00Z',
        realizadoPor: 'Outro Usuário',
      },
    ],
  };
}

export function obterPublicacoesResponse(): MinhasPublicacoes[] {
  return [
    {
      importacaoId: 1,
      cicloId: '2024.1',
      nomeArquivo: 'precos.xlsx',
      status: 'PUBLICADO',
      totalSkus: 100,
      importadoPor: 'usuario@cruzeirodosul.edu.br',
      publicadoPor: 'outro.usuario@cruzeirodosul.edu.br',
      dataImportacao: '2024-01-15T10:00:00Z',
      dataPublicacao: '2024-01-16T08:00:00Z',
    },
    {
      importacaoId: 2,
      cicloId: '2024.2',
      nomeArquivo: 'precos-2.xlsx',
      status: 'INVALIDO',
      totalSkus: 200,
      importadoPor: 'outro.usuario@cruzeirodosul.edu.br',
      publicadoPor: 'usuario@cruzeirodosul.edu.br',
      dataImportacao: '2024-06-01T09:00:00Z',
      dataPublicacao: '2024-06-02T10:00:00Z',
    },
  ];
}

export function obterMinhasPublicacoesResponse(): ResponseAPI<MinhasPublicacoes[]> {
  return {
    status: '200 OK',
    message: 'Publicações retornadas com sucesso',
    data: [
      {
        importacaoId: 1,
        cicloId: '2024.1',
        nomeArquivo: 'precos.xlsx',
        status: 'PUBLICADO',
        totalSkus: 100,
        importadoPor: 'usuario@cruzeirodosul.edu.br',
        publicadoPor: 'outro.usuario@cruzeirodosul.edu.br',
        dataImportacao: '2024-01-15T10:00:00Z',
        dataPublicacao: '2024-01-16T08:00:00Z',
      },
      {
        importacaoId: 2,
        cicloId: '2024.2',
        nomeArquivo: 'precos-2.xlsx',
        status: 'PENDENTE',
        totalSkus: 200,
        importadoPor: 'usuario@cruzeirodosul.edu.br',
        publicadoPor: 'outro.usuario@cruzeirodosul.edu.br',
        dataImportacao: '2024-06-01T09:00:00Z',
        dataPublicacao: null,
      },
    ],
  };
}
