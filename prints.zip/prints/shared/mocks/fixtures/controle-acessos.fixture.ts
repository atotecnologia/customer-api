import { ControleAcesso } from '@app/shared/models/controle-acesso.model';
import { ResponseAPI } from '@app/shared/models/response-api.model';

export function obterGrupoAdResponse(): ControleAcesso {
  return {
    status: '200 OK',
    message: 'Consulta de dados concluída com sucesso',
    data: {
      grupoAds: [
        {
          id: 'admin_geral',
          descricao: 'Administrador Geral',
          roles: [
            {
              id: 1,
              nome: 'View_report',
              descricao: 'Visualizar relatórios e resultados consolidados',
              selecionado: true,
            },
            {
              id: 2,
              nome: 'View_candidate',
              descricao: 'Visualizar a jornada e simulação do candidato',
              selecionado: true,
            },
          ],
        },
        {
          id: 'analista_precificacao',
          descricao: 'Analista de Precificação',
          roles: [
            {
              id: 1,
              nome: 'View_report',
              descricao: 'Visualizar relatórios e resultados consolidados',
              selecionado: false,
            },
            {
              id: 2,
              nome: 'View_candidate',
              descricao: 'Visualizar a jornada e simulação do candidato',
              selecionado: true,
            },
          ],
        },
      ],
    },
  };
}

export function salvarAteracaoGrupoAdResponse(): ResponseAPI<null> {
  return {
    status: '200 OK',
    message: 'Grupos AD atualizados com sucesso',
    data: null,
  };
}
