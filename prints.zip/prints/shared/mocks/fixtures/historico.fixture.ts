import { HistoricoResponse } from '@shared/models/historico.model';
import { ResponseAPI } from '@shared/models/response-api.model';

export function obterHistoricoVazio(): ResponseAPI<HistoricoResponse> {
  return {
    status: '200 OK',
    message: 'Histórico de publicações retornado com sucesso',
    data: {
      content: [],
      pagination: { page: 0, pageSize: 10, totalPages: 0, totalElements: 0 },
      filtrosDisponiveis: { ciclos: [], status: [] },
    },
  };
}

export function obterHistoricoResponse(): ResponseAPI<HistoricoResponse> {
  return {
    status: '200 OK',
    message: 'Histórico de publicações retornado com sucesso',
    data: {
      content: [
        {
          importacaoId: 1,
          cicloId: '2026.1',
          nomeArquivo: 'Tabela_Pricing_261_FINANCEIRO_v6.xlsx',
          status: 'PUBLICADO',
          importadoPor: 'Maria Silva',
          dataImportacao: '2025-09-28T14:32:00Z',
          publicadoPor: 'João Santos',
          dataPublicacao: '2025-09-28T16:00:00Z',
        },
        {
          importacaoId: 2,
          cicloId: '2026.2',
          nomeArquivo: 'Tabela_Pricing_262_FINANCEIRO_v1.xlsx',
          status: 'INVALIDO',
          importadoPor: 'João Santos',
          dataImportacao: '2025-09-28T10:15:00Z',
          publicadoPor: 'João Santos',
          dataPublicacao: '2025-09-28T12:00:00Z',
        },
        {
          importacaoId: 3,
          cicloId: '2026.1',
          nomeArquivo: 'Tabela_Pricing_261_FINANCEIRO_v5.xlsx',
          status: 'PUBLICADO',
          importadoPor: 'Maria Silva',
          dataImportacao: '2025-09-27T09:00:00Z',
          publicadoPor: 'Maria Silva',
          dataPublicacao: '2025-09-27T11:45:00Z',
        },
        {
          importacaoId: 4,
          cicloId: '2026.1',
          nomeArquivo: 'Tabela_Pricing_261_FINANCEIRO_v4.xlsx',
          status: 'EM_PUBLICACAO',
          importadoPor: 'Maria Silva',
          dataImportacao: '2025-09-26T16:00:00Z',
          publicadoPor: null,
          dataPublicacao: null,
        },
        {
          importacaoId: 5,
          cicloId: '2026.2',
          nomeArquivo: 'Tabela_Pricing_262_FINANCEIRO_v2.xlsx',
          status: 'PENDENTE',
          importadoPor: 'João Santos',
          dataImportacao: '2025-09-25T08:30:00Z',
          publicadoPor: null,
          dataPublicacao: null,
        },
        {
          importacaoId: 6,
          cicloId: '2026.1',
          nomeArquivo: 'Tabela_Pricing_261_FINANCEIRO_v3.xlsx',
          status: 'PUBLICADO',
          importadoPor: 'Maria Silva',
          dataImportacao: '2025-09-24T13:20:00Z',
          publicadoPor: 'Maria Silva',
          dataPublicacao: '2025-09-24T15:00:00Z',
        },
      ],
      pagination: {
        page: 0,
        pageSize: 20,
        totalPages: 1,
        totalElements: 6,
      },
      filtrosDisponiveis: {
        ciclos: ['2026.2', '2026.1'],
        status: ['PUBLICADO', 'INVALIDO', 'EM_PUBLICACAO', 'PENDENTE'],
      },
    },
  };
}
