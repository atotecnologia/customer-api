export interface PaginationInfo {
  page: number;
  pageSize: number;
  totalPages: number;
  totalElements: number;
}
