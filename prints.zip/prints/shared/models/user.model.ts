export interface User {
  oid: string;
  nome: string;
  email: string;
  grupos: string[];
}
