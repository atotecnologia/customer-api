import { PaginationInfo } from './pagination-info.model';

export interface GrupoResumo {
  id: string;
  nome: string;
  descricao: string;
  totalUsuarios: number;
}

export interface UsuarioPerfil {
  nome: string;
  email: string;
  grupos: string[];
}

export interface FiltrosUsuarios {
  search?: string;
  grupoIds?: string[];
  page: number;
  pageSize: number;
  sortBy?: 'nome' | 'email';
  sortDir?: 'asc' | 'desc';
}

export interface PaginatedResult<T> {
  content: T[];
  pagination: PaginationInfo;
}

export type EstadoCelula = 'CONCEDIDA' | 'NEGADA';

export interface CelulaPermissao {
  estado: EstadoCelula;
  editavel: boolean;
}

export interface LinhaPermissao {
  roleNome: string;
  descricao: string;
  celulas: Record<string, CelulaPermissao>;
}

export interface GrupoColuna {
  id: string;
  nome: string;
}

export interface MatrizPermissoes {
  grupos: GrupoColuna[];
  permissoes: LinhaPermissao[];
}

export interface AlteracaoPermissao {
  grupoId: string;
  roleNome: string;
  conceder: boolean;
}

export interface HistoricoPermissao {
  dataHora: string;
  perfil: string;
  permissao: string;
  acao: 'ADICIONADA' | 'REMOVIDA';
  responsavel: string;
}
