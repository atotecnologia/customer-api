export interface HistoricoItem {
  importacaoId: number;
  cicloId: string;
  nomeArquivo: string;
  status: 'PUBLICADO' | 'INVALIDO' | 'EM_PUBLICACAO' | 'NAO_PUBLICADO' | 'PENDENTE' | 'CANCELADA';
  importadoPor: string;
  dataImportacao: string;
  publicadoPor: string | null;
  dataPublicacao: string | null;
}

export interface PaginationInfo {
  page: number;
  pageSize: number;
  totalPages: number;
  totalElements: number;
}

export interface FiltrosDisponiveis {
  ciclos: string[];
  status: string[];
}

export interface HistoricoFiltros {
  ciclos: string[];
  status: string[];
}

export interface HistoricoResponse {
  content: HistoricoItem[];
  pagination: PaginationInfo;
  filtrosDisponiveis: FiltrosDisponiveis;
}
