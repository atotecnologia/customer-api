export interface ResponseAPI<T> {
  status: string;
  message: string;
  data: T;
}
