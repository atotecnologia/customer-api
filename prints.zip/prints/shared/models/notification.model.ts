export type NotificationType = 'success' | 'error' | 'info' | 'warning';

export interface Notification {
  title?: string;
  message: string;
  type: NotificationType;
}
