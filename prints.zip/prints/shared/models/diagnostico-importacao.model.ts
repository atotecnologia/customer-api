export type StatusImportacaoBackend =
  | 'PROCESSANDO'
  | 'PENDENTE'
  | 'VALIDACAO_ERRO'
  | 'PUBLICADO'
  | 'EM_PUBLICACAO'
  | 'INVALIDO'
  | 'ERRO_SISTEMA'
  | 'CANCELADA';

export interface ErroDiagnostico {
  linha: number;
  coluna: string;
  descricao: string;
}

/**
 * Diagnóstico da última importação de um ciclo. Além do session-resumption, é o canal de polling
 * do upload assíncrono: enquanto `status === 'PROCESSANDO'`, o cliente continua consultando.
 */
export interface DiagnosticoImportacao {
  ultimaImportacao: {
    importacaoId: number;
    nomeArquivo: string;
    status: StatusImportacaoBackend;
    realizadoPor: string;
    data: string;
    totalSkus: number | null;
  };
  skusValidos?: number | null;
  skusInvalidos?: number | null;
  erros?: ErroDiagnostico[] | null;
}
