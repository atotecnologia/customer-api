import { Ciclo } from './ciclo.model';

export interface ListagemCiclos {
  status: string;
  message: string;
  data: {
    ultimoUploadGeral: string;
    ciclos: Ciclo[];
  };
}
