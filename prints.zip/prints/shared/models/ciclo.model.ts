export interface Ciclo {
  id: string;
  label: string;
  dataUpload: string;
}
