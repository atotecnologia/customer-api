export interface Cycle {
  id: string;
  label: string;
  data_upload: string;
}

export interface CycleListResponse {
  status: string;
  message: string;
  data: {
    ciclos: Cycle[];
  };
}
