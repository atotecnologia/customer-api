import { CourseItem } from './course-item.model';
import { PaginationInfo } from './pagination-info.model';

export interface DetalhesData {
  itens: CourseItem[];
  pagination: PaginationInfo;
}
