export interface ErroUpload {
  linha: number;
  coluna: string;
  descricao: string;
}

/**
 * Resposta do aceite de upload (HTTP 202). O processamento é assíncrono: `status` vem como
 * `PROCESSANDO` e as contagens/erros são obtidos depois por polling do diagnóstico.
 */
export interface UploadResponse {
  importacaoId: number;
  status: string;
  totalSkus: number;
  skusValidos: number;
  skusInvalidos: number;
  erros: ErroUpload[];
}
