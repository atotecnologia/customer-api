export interface Importacoes {
  importacaoId: number;
  nomeArquivo: string;
  cicloId: string;
  status: string;
  data: string;
  realizadoPor: string;
}
