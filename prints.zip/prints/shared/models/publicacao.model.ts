export interface ErroStatusPublicacao {
  sku: string;
  tipo: string;
  mensagem: string;
}

export interface StatusPublicacao {
  importacaoId: number;
  cicloId: string;
  nomeArquivo: string;
  status: 'PENDENTE' | 'EM_PUBLICACAO' | 'PUBLICADO' | 'INVALIDO' | 'ERRO_SISTEMA';
  totalSkus: number;
  dataImportacao: string;
  dataPublicacao: string | null;
  realizadoPor: string;
  realizadoPorOid: string;
  erros: ErroStatusPublicacao[];
}

export interface MinhasPublicacoes {
  importacaoId: number;
  cicloId: string;
  nomeArquivo: string;
  status: string;
  totalSkus: number;
  importadoPor: string;
  publicadoPor: string;
  dataImportacao: string;
  dataPublicacao: string | null;
}
