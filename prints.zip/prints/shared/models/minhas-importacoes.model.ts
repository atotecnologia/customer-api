export interface MinhasImportacoes {
  importacaoId: number;
  nomeArquivo: string;
  cicloId: string;
  status: string;
  data: string;
}
