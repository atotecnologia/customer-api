import { ResponseAPI } from './response-api.model';

export interface Roles {
  id: number;
  nome: string;
  descricao: string;
  selecionado: boolean;
}

export interface GrupoAds {
  id: string;
  descricao: string;
  roles: Roles[];
}

export type ControleAcesso = ResponseAPI<{
  grupoAds: GrupoAds[];
}>;
