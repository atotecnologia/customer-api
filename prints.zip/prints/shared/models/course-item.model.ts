export interface CourseItem {
  sku: number;
  empresa: string;
  cycleId: string;
  cidade: string;
  curso: string;
  area: string;
  grau: string;
  turno: string;
  bu: string;
  status: string;
  statusRevisado: string;
}
