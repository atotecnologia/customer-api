import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ScrollLockService } from '@core/scroll-lock/scroll-lock.service';
import { BaseModal } from './base-modal';

@Component({
  selector: 'app-test-modal',
  template: '<div class="cruz-modal-box"><button id="btn-inside">ok</button></div>',
})
class TestModalComponent extends BaseModal {}

describe('BaseModal', () => {
  let component: TestModalComponent;
  let fixture: ComponentFixture<TestModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TestModalComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(TestModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    document.body.style.overflow = '';
  });

  it('deve criar o componente de teste', () => {
    expect(component).toBeTruthy();
  });

  describe('dado o estado inicial', () => {
    it('deve iniciar com isOpen = false', () => {
      expect(component.isOpen).toBe(false);
    });
  });

  describe('dado o método open()', () => {
    it('deve definir isOpen como true', () => {
      component.open();

      expect(component.isOpen).toBe(true);
    });
  });

  describe('dado o método close()', () => {
    it('deve definir isOpen como false', () => {
      component.open();
      component.close();

      expect(component.isOpen).toBe(false);
    });

    it('não deve fazer nada quando já está fechado', () => {
      const scrollLockService = TestBed.inject(ScrollLockService);
      jest.spyOn(scrollLockService, 'unlock');

      component.close();

      expect(scrollLockService.unlock).not.toHaveBeenCalled();
    });
  });

  describe('dado o método onEscape()', () => {
    it('deve fechar o modal ao pressionar Escape quando aberto', () => {
      component.isOpen = true;

      component.onEscape();

      expect(component.isOpen).toBe(false);
    });

    it('não deve alterar o estado quando o modal já está fechado', () => {
      component.isOpen = false;

      component.onEscape();

      expect(component.isOpen).toBe(false);
    });
  });

  describe('dado o método onDocumentClick()', () => {
    it('não deve fazer nada quando o modal está fechado', () => {
      component.isOpen = false;

      const event = new MouseEvent('click');
      component.onDocumentClick(event);

      expect(component.isOpen).toBe(false);
    });

    it('deve fechar ao clicar fora do modal-box', () => {
      component.open();
      fixture.detectChanges();

      const outsideElement = document.createElement('div');
      document.body.appendChild(outsideElement);

      const event = { target: outsideElement } as unknown as MouseEvent;
      component.onDocumentClick(event);

      expect(component.isOpen).toBe(false);
      document.body.removeChild(outsideElement);
    });

    it('não deve fechar ao clicar dentro do modal-box', () => {
      component.open();
      fixture.detectChanges();

      const modalBox = fixture.nativeElement.querySelector('.cruz-modal-box');
      const event = { target: modalBox } as unknown as MouseEvent;
      component.onDocumentClick(event);

      expect(component.isOpen).toBe(true);
    });

    it('não deve fechar ao clicar em elemento filho do modal-box', () => {
      component.open();
      fixture.detectChanges();

      const child = fixture.nativeElement.querySelector('#btn-inside');
      const event = { target: child } as unknown as MouseEvent;
      component.onDocumentClick(event);

      expect(component.isOpen).toBe(true);
    });
  });

  describe('dado o scroll lock', () => {
    let scrollLockService: ScrollLockService;

    beforeEach(() => {
      scrollLockService = TestBed.inject(ScrollLockService);
    });

    it('deve bloquear o scroll ao abrir', () => {
      component.open();

      expect(document.body.style.overflow).toBe('hidden');
    });

    it('deve liberar o scroll ao fechar', () => {
      component.open();
      component.close();

      expect(document.body.style.overflow).toBe('');
    });

    it('não deve chamar unlock() se close() for chamado sem open() anterior', () => {
      jest.spyOn(scrollLockService, 'unlock');

      component.close();

      expect(scrollLockService.unlock).not.toHaveBeenCalled();
    });
  });
});
