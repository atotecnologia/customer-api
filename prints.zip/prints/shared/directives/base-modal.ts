import { DestroyRef, Directive, ElementRef, HostListener, inject } from '@angular/core';
import { ScrollLockService } from '@core/scroll-lock/scroll-lock.service';

@Directive()
export abstract class BaseModal {
  protected readonly elementRef = inject(ElementRef);
  private readonly scrollLock = inject(ScrollLockService);
  private readonly destroyRef = inject(DestroyRef);

  protected readonly modalBoxSelector = '.cruz-modal-box';

  isOpen = false;

  constructor() {
    this.destroyRef.onDestroy(() => {
      if (this.isOpen) {
        this.scrollLock.unlock();
      }
    });
  }

  open(): void {
    this.isOpen = true;
    this.scrollLock.lock();
  }

  close(): void {
    if (!this.isOpen) {
      return;
    }

    this.isOpen = false;
    this.scrollLock.unlock();
  }

  @HostListener('document:keydown.escape')
  onEscape(): void {
    if (this.isOpen) {
      this.close();
    }
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    if (!this.isOpen) {
      return;
    }

    const modalBox = this.elementRef.nativeElement.querySelector(this.modalBoxSelector);

    if (modalBox && !modalBox.contains(event.target as Node)) {
      this.close();
    }
  }
}
