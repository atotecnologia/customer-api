import { Component, EventEmitter, Input, Output } from '@angular/core';
import { NgClass } from '@angular/common';
import { LucideCircleAlert, LucideRefreshCcw } from '@lucide/angular';

export type ErrorStateType = 'menu' | 'request' | 'generic';

@Component({
  selector: 'app-error-state',
  standalone: true,
  templateUrl: './error-state.html',
  styleUrl: './error-state.scss',
  imports: [LucideCircleAlert, NgClass, LucideRefreshCcw],
})
export class ErrorStateComponent {
  @Input() type: ErrorStateType = 'generic';
  @Input() customMessage?: string;
  @Input() buttonLabel = 'Recarregar';
  @Output() retry = new EventEmitter<void>();

  get message(): string {
    if (this.customMessage) return this.customMessage;

    const messages: Record<ErrorStateType, string> = {
      menu: 'Ocorreu uma falha ao carregar o menu. Recarregue para tentar novamente.',
      request: 'Ocorreu uma falha ao processar os dados. Recarregue para tentar novamente.',
      generic: 'Algo deu errado. Por favor, tente novamente.',
    };

    return messages[this.type];
  }

  onRetry(): void {
    this.retry.emit();
  }
}
