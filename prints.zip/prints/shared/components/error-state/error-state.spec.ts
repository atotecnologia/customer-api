import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ErrorStateComponent } from './error-state';

describe('ErrorStateComponent', () => {
  let component: ErrorStateComponent;
  let fixture: ComponentFixture<ErrorStateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ErrorStateComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ErrorStateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display generic message by default', () => {
    expect(component.message).toBe('Algo deu errado. Por favor, tente novamente.');
  });

  it('should display menu message when type is menu', () => {
    fixture.componentRef.setInput('type', 'menu');
    expect(component.message).toBe(
      'Ocorreu uma falha ao carregar o menu. Recarregue para tentar novamente.'
    );
  });

  it('should display request message when type is request', () => {
    fixture.componentRef.setInput('type', 'request');
    expect(component.message).toBe(
      'Ocorreu uma falha ao processar os dados. Recarregue para tentar novamente.'
    );
  });

  it('should display custom message if provided', () => {
    fixture.componentRef.setInput('customMessage', 'Custom Error');
    expect(component.message).toBe('Custom Error');
  });

  it('should emit retry event when onRetry is called', () => {
    const spy = jest.spyOn(component.retry, 'emit');
    component.onRetry();
    expect(spy).toHaveBeenCalled();
  });

  it('should display custom button label if provided', () => {
    fixture.componentRef.setInput('buttonLabel', 'Tentar de novo');
    fixture.detectChanges();
    const button = fixture.nativeElement.querySelector('.btn-retry');
    expect(button.textContent.trim()).toBe('Tentar de novo');
  });
});
