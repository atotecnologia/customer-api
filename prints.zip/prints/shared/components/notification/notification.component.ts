import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';
import { NotificationService } from '../../../core/services/notification/notification.service';
import { Notification } from '../../models/notification.model';

@Component({
  selector: 'app-notification',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss'],
})
export class NotificationComponent implements OnInit, OnDestroy {
  notifications: (Notification & { id: number; state: 'visible' | 'hidden' })[] = [];
  private subscription!: Subscription;
  private nextId = 0;

  constructor(
    private readonly notificationService: NotificationService,
    private readonly cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.subscription = this.notificationService.notifications.subscribe(notification => {
      this.addNotification(notification);
    });
  }

  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  private addNotification(notification: Notification): void {
    const newId = this.nextId++;
    const newNotification = {
      ...notification,
      id: newId,
      state: 'visible' as const,
    };

    this.notifications.push(newNotification);
    this.cdr.detectChanges(); // Mostra o toast

    // Agenda o início do fechamento para daqui a 5 segundos
    setTimeout(() => {
      this.hideNotification(newId);
    }, 5000);
  }

  hideNotification(id: number): void {
    const index = this.notifications.findIndex(n => n.id === id);

    if (index !== -1) {
      // 1. Muda o estado para disparar a animação de saída (fade out)
      this.notifications[index].state = 'hidden';
      this.cdr.detectChanges();

      // 2. Aguarda o tempo da animação (300ms) para remover do array
      setTimeout(() => {
        this.notifications = this.notifications.filter(n => n.id !== id);
        this.cdr.detectChanges(); // Atualiza o DOM removendo o elemento
      }, 300);
    }
  }
}
