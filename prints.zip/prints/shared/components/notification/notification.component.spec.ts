import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Subject } from 'rxjs';
import { Notification } from '../../models/notification.model';
import { NotificationComponent } from './notification.component';
import { NotificationService } from '@app/core/services/notification/notification.service';

describe('NotificationComponent', () => {
  let component: NotificationComponent;
  let fixture: ComponentFixture<NotificationComponent>;
  let notificationSubject: Subject<Notification>;

  beforeEach(async () => {
    notificationSubject = new Subject<Notification>();
    await TestBed.configureTestingModule({
      imports: [NotificationComponent, NoopAnimationsModule],
      providers: [
        {
          provide: NotificationService,
          useValue: {
            notifications: notificationSubject.asObservable(),
          },
        },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(NotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should add a notification when the service sends one', () => {
    const notification: Notification = { message: 'Test message', type: 'success' };
    expect(component.notifications.length).toBe(0);

    notificationSubject.next(notification);

    expect(component.notifications.length).toBe(1);
    expect(component.notifications[0].message).toBe('Test message');
    expect(component.notifications[0].type).toBe('success');
    expect(component.notifications[0].state).toBe('visible');
  });

  it('should hide and remove a notification after a delay', fakeAsync(() => {
    const notification: Notification = { message: 'Test message', type: 'info' };
    notificationSubject.next(notification);

    fixture.detectChanges();
    expect(component.notifications.length).toBe(1);

    // Fast-forward time by 5 seconds for the first setTimeout in addNotification
    tick(5000);
    fixture.detectChanges();

    expect(component.notifications[0].state).toBe('hidden');

    // Fast-forward time by 300ms for the second setTimeout in hideNotification
    tick(300);
    fixture.detectChanges();

    expect(component.notifications.length).toBe(0);
  }));

  it('should hide a notification and remove it from the array', fakeAsync(() => {
    // Manually add a notification to test hideNotification directly
    component.notifications = [{ id: 0, message: 'Test', type: 'error', state: 'visible' }];
    fixture.detectChanges();
    expect(component.notifications.length).toBe(1);

    component.hideNotification(0);
    expect(component.notifications[0].state).toBe('hidden');

    tick(300); // Wait for the animation timeout
    fixture.detectChanges();

    expect(component.notifications.length).toBe(0);
  }));

  it('should not do anything if notification to hide is not found', fakeAsync(() => {
    component.notifications = [{ id: 0, message: 'Test', type: 'error', state: 'visible' }];
    fixture.detectChanges();
    expect(component.notifications.length).toBe(1);

    component.hideNotification(1); // Non-existent ID
    expect(component.notifications.length).toBe(1);
    expect(component.notifications[0].state).toBe('visible');

    tick(300);
    fixture.detectChanges();

    expect(component.notifications.length).toBe(1);
  }));

  it('ngOnDestroy should unsubscribe from notification service', () => {
    const subscription = (component as unknown as { subscription: { unsubscribe: () => void } })
      .subscription;
    jest.spyOn(subscription, 'unsubscribe');
    component.ngOnDestroy();
    expect(subscription.unsubscribe).toHaveBeenCalled();
  });
});
