import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DropdownComponent } from './dropdown';

describe('DropdownComponent', () => {
  let component: DropdownComponent;
  let fixture: ComponentFixture<DropdownComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DropdownComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(DropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('toggleDropdown', () => {
    it('deve abrir o dropdown quando está fechado', () => {
      component.isOpen = false;

      component.toggleDropdown();

      expect(component.isOpen).toBe(true);
    });

    it('deve fechar o dropdown quando está aberto', () => {
      component.isOpen = true;

      component.toggleDropdown();

      expect(component.isOpen).toBe(false);
    });

    it('não deve abrir o dropdown quando está desabilitado', () => {
      component.disabled = true;
      component.isOpen = false;

      component.toggleDropdown();

      expect(component.isOpen).toBe(false);
    });
  });

  describe('selectOption', () => {
    let emitSpy: jest.SpyInstance;

    beforeEach(() => {
      emitSpy = jest.spyOn(component.selectedOptionChange, 'emit');
      component.isOpen = true;
    });

    it('deve atualizar o valor selecionado se for diferente do já informado', () => {
      const opcaoSelecionada = 'opcao-1';

      component.selectedOption = null;

      component.selectOption(opcaoSelecionada);

      expect(component.selectedOption).toBe(opcaoSelecionada);
      expect(emitSpy).toHaveBeenCalledWith(opcaoSelecionada);
      expect(component.isOpen).toBe(false);
    });

    it('não deve fazer nada se o valor selecionado for o mesmo do já informado', () => {
      const opcaoSelecionada = 'opcao-2';

      component.selectedOption = opcaoSelecionada;

      component.selectOption(opcaoSelecionada);

      expect(component.selectedOption).toBe(opcaoSelecionada);
      expect(emitSpy).not.toHaveBeenCalled();
      expect(component.isOpen).toBe(false);
    });
  });

  describe('onDocumentClick', () => {
    it('deve fechar o dropdown ao clicar fora do componente', () => {
      component.isOpen = true;

      const elementoExterno = document.createElement('div');
      component.onDocumentClick({ target: elementoExterno } as unknown as MouseEvent);

      expect(component.isOpen).toBe(false);
    });

    it('deve manter o dropdown aberto ao clicar dentro do componente', () => {
      component.isOpen = true;

      component.onDocumentClick({ target: fixture.nativeElement } as unknown as MouseEvent);

      expect(component.isOpen).toBe(true);
    });
  });

  describe('onEscape', () => {
    it('deve fechar o dropdown ao pressionar Escape', () => {
      component.isOpen = true;

      component.onEscape();

      expect(component.isOpen).toBe(false);
    });

    it('não deve lançar erro quando o dropdown já está fechado', () => {
      component.isOpen = false;

      expect(() => component.onEscape()).not.toThrow();
      expect(component.isOpen).toBe(false);
    });
  });
});
