import {
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  Output,
  inject,
} from '@angular/core';
import { LucideChevronDown } from '@lucide/angular';

@Component({
  selector: 'app-dropdown',
  standalone: true,
  imports: [LucideChevronDown],
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.scss'],
})
export class DropdownComponent {
  @Input() options: string[] = [];
  @Input() selectedOption: string | null = null;
  @Input() placeholder = 'Selecione...';
  @Input() disabled = false;

  @Output() selectedOptionChange = new EventEmitter<string>();

  private readonly elementRef = inject(ElementRef);

  isOpen = false;

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    if (!this.elementRef.nativeElement.contains(event.target)) {
      this.isOpen = false;
    }
  }

  @HostListener('document:keydown.escape')
  onEscape(): void {
    this.isOpen = false;
  }

  toggleDropdown(): void {
    if (!this.disabled) {
      this.isOpen = !this.isOpen;
    }
  }

  selectOption(option: string): void {
    if (option !== this.selectedOption) {
      this.selectedOption = option;
      this.selectedOptionChange.emit(option);
    }

    this.isOpen = false;
  }
}
