import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { SemAcessoComponent } from './sem-acesso.component';

describe('SemAcessoComponent', () => {
  let component: SemAcessoComponent;
  let fixture: ComponentFixture<SemAcessoComponent>;

  const createComponent = (queryParams: Record<string, string>) => {
    TestBed.configureTestingModule({
      imports: [SemAcessoComponent],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: { snapshot: { queryParams } },
        },
      ],
    });

    fixture = TestBed.createComponent(SemAcessoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  };

  it('deve usar o texto padrão quando o parâmetro "recurso" não for informado', () => {
    createComponent({});

    expect(component['resourceName']).toBe('esta funcionalidade');
    const text: string = fixture.nativeElement.querySelector('.sem-acesso__text').textContent;
    expect(text).toContain('esta funcionalidade');
  });

  it('deve exibir o nome do recurso informado via query param', () => {
    createComponent({ recurso: 'Publicações' });

    expect(component['resourceName']).toBe('Publicações');
    const text: string = fixture.nativeElement.querySelector('.sem-acesso__text').textContent;
    expect(text).toContain('Publicações');
  });
});
