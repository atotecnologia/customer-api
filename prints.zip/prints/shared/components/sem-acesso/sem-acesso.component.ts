import { Component, inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-sem-acesso',
  standalone: true,
  templateUrl: './sem-acesso.component.html',
  styleUrl: './sem-acesso.component.scss',
})
export class SemAcessoComponent {
  protected readonly resourceName: string =
    inject(ActivatedRoute).snapshot.queryParams['recurso'] ?? 'esta funcionalidade';
}
