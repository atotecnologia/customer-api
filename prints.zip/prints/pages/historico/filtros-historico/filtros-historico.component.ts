import { Component, EventEmitter, Input, Output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BaseModal } from '@shared/directives/base-modal';
import { HistoricoFiltros } from '@shared/models/historico.model';

const STATUS_LABELS: Record<string, string> = {
  PUBLICADO: 'Publicado',
  PENDENTE: 'Não publicado',
  EM_PUBLICACAO: 'Em publicação',
  INVALIDO: 'Inválido',
  CANCELADA: 'Cancelado',
  ERRO_SISTEMA: 'Erro do sistema',
  VALIDACAO_ERRO: 'Erro de validação',
};

@Component({
  selector: 'app-filtros-historico',
  imports: [FormsModule],
  templateUrl: './filtros-historico.component.html',
  styleUrl: './filtros-historico.component.scss',
})
export class FiltrosHistoricoComponent extends BaseModal {
  @Input() ciclosDisponiveis: string[] = [];

  readonly todosStatus = Object.keys(STATUS_LABELS);

  @Output() filtrosAplicados = new EventEmitter<HistoricoFiltros>();
  @Output() filtrosLimpos = new EventEmitter<void>();
  @Output() fechado = new EventEmitter<void>();

  ciclosSelecionados = signal<string[]>([]);
  statusSelecionados = signal<string[]>([]);
  secaoCiclosAberta = signal(true);
  secaoStatusAberta = signal(true);

  private snapshotAoAbrir: HistoricoFiltros = { ciclos: [], status: [] };

  initFiltros(filtrosAtivos: HistoricoFiltros): void {
    this.snapshotAoAbrir = { ciclos: [...filtrosAtivos.ciclos], status: [...filtrosAtivos.status] };
    this.ciclosSelecionados.set([...filtrosAtivos.ciclos]);
    this.statusSelecionados.set([...filtrosAtivos.status]);
  }

  override close(): void {
    if (!this.isOpen) return;
    const selecaoAtual: HistoricoFiltros = {
      ciclos: this.ciclosSelecionados(),
      status: this.statusSelecionados(),
    };
    if (!this.filtrosIguais(selecaoAtual, this.snapshotAoAbrir)) {
      this.filtrosAplicados.emit(selecaoAtual);
    }
    super.close();
    this.fechado.emit();
  }

  toggleSecaoCiclos(): void {
    this.secaoCiclosAberta.update(v => !v);
  }

  toggleSecaoStatus(): void {
    this.secaoStatusAberta.update(v => !v);
  }

  labelStatus(status: string): string {
    return STATUS_LABELS[status] ?? status;
  }

  toggleCiclo(ciclo: string): void {
    const atual = this.ciclosSelecionados();
    const idx = atual.indexOf(ciclo);
    this.ciclosSelecionados.set(idx >= 0 ? atual.filter(c => c !== ciclo) : [...atual, ciclo]);
  }

  toggleStatus(status: string): void {
    const atual = this.statusSelecionados();
    const idx = atual.indexOf(status);
    this.statusSelecionados.set(idx >= 0 ? atual.filter(s => s !== status) : [...atual, status]);
  }

  isCicloSelecionado(ciclo: string): boolean {
    return this.ciclosSelecionados().includes(ciclo);
  }

  isStatusSelecionado(status: string): boolean {
    return this.statusSelecionados().includes(status);
  }

  aplicar(): void {
    this.close();
  }

  limpar(): void {
    this.ciclosSelecionados.set([]);
    this.statusSelecionados.set([]);
    this.snapshotAoAbrir = { ciclos: [], status: [] };
    this.filtrosLimpos.emit();
    this.close();
  }

  private filtrosIguais(a: HistoricoFiltros, b: HistoricoFiltros): boolean {
    const norm = (f: HistoricoFiltros) =>
      JSON.stringify({
        ciclos: [...f.ciclos].sort((a, b) => a.localeCompare(b)),
        status: [...f.status].sort((a, b) => a.localeCompare(b)),
      });
    return norm(a) === norm(b);
  }
}
