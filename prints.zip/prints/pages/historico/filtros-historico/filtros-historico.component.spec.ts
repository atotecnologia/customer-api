import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FiltrosHistoricoComponent } from './filtros-historico.component';

describe('FiltrosHistoricoComponent', () => {
  let component: FiltrosHistoricoComponent;
  let fixture: ComponentFixture<FiltrosHistoricoComponent>;

  const ciclosMock = ['2026.1', '2026.2', '2027.1'];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FiltrosHistoricoComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(FiltrosHistoricoComponent);
    component = fixture.componentInstance;
    component.ciclosDisponiveis = ciclosMock;
    component.initFiltros({ ciclos: [], status: [] });
    component.open();
    fixture.detectChanges();
  });

  it('deve criar o componente', () => {
    expect(component).toBeTruthy();
  });

  describe('Renderização', () => {
    it('deve exibir seções de CICLO e STATUS', () => {
      const compiled = fixture.nativeElement as HTMLElement;
      const titulos = Array.from(compiled.querySelectorAll('.filtros-secao__titulo')).map(el =>
        el.textContent?.trim()
      );
      expect(titulos).toContain('Ciclos');
      expect(titulos).toContain('Status');
    });

    it('deve renderizar um checkbox para cada ciclo e para todos os status', () => {
      const labels = fixture.nativeElement.querySelectorAll('.filtros-opcao');
      expect(labels.length).toBe(ciclosMock.length + component.todosStatus.length);
    });
  });

  describe('Seleção de ciclo', () => {
    it('deve marcar ciclo ao chamar toggleCiclo()', () => {
      component.toggleCiclo('2026.1');
      expect(component.isCicloSelecionado('2026.1')).toBe(true);
    });

    it('deve desmarcar ciclo já selecionado', () => {
      component.toggleCiclo('2026.1');
      component.toggleCiclo('2026.1');
      expect(component.isCicloSelecionado('2026.1')).toBe(false);
    });
  });

  describe('Seleção de status', () => {
    it('deve marcar status ao chamar toggleStatus()', () => {
      component.toggleStatus('PUBLICADO');
      expect(component.isStatusSelecionado('PUBLICADO')).toBe(true);
    });

    it('deve desmarcar status já selecionado', () => {
      component.toggleStatus('PUBLICADO');
      component.toggleStatus('PUBLICADO');
      expect(component.isStatusSelecionado('PUBLICADO')).toBe(false);
    });
  });

  describe('toggleSecaoCiclos()', () => {
    it('deve colapsar a seção de ciclos ao chamar toggleSecaoCiclos()', () => {
      expect(component.secaoCiclosAberta()).toBe(true);
      component.toggleSecaoCiclos();
      expect(component.secaoCiclosAberta()).toBe(false);
    });

    it('deve expandir a seção de ciclos ao chamar toggleSecaoCiclos() novamente', () => {
      component.toggleSecaoCiclos();
      component.toggleSecaoCiclos();
      expect(component.secaoCiclosAberta()).toBe(true);
    });
  });

  describe('toggleSecaoStatus()', () => {
    it('deve colapsar a seção de status ao chamar toggleSecaoStatus()', () => {
      expect(component.secaoStatusAberta()).toBe(true);
      component.toggleSecaoStatus();
      expect(component.secaoStatusAberta()).toBe(false);
    });

    it('deve expandir a seção de status ao chamar toggleSecaoStatus() novamente', () => {
      component.toggleSecaoStatus();
      component.toggleSecaoStatus();
      expect(component.secaoStatusAberta()).toBe(true);
    });
  });

  describe('initFiltros()', () => {
    it('deve refletir filtros ao chamar initFiltros()', () => {
      component.initFiltros({ ciclos: ['2026.2'], status: ['INVALIDO'] });

      expect(component.isCicloSelecionado('2026.2')).toBe(true);
      expect(component.isStatusSelecionado('INVALIDO')).toBe(true);
    });

    it('deve sobrescrever seleção anterior ao chamar initFiltros() novamente', () => {
      component.initFiltros({ ciclos: ['2026.1'], status: [] });
      component.initFiltros({ ciclos: ['2026.2'], status: ['INVALIDO'] });

      expect(component.isCicloSelecionado('2026.1')).toBe(false);
      expect(component.isCicloSelecionado('2026.2')).toBe(true);
    });
  });

  describe('Apply-on-close', () => {
    it('deve emitir filtrosAplicados ao fechar com seleção diferente do snapshot', () => {
      const spy = jest.fn();
      component.filtrosAplicados.subscribe(spy);

      component.toggleCiclo('2026.1');
      component.close();

      expect(spy).toHaveBeenCalledWith({ ciclos: ['2026.1'], status: [] });
    });

    it('não deve emitir filtrosAplicados ao fechar com seleção idêntica ao snapshot', () => {
      component.initFiltros({ ciclos: ['2026.1'], status: [] });
      component.open();
      const spy = jest.fn();
      component.filtrosAplicados.subscribe(spy);

      component.close();

      expect(spy).not.toHaveBeenCalled();
    });

    it('deve considerar filtros iguais independente da ordem', () => {
      component.initFiltros({ ciclos: ['2026.1', '2026.2'], status: [] });
      component.open();
      const spy = jest.fn();
      component.filtrosAplicados.subscribe(spy);

      component.ciclosSelecionados.set(['2026.2', '2026.1']);
      component.close();

      expect(spy).not.toHaveBeenCalled();
    });

    it('deve emitir fechado ao fechar', () => {
      const spy = jest.fn();
      component.fechado.subscribe(spy);
      component.close();
      expect(spy).toHaveBeenCalled();
    });
  });

  describe('Botão Filtrar', () => {
    it('deve emitir filtrosAplicados com ciclos e status selecionados ao chamar aplicar()', () => {
      const spy = jest.fn();
      component.filtrosAplicados.subscribe(spy);

      component.toggleCiclo('2026.1');
      component.toggleStatus('PUBLICADO');
      component.aplicar();

      expect(spy).toHaveBeenCalledWith({
        ciclos: ['2026.1'],
        status: ['PUBLICADO'],
      });
    });
  });

  describe('Botão Limpar filtro', () => {
    it('deve emitir filtrosLimpos', () => {
      const spy = jest.fn();
      component.filtrosLimpos.subscribe(spy);

      component.toggleCiclo('2026.1');
      component.limpar();

      expect(spy).toHaveBeenCalled();
    });

    it('deve limpar seleções após limpar', () => {
      component.toggleCiclo('2026.1');
      component.toggleStatus('PUBLICADO');
      component.limpar();

      expect(component.ciclosSelecionados()).toHaveLength(0);
      expect(component.statusSelecionados()).toHaveLength(0);
    });

    it('não deve emitir filtrosAplicados ao limpar', () => {
      const spy = jest.fn();
      component.filtrosAplicados.subscribe(spy);

      component.toggleCiclo('2026.1');
      component.limpar();

      expect(spy).not.toHaveBeenCalled();
    });
  });

  describe('Fechar ao clicar fora (ESC)', () => {
    it('deve emitir fechado ao chamar onEscape() quando aberto', () => {
      const spy = jest.fn();
      component.fechado.subscribe(spy);
      component.onEscape();
      expect(spy).toHaveBeenCalled();
    });
  });

  describe('labelStatus()', () => {
    it('deve retornar label legível para PUBLICADO', () => {
      expect(component.labelStatus('PUBLICADO')).toBe('Publicado');
    });

    it('deve retornar label legível para EM_PUBLICACAO', () => {
      expect(component.labelStatus('EM_PUBLICACAO')).toBe('Em publicação');
    });

    it('deve retornar o próprio status quando não há mapeamento', () => {
      expect(component.labelStatus('OUTRO')).toBe('OUTRO');
    });
  });
});
