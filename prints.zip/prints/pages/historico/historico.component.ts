import { Component, computed, DestroyRef, inject, OnInit, signal, ViewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { DatePipe } from '@angular/common';
import { HistoricoService } from '@core/services/historico/historico.service';
import { ErrorStateComponent } from '@shared/components/error-state/error-state';
import { Spinner } from '@shared/components/spinner/spinner';
import { FiltrosHistoricoComponent } from './filtros-historico/filtros-historico.component';
import { HistoricoFiltros, HistoricoItem, PaginationInfo } from '@shared/models/historico.model';

@Component({
  selector: 'app-historico',
  imports: [DatePipe, ErrorStateComponent, Spinner, FiltrosHistoricoComponent],
  templateUrl: './historico.component.html',
  styleUrl: './historico.component.scss',
})
export class HistoricoComponent implements OnInit {
  @ViewChild('filtrosDrawer') private readonly filtrosDrawer!: FiltrosHistoricoComponent;

  private readonly historicoService = inject(HistoricoService);
  private readonly destroyRef = inject(DestroyRef);

  registros = signal<HistoricoItem[]>([]);
  paginacao = signal<PaginationInfo | null>(null);
  carregando = signal(true);
  erro = signal(false);
  paginaAtual = signal(0);
  ordemAsc = signal(false);
  filtrosAtivos = signal<HistoricoFiltros>({ ciclos: [], status: [] });
  ciclosDisponiveis = signal<string[]>([]);
  exportandoId = signal<number | null>(null);

  pageSize = signal<number>(10);
  readonly pageSizeOptions = [10, 20, 50];
  readonly skeletonRows = Array(10);

  filtrosAplicados = computed(
    () => this.filtrosAtivos().ciclos.length > 0 || this.filtrosAtivos().status.length > 0
  );

  totalFiltrosAtivos = computed(() => {
    const f = this.filtrosAtivos();
    return f.ciclos.length + f.status.length;
  });

  private readonly STATUS_LABELS: Record<string, string> = {
    PUBLICADO: 'Publicado',
    PENDENTE: 'Não publicado',
    EM_PUBLICACAO: 'Em publicação',
    INVALIDO: 'Inválido',
    CANCELADA: 'Cancelado',
    ERRO_SISTEMA: 'Erro do sistema',
    VALIDACAO_ERRO: 'Erro de validação',
  };

  ngOnInit(): void {
    this.carregar();
  }

  carregar(): void {
    this.carregando.set(true);
    this.erro.set(false);
    const ordem = this.ordemAsc() ? 'ASC' : 'DESC';

    this.historicoService
      .obterHistorico(this.filtrosAtivos(), this.paginaAtual(), this.pageSize(), ordem)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: resp => {
          const data = resp.data;
          this.registros.set(data.content ?? []);
          this.paginacao.set(data.pagination ?? null);
          this.ciclosDisponiveis.set(data.filtrosDisponiveis?.ciclos ?? []);
          this.carregando.set(false);
        },
        error: () => {
          this.erro.set(true);
          this.carregando.set(false);
        },
      });
  }

  toggleOrdem(): void {
    this.ordemAsc.update(v => !v);
    this.paginaAtual.set(0);
    this.carregar();
  }

  irParaPagina(pagina: number): void {
    const totalPages = this.paginacao()?.totalPages ?? 0;
    if (pagina < 0 || pagina >= totalPages) return;
    this.paginaAtual.set(pagina);
    this.carregar();
  }

  aplicarFiltros(filtros: HistoricoFiltros): void {
    this.filtrosAtivos.set(filtros);
    this.paginaAtual.set(0);
    this.carregar();
  }

  alterarItensPorPagina(size: number): void {
    this.pageSize.set(size);
    this.paginaAtual.set(0);
    this.carregar();
  }

  abrirFiltros(): void {
    this.filtrosDrawer.initFiltros(this.filtrosAtivos());
    this.filtrosDrawer.open();
  }

  limparFiltros(): void {
    this.filtrosAtivos.set({ ciclos: [], status: [] });
    this.paginaAtual.set(0);
    this.carregar();
  }

  exportar(item: HistoricoItem): void {
    this.exportandoId.set(item.importacaoId);
    this.historicoService
      .exportar(item.importacaoId)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: blob => {
          const link = document.createElement('a');
          link.href = URL.createObjectURL(blob);
          link.download = `Historico_Publicacao_${item.cicloId}_${item.importacaoId}.xlsx`;
          link.click();
          URL.revokeObjectURL(link.href);
          this.exportandoId.set(null);
        },
        error: () => this.exportandoId.set(null),
      });
  }

  obterIniciais(nome: string): string {
    if (!nome) return '?';
    const partes = nome.trim().split(/\s+/);
    if (partes.length === 1) return partes[0][0].toUpperCase();
    return `${partes[0][0]}${partes[partes.length - 1][0]}`.toUpperCase();
  }

  corAvatar(nome: string): string {
    const cores = [
      '#5B8DEF',
      '#00BFA5',
      '#FF7043',
      '#AB47BC',
      '#26A69A',
      '#7E57C2',
      '#42A5F5',
      '#66BB6A',
    ];
    let hash = 0;
    for (const char of nome) hash = char.charCodeAt(0) + ((hash << 5) - hash);
    return cores[Math.abs(hash) % cores.length];
  }

  labelStatus(status: string): string {
    return this.STATUS_LABELS[status] ?? status;
  }

  paginacaoInfo(): { inicio: number; fim: number; total: number } {
    const pag = this.paginacao();
    if (!pag || pag.totalElements === 0) return { inicio: 0, fim: 0, total: 0 };
    const inicio = pag.page * pag.pageSize + 1;
    const fim = Math.min((pag.page + 1) * pag.pageSize, pag.totalElements);
    return { inicio, fim, total: pag.totalElements };
  }

  temFiltrosAtivos(): boolean {
    const f = this.filtrosAtivos();
    return f.ciclos.length > 0 || f.status.length > 0;
  }

  contadorFiltros(): number {
    return this.totalFiltrosAtivos();
  }
}
