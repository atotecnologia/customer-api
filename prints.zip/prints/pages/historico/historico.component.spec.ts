import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NEVER, of, throwError } from 'rxjs';
import { HistoricoComponent } from './historico.component';
import { HistoricoService } from '@core/services/historico/historico.service';
import { FiltrosHistoricoComponent } from './filtros-historico/filtros-historico.component';
import {
  obterHistoricoResponse,
  obterHistoricoVazio,
} from '@shared/mocks/fixtures/historico.fixture';

const mockService = {
  obterHistorico: jest.fn(),
  exportar: jest.fn(),
};

describe('HistoricoComponent', () => {
  let component: HistoricoComponent;
  let fixture: ComponentFixture<HistoricoComponent>;

  beforeEach(async () => {
    jest.clearAllMocks();

    await TestBed.configureTestingModule({
      imports: [HistoricoComponent],
      providers: [{ provide: HistoricoService, useValue: mockService }],
    }).compileComponents();

    fixture = TestBed.createComponent(HistoricoComponent);
    component = fixture.componentInstance;
  });

  it('deve criar o componente', () => {
    mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  describe('Inicialização', () => {
    it('deve exibir spinner durante o carregamento', () => {
      mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
      expect(component.carregando()).toBe(true);
    });

    it('deve chamar obterHistorico com parâmetros padrão ao inicializar', () => {
      mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
      fixture.detectChanges();

      expect(mockService.obterHistorico).toHaveBeenCalledWith(
        { ciclos: [], status: [] },
        0,
        10,
        'DESC'
      );
    });
  });

  describe('Carregamento com sucesso', () => {
    beforeEach(() => {
      mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
      fixture.detectChanges();
    });

    it('deve popular registros com o conteúdo da resposta', () => {
      expect(component.registros()).toHaveLength(6);
    });

    it('deve popular informações de paginação', () => {
      expect(component.paginacao()?.totalElements).toBe(6);
      expect(component.paginacao()?.totalPages).toBe(1);
    });

    it('deve popular filtros disponíveis', () => {
      expect(component.ciclosDisponiveis()).toContain('2026.1');
    });

    it('deve ocultar spinner após carregamento', () => {
      expect(component.carregando()).toBe(false);
    });

    it('deve manter erro como false após sucesso', () => {
      expect(component.erro()).toBe(false);
    });
  });

  describe('Erro no carregamento', () => {
    beforeEach(() => {
      mockService.obterHistorico.mockReturnValue(throwError(() => new Error('falha')));
      fixture.detectChanges();
    });

    it('deve ativar signal de erro', () => {
      expect(component.erro()).toBe(true);
    });

    it('deve ocultar carregando após erro', () => {
      expect(component.carregando()).toBe(false);
    });

    it('deve manter registros vazios após erro', () => {
      expect(component.registros()).toHaveLength(0);
    });

    it('deve manter paginacao como null após erro', () => {
      expect(component.paginacao()).toBeNull();
    });

    it('deve resetar signal de erro ao chamar carregar() novamente', () => {
      mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
      component.carregar();
      expect(component.erro()).toBe(false);
    });

    it('deve ativar carregando ao tentar recarregar após erro', () => {
      mockService.obterHistorico.mockReturnValue(NEVER);
      component.carregar();
      expect(component.carregando()).toBe(true);
    });

    it('deve popular registros após retry bem-sucedido', () => {
      mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
      component.carregar();
      expect(component.registros()).toHaveLength(6);
    });
  });

  describe('toggleOrdem()', () => {
    beforeEach(() => {
      mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
      fixture.detectChanges();
    });

    it('deve mudar ordemAsc de false para true', () => {
      expect(component.ordemAsc()).toBe(false);
      component.toggleOrdem();
      expect(component.ordemAsc()).toBe(true);
    });

    it('deve chamar obterHistorico com ordem=ASC após toggle', () => {
      component.toggleOrdem();
      expect(mockService.obterHistorico).toHaveBeenLastCalledWith(expect.any(Object), 0, 10, 'ASC');
    });

    it('deve resetar paginaAtual para 0 ao trocar ordem', () => {
      component.paginaAtual.set(2);
      component.toggleOrdem();
      expect(component.paginaAtual()).toBe(0);
    });
  });

  describe('Filtros', () => {
    beforeEach(() => {
      mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
      fixture.detectChanges();
    });

    it('deve aplicar filtros e resetar página ao chamar aplicarFiltros()', () => {
      component.paginaAtual.set(2);
      component.aplicarFiltros({ ciclos: ['2026.1'], status: ['PUBLICADO'] });

      expect(component.filtrosAtivos()).toEqual({ ciclos: ['2026.1'], status: ['PUBLICADO'] });
      expect(component.paginaAtual()).toBe(0);
      expect(mockService.obterHistorico).toHaveBeenCalledTimes(2);
    });

    it('deve limpar filtros e resetar página ao chamar limparFiltros()', () => {
      component.filtrosAtivos.set({ ciclos: ['2026.1'], status: ['PUBLICADO'] });
      component.paginaAtual.set(1);
      component.limparFiltros();

      expect(component.filtrosAtivos()).toEqual({ ciclos: [], status: [] });
      expect(component.paginaAtual()).toBe(0);
    });

    it('temFiltrosAtivos() deve retornar true quando há filtros', () => {
      component.filtrosAtivos.set({ ciclos: ['2026.1'], status: [] });
      expect(component.temFiltrosAtivos()).toBe(true);
    });

    it('temFiltrosAtivos() deve retornar false quando filtros estão vazios', () => {
      component.filtrosAtivos.set({ ciclos: [], status: [] });
      expect(component.temFiltrosAtivos()).toBe(false);
    });

    it('totalFiltrosAtivos deve somar ciclos e status ativos', () => {
      component.filtrosAtivos.set({ ciclos: ['2026.1', '2026.2'], status: ['PUBLICADO'] });
      expect(component.totalFiltrosAtivos()).toBe(3);
    });

    it('totalFiltrosAtivos deve retornar 0 quando sem filtros', () => {
      component.filtrosAtivos.set({ ciclos: [], status: [] });
      expect(component.totalFiltrosAtivos()).toBe(0);
    });
  });

  describe('abrirFiltros()', () => {
    it('deve chamar initFiltros e open no drawer com os filtros ativos atuais', () => {
      mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
      fixture.detectChanges();

      const drawer = fixture.debugElement.query(By.directive(FiltrosHistoricoComponent))
        .componentInstance as FiltrosHistoricoComponent;
      const initSpy = jest.spyOn(drawer, 'initFiltros');
      const openSpy = jest.spyOn(drawer, 'open');

      component.filtrosAtivos.set({ ciclos: ['2026.1'], status: [] });
      component.abrirFiltros();

      expect(initSpy).toHaveBeenCalledWith({ ciclos: ['2026.1'], status: [] });
      expect(openSpy).toHaveBeenCalled();
    });
  });

  describe('Paginação', () => {
    beforeEach(() => {
      mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
      fixture.detectChanges();
    });

    it('irParaPagina() deve atualizar paginaAtual e recarregar', () => {
      component.paginacao.set({ page: 0, pageSize: 20, totalPages: 5, totalElements: 100 });
      component.irParaPagina(2);

      expect(component.paginaAtual()).toBe(2);
      expect(mockService.obterHistorico).toHaveBeenCalledTimes(2);
    });

    it('irParaPagina() não deve ir além do limite de páginas', () => {
      component.paginacao.set({ page: 0, pageSize: 20, totalPages: 2, totalElements: 30 });
      component.paginaAtual.set(1);
      const chamadas = mockService.obterHistorico.mock.calls.length;
      component.irParaPagina(2);

      expect(component.paginaAtual()).toBe(1);
      expect(mockService.obterHistorico).toHaveBeenCalledTimes(chamadas);
    });
  });

  describe('alterarItensPorPagina()', () => {
    beforeEach(() => {
      mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
      fixture.detectChanges();
    });

    it('deve atualizar pageSize e resetar paginaAtual para 0', () => {
      component.paginaAtual.set(3);
      component.alterarItensPorPagina(50);

      expect(component.pageSize()).toBe(50);
      expect(component.paginaAtual()).toBe(0);
    });

    it('deve recarregar os dados após alterar pageSize', () => {
      component.alterarItensPorPagina(20);
      expect(mockService.obterHistorico).toHaveBeenLastCalledWith(
        expect.any(Object),
        0,
        20,
        'DESC'
      );
    });

    it('deve expor as opções de página 10, 20 e 50', () => {
      expect(component.pageSizeOptions).toEqual([10, 20, 50]);
    });
  });

  describe('Estados vazios', () => {
    it('filtrosAplicados deve retornar true quando há filtros de ciclo ativos', () => {
      mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
      fixture.detectChanges();
      component.filtrosAtivos.set({ ciclos: ['2026.1'], status: [] });
      expect(component.filtrosAplicados()).toBe(true);
    });

    it('filtrosAplicados deve retornar true quando há filtros de status ativos', () => {
      mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
      fixture.detectChanges();
      component.filtrosAtivos.set({ ciclos: [], status: ['PUBLICADO'] });
      expect(component.filtrosAplicados()).toBe(true);
    });

    it('filtrosAplicados deve retornar false quando não há filtros', () => {
      mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
      fixture.detectChanges();
      component.filtrosAtivos.set({ ciclos: [], status: [] });
      expect(component.filtrosAplicados()).toBe(false);
    });
  });

  describe('Exportar', () => {
    beforeEach(() => {
      global.URL.createObjectURL = jest.fn().mockReturnValue('blob:mock');
      global.URL.revokeObjectURL = jest.fn();
      mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
      fixture.detectChanges();
    });

    it('deve chamar historicoService.exportar com os dados do item', () => {
      mockService.exportar.mockReturnValue(of(new Blob(['xlsx'])));
      const item = component.registros()[0];
      component.exportar(item);

      expect(mockService.exportar).toHaveBeenCalledWith(item.importacaoId);
    });

    it('deve limpar exportandoId após conclusão', () => {
      mockService.exportar.mockReturnValue(of(new Blob(['xlsx'])));
      const item = component.registros()[0];
      component.exportar(item);

      expect(component.exportandoId()).toBeNull();
    });

    it('deve limpar exportandoId em caso de erro na exportação', () => {
      mockService.exportar.mockReturnValue(throwError(() => new Error('falha export')));
      const item = component.registros()[0];
      component.exportar(item);

      expect(component.exportandoId()).toBeNull();
    });
  });

  describe('obterIniciais()', () => {
    it('deve retornar as iniciais do primeiro e último nome', () => {
      expect(component.obterIniciais('Maria Silva')).toBe('MS');
    });

    it('deve retornar a inicial do nome único', () => {
      expect(component.obterIniciais('Maria')).toBe('M');
    });

    it('deve retornar ? para string vazia', () => {
      expect(component.obterIniciais('')).toBe('?');
    });
  });

  describe('labelStatus()', () => {
    it('deve retornar label correto para PUBLICADO', () => {
      expect(component.labelStatus('PUBLICADO')).toBe('Publicado');
    });

    it('deve retornar o próprio status quando não há mapeamento', () => {
      expect(component.labelStatus('DESCONHECIDO')).toBe('DESCONHECIDO');
    });
  });

  describe('Template', () => {
    describe('Skeleton', () => {
      it('deve exibir skeleton enquanto carrega', () => {
        mockService.obterHistorico.mockReturnValue(NEVER);
        fixture.detectChanges();

        const skeleton = fixture.nativeElement.querySelector('.historico-skeleton');
        expect(skeleton).toBeTruthy();
      });

      it('deve exibir 10 linhas skeleton', () => {
        mockService.obterHistorico.mockReturnValue(NEVER);
        fixture.detectChanges();

        const rows = fixture.nativeElement.querySelectorAll('.skeleton-row');
        expect(rows).toHaveLength(10);
      });

      it('não deve exibir a tabela durante o carregamento', () => {
        mockService.obterHistorico.mockReturnValue(NEVER);
        fixture.detectChanges();

        expect(fixture.nativeElement.querySelector('.historico-table-wrap')).toBeFalsy();
      });

      it('deve ocultar skeleton após carregamento concluído', () => {
        mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
        fixture.detectChanges();

        expect(fixture.nativeElement.querySelector('.historico-skeleton')).toBeFalsy();
      });
    });

    describe('Estado de erro', () => {
      beforeEach(() => {
        mockService.obterHistorico.mockReturnValue(throwError(() => new Error('falha')));
        fixture.detectChanges();
      });

      it('deve exibir app-error-state quando ocorre erro na requisição', () => {
        expect(fixture.nativeElement.querySelector('app-error-state')).toBeTruthy();
      });

      it('não deve exibir a tabela quando há erro', () => {
        expect(fixture.nativeElement.querySelector('.historico-table-wrap')).toBeFalsy();
      });

      it('não deve exibir skeleton quando há erro', () => {
        expect(fixture.nativeElement.querySelector('.historico-skeleton')).toBeFalsy();
      });

      it('não deve exibir a toolbar de filtros quando há erro', () => {
        expect(fixture.nativeElement.querySelector('.historico-toolbar')).toBeFalsy();
      });

      it('deve exibir botão com texto "Recarregar"', () => {
        const botao: HTMLButtonElement = fixture.nativeElement.querySelector('.btn-retry');
        expect(botao).toBeTruthy();
        expect(botao.textContent?.trim()).toContain('Recarregar');
      });

      it('deve exibir skeleton ao acionar retry enquanto recarrega', () => {
        mockService.obterHistorico.mockReturnValue(NEVER);
        const botao: HTMLButtonElement = fixture.nativeElement.querySelector('.btn-retry');
        botao.click();
        fixture.detectChanges();

        expect(fixture.nativeElement.querySelector('.historico-skeleton')).toBeTruthy();
        expect(fixture.nativeElement.querySelector('app-error-state')).toBeFalsy();
      });

      it('deve exibir a tabela após retry bem-sucedido', () => {
        mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
        const botao: HTMLButtonElement = fixture.nativeElement.querySelector('.btn-retry');
        botao.click();
        fixture.detectChanges();

        expect(fixture.nativeElement.querySelector('.historico-table-wrap')).toBeTruthy();
        expect(fixture.nativeElement.querySelector('app-error-state')).toBeFalsy();
      });

      it('deve ocultar app-error-state após retry bem-sucedido', () => {
        mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
        component.carregar();
        fixture.detectChanges();

        expect(fixture.nativeElement.querySelector('app-error-state')).toBeFalsy();
      });
    });

    describe('Estado "não há dados" (sem filtros e sem registros)', () => {
      beforeEach(() => {
        mockService.obterHistorico.mockReturnValue(of(obterHistoricoVazio()));
        fixture.detectChanges();
      });

      it('deve exibir mensagem principal de ausência de dados', () => {
        expect(fixture.nativeElement.textContent).toContain(
          'Ainda não há dados para serem exibidos.'
        );
      });

      it('deve exibir instrução para realizar a primeira ação', () => {
        expect(fixture.nativeElement.textContent).toContain(
          'Faça a sua primeira ação para começar a ver os dados aqui.'
        );
      });

      it('deve manter os cabeçalhos da tabela visíveis', () => {
        const texto = fixture.nativeElement.textContent;
        expect(texto).toContain('Data');
        expect(texto).toContain('Status');
        expect(texto).toContain('Importação');
        expect(texto).toContain('Publicação');
      });

      it('não deve exibir mensagem de "sem resultado"', () => {
        expect(fixture.nativeElement.textContent).not.toContain('Não encontramos resultados.');
      });

      it('não deve exibir os controles de paginação', () => {
        expect(fixture.nativeElement.querySelector('.historico-pagination')).toBeFalsy();
      });
    });

    describe('Estado "sem resultado" (filtros ativos sem retorno)', () => {
      beforeEach(() => {
        mockService.obterHistorico.mockReturnValue(of(obterHistoricoVazio()));
        fixture.detectChanges();
        component.filtrosAtivos.set({ ciclos: ['2026.1'], status: [] });
        fixture.detectChanges();
      });

      it('deve exibir mensagem de nenhum resultado encontrado', () => {
        expect(fixture.nativeElement.textContent).toContain('Não encontramos resultados.');
      });

      it('deve exibir orientação para ajustar os filtros', () => {
        expect(fixture.nativeElement.textContent).toContain('Ajuste os filtros e tente novamente');
      });

      it('deve manter os cabeçalhos da tabela visíveis', () => {
        const texto = fixture.nativeElement.textContent;
        expect(texto).toContain('Data');
        expect(texto).toContain('Status');
      });

      it('não deve exibir mensagem de "não há dados"', () => {
        expect(fixture.nativeElement.textContent).not.toContain(
          'Ainda não há dados para serem exibidos.'
        );
      });

      it('não deve exibir os controles de paginação', () => {
        expect(fixture.nativeElement.querySelector('.historico-pagination')).toBeFalsy();
      });
    });

    describe('Seletor de itens por página', () => {
      beforeEach(() => {
        mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
        fixture.detectChanges();
      });

      it('deve exibir o select de itens por página quando há registros', () => {
        expect(fixture.nativeElement.querySelector('.pagination-select')).toBeTruthy();
      });

      it('deve listar as opções 10, 20 e 50', () => {
        const options: HTMLOptionElement[] = Array.from(
          fixture.nativeElement.querySelectorAll('.pagination-select option')
        );
        expect(options.map(o => Number(o.value))).toEqual([10, 20, 50]);
      });

      it('deve ter a opção 10 selecionada por padrão', () => {
        const select: HTMLSelectElement = fixture.nativeElement.querySelector('.pagination-select');
        expect(Number(select.value)).toBe(10);
      });

      it('não deve exibir o select quando não há registros', () => {
        mockService.obterHistorico.mockReturnValue(of(obterHistoricoVazio()));
        component.carregar();
        fixture.detectChanges();

        expect(fixture.nativeElement.querySelector('.pagination-select')).toBeFalsy();
      });
    });

    describe('Paginação com dados', () => {
      beforeEach(() => {
        mockService.obterHistorico.mockReturnValue(of(obterHistoricoResponse()));
        fixture.detectChanges();
      });

      it('deve exibir indicador de página atual e total', () => {
        component.paginaAtual.set(1);
        component.paginacao.set({ page: 1, pageSize: 10, totalPages: 5, totalElements: 50 });
        fixture.detectChanges();

        expect(fixture.nativeElement.textContent).toContain('Página 2 de 5');
      });

      it('deve exibir os quatro botões de navegação', () => {
        const botoes = fixture.nativeElement.querySelectorAll('.pagination-btn');
        expect(botoes).toHaveLength(4);
      });

      it('deve desabilitar botões de página anterior na primeira página', () => {
        const botoes: HTMLButtonElement[] = Array.from(
          fixture.nativeElement.querySelectorAll('.pagination-btn')
        );
        expect(botoes[0].disabled).toBe(true);
        expect(botoes[1].disabled).toBe(true);
      });
    });
  });
});
