import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { HttpErrorResponse } from '@angular/common/http';
import { EMPTY, of, throwError } from 'rxjs';
import { UploadComponent } from './upload.component';
import { UploadService } from '@app/core/services/upload/upload.service';
import { PublicacaoService } from '@app/core/services/publicacao/publicacao.service';
import { Router } from '@angular/router';
import { DiagnosticoImportacao } from '@app/shared/models/diagnostico-importacao.model';
import { ListagemCiclos } from '@app/shared/models/listagem-ciclos.model';
import { ResponseAPI } from '@app/shared/models/response-api.model';
import { StatusPublicacao } from '@app/shared/models/publicacao.model';
import { UploadResponse } from '@app/shared/models/upload-response.model';
import { obterStatusPublicacaoResponse } from '@shared/mocks/fixtures/publicacao.fixture';

const mockCiclosVazios: ListagemCiclos = {
  status: 'OK',
  message: 'Sucesso',
  data: { ultimoUploadGeral: '', ciclos: [] },
};

const mockDiagnosticoNulo: ResponseAPI<null> = {
  status: 'OK',
  message: 'Nenhuma importação',
  data: null,
};

type StatusDiag = DiagnosticoImportacao['ultimaImportacao']['status'];

function mockDiagnostico(
  status: StatusDiag,
  extras: Partial<Omit<DiagnosticoImportacao, 'ultimaImportacao'>> & { totalSkus?: number } = {}
): ResponseAPI<DiagnosticoImportacao> {
  const { totalSkus = null, skusValidos, skusInvalidos, erros } = extras;

  return {
    status: 'OK',
    message: '',
    data: {
      ultimaImportacao: {
        importacaoId: 7,
        nomeArquivo: 'planilha.xlsx',
        status,
        realizadoPor: 'usuario@cruzeirodosul.edu.br',
        data: '2026-07-06T10:00:00',
        totalSkus,
      },
      skusValidos,
      skusInvalidos,
      erros,
    },
  };
}

describe('UploadComponent', () => {
  let component: UploadComponent;
  let fixture: ComponentFixture<UploadComponent>;
  let mockUploadService: jest.Mocked<UploadService>;
  let mockPublicacaoService: jest.Mocked<PublicacaoService>;
  let mockRouter: jest.Mocked<Router>;

  beforeEach(async () => {
    jest.spyOn(console, 'error').mockImplementation(jest.fn());

    const uploadServiceSpy = {
      obterCiclosImportados: jest.fn().mockReturnValue(of(mockCiclosVazios)),
      obterImportacoes: jest
        .fn()
        .mockReturnValue(of({ status: 'OK', message: 'Sucesso', data: [] })),
      diagnosticoImportacao: jest.fn().mockReturnValue(of(mockDiagnosticoNulo)),
      observarDiagnosticoImportacao: jest.fn().mockReturnValue(of(mockDiagnosticoNulo)),
      enviarCicloImportado: jest.fn(),
    };

    const publicacaoServiceSpy = {
      observarStatusPublicacao: jest
        .fn()
        .mockReturnValue(of({ status: 'OK', message: '', data: null })),
    };

    const routerSpy = {
      navigate: jest.fn(),
    };

    await TestBed.configureTestingModule({
      imports: [UploadComponent],
      providers: [
        { provide: UploadService, useValue: uploadServiceSpy },
        { provide: PublicacaoService, useValue: publicacaoServiceSpy },
        { provide: Router, useValue: routerSpy },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(UploadComponent);
    component = fixture.componentInstance;
    mockUploadService = TestBed.inject(UploadService) as jest.Mocked<UploadService>;
    mockPublicacaoService = TestBed.inject(PublicacaoService) as jest.Mocked<PublicacaoService>;
    mockRouter = TestBed.inject(Router) as jest.Mocked<Router>;
  });

  it('deve criar o componente corretamente', () => {
    expect(component).toBeTruthy();
  });

  describe('dado o método ngOnInit', () => {
    it('deve chamar os métodos na inicialização', () => {
      const loadOpcoesCiclosSpy = jest.spyOn(component as any, 'loadOpcoesCiclos');

      fixture.detectChanges();

      expect(loadOpcoesCiclosSpy).toHaveBeenCalledWith('2026.1');
      expect(mockUploadService.obterImportacoes).toHaveBeenCalledTimes(1);
      expect(mockPublicacaoService.observarStatusPublicacao).toHaveBeenCalledTimes(1);
    });

    it('não deve definir cicloSelecionado automaticamente', () => {
      fixture.detectChanges();

      expect(component.cicloSelecionado).toBe('');
    });
  });

  describe('dado o método verificaStatusPublicacao', () => {
    it('deve definir publicacaoEmAndamento como true quando status é EM_PUBLICACAO', () => {
      const resposta = obterStatusPublicacaoResponse();
      const respostaEmPublicacao = {
        ...resposta,
        data: { ...resposta.data, status: 'EM_PUBLICACAO' as StatusPublicacao['status'] },
      };

      mockPublicacaoService.observarStatusPublicacao.mockReturnValue(of(respostaEmPublicacao));

      fixture.detectChanges();

      expect(component.publicacaoEmAndamento()).toBe(true);
    });

    it('não deve definir publicacaoEmAndamento como true quando status é diferente de EM_PUBLICACAO', () => {
      mockPublicacaoService.observarStatusPublicacao.mockReturnValue(
        of(obterStatusPublicacaoResponse())
      );

      fixture.detectChanges();

      expect(component.publicacaoEmAndamento()).toBe(false);
    });

    it('não deve definir publicacaoEmAndamento como true quando data é null', () => {
      fixture.detectChanges();

      expect(component.publicacaoEmAndamento()).toBe(false);
    });

    it('deve manter publicacaoEmAndamento como false quando o stream não emite (falhas tratadas no service)', () => {
      mockPublicacaoService.observarStatusPublicacao.mockReturnValue(EMPTY);

      expect(() => fixture.detectChanges()).not.toThrow();
      expect(component.publicacaoEmAndamento()).toBe(false);
    });
  });

  describe('dado o método gerarProximosCiclos', () => {
    it('deve gerar os próximos 4 ciclos a partir do primeiro semestre', () => {
      expect(component['gerarProximosCiclos']('2024.1')).toEqual([
        '2024.2',
        '2025.1',
        '2025.2',
        '2026.1',
      ]);
    });

    it('deve gerar os próximos 2 ciclos a partir do segundo semestre', () => {
      expect(component['gerarProximosCiclos']('2023.2')).toEqual([
        '2024.1',
        '2024.2',
        '2025.1',
        '2025.2',
      ]);
    });
  });

  describe('dado o método onCicloSelected', () => {
    it('deve atualizar cicloSelecionado e chamar diagnosticoImportacao', () => {
      component.onCicloSelected('2024.1');

      expect(component.cicloSelecionado).toBe('2024.1');
      expect(mockUploadService.diagnosticoImportacao).toHaveBeenCalledWith('2024.1');
    });

    it('deve definir selecionarArquivo como true quando data do diagnóstico for null', () => {
      mockUploadService.diagnosticoImportacao.mockReturnValue(of(mockDiagnosticoNulo));

      component.onCicloSelected('2024.1');

      expect(component.selecionarArquivo()).toBe(true);
      expect(component.statusImportacao()).toBeNull();
    });

    it('deve definir statusImportacao como sucesso quando há importação PENDENTE', () => {
      const mockDiagnostico: ResponseAPI<DiagnosticoImportacao> = {
        status: 'OK',
        message: 'Sucesso',
        data: {
          ultimaImportacao: {
            importacaoId: 10,
            nomeArquivo: 'planilha-2024.xlsx',
            status: 'PENDENTE',
            realizadoPor: 'user@cruzeirodosul.edu.br',
            data: '2024-06-01',
            totalSkus: 200,
          },
        },
      };

      mockUploadService.diagnosticoImportacao.mockReturnValue(of(mockDiagnostico));

      component.onCicloSelected('2024.1');

      expect(component.statusImportacao()).toBe('sucesso');
      expect(component.resultadoImportacao()?.nomeArquivo).toBe('planilha-2024.xlsx');
      expect(component.resultadoImportacao()?.totalSkus).toBe(200);
      expect(component.resultadoImportacao()?.skusInvalidos).toBe(0);
    });

    it('deve definir selecionarArquivo como true quando importação tem status PUBLICADO', () => {
      const mockDiagnostico: ResponseAPI<DiagnosticoImportacao> = {
        status: 'OK',
        message: 'Sucesso',
        data: {
          ultimaImportacao: {
            importacaoId: 5,
            nomeArquivo: 'planilha.xlsx',
            status: 'PUBLICADO',
            realizadoPor: 'user@cruzeirodosul.edu.br',
            data: '2024-06-01',
            totalSkus: 100,
          },
        },
      };

      mockUploadService.diagnosticoImportacao.mockReturnValue(of(mockDiagnostico));

      component.onCicloSelected('2024.1');

      expect(component.selecionarArquivo()).toBe(true);
      expect(component.statusImportacao()).toBeNull();
    });

    it('deve retomar o acompanhamento quando a última importação está PROCESSANDO', () => {
      mockUploadService.diagnosticoImportacao.mockReturnValue(of(mockDiagnostico('PROCESSANDO')));
      mockUploadService.observarDiagnosticoImportacao.mockReturnValue(
        of(mockDiagnostico('PROCESSANDO'))
      );

      component.onCicloSelected('2024.1');

      expect(component.isUploading()).toBe(true);
      expect(mockUploadService.observarDiagnosticoImportacao).toHaveBeenCalledWith('2024.1');
    });

    it('deve exibir o resultado de erro quando a última importação é VALIDACAO_ERRO', () => {
      mockUploadService.diagnosticoImportacao.mockReturnValue(
        of(
          mockDiagnostico('VALIDACAO_ERRO', {
            totalSkus: 10,
            skusValidos: 8,
            skusInvalidos: 2,
            erros: [{ linha: 3, coluna: 'C', descricao: 'Inválido' }],
          })
        )
      );

      component.onCicloSelected('2024.1');

      expect(component.statusImportacao()).toBe('erro');
      expect(component.resultadoImportacao()?.skusInvalidos).toBe(2);
      expect(component.resultadoImportacao()?.erros).toHaveLength(1);
    });

    it('deve definir exibirErroCarregamento como true quando diagnosticoImportacao falhar', () => {
      mockUploadService.diagnosticoImportacao.mockReturnValue(
        throwError(() => new Error('Erro de rede'))
      );

      component.onCicloSelected('2024.1');

      expect(component.exibirErroCarregamento()).toBe(true);
    });
  });

  describe('dado o método onFilesDropped', () => {
    const mockValidFile = new File([''], 'planilha.xlsx', {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    });

    it('deve definir arquivoSelecionado ao receber arquivo válido', () => {
      const fileList = { 0: mockValidFile, length: 1 } as unknown as FileList;

      component.onFilesDropped(fileList);

      expect(component.arquivoSelecionado()).toEqual(mockValidFile);
      expect(component.erroDropzone()).toBeNull();
    });

    it('deve ignorar silenciosamente quando múltiplos arquivos são soltos', () => {
      const fileList = { length: 2 } as FileList;

      component.onFilesDropped(fileList);

      expect(component.arquivoSelecionado()).toBeNull();
      expect(component.erroDropzone()).toBeNull();
    });

    it('deve definir erroDropzone com título "Formato incompatível" para tipo inválido', () => {
      const invalidFile = new File([''], 'documento.txt', { type: 'text/plain' });
      const fileList = { 0: invalidFile, length: 1 } as unknown as FileList;

      component.onFilesDropped(fileList);

      expect(component.arquivoSelecionado()).toBeNull();
      expect(component.erroDropzone()?.titulo).toBe('Formato incompatível');
    });

    it('deve definir erroDropzone com título "Tamanho máximo excedido" para arquivo muito grande', () => {
      const largeFile = new File(['a'.repeat(6 * 1024 * 1024)], 'grande.xlsx', {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });
      const fileList = { 0: largeFile, length: 1 } as unknown as FileList;

      component.onFilesDropped(fileList);

      expect(component.arquivoSelecionado()).toBeNull();
      expect(component.erroDropzone()?.titulo).toBe('Tamanho máximo excedido');
    });
  });

  describe('dado o método onSelected', () => {
    const mockValidFile = new File([''], 'planilha.xlsx', {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    });

    it('deve selecionar arquivo válido via input', () => {
      const fileList = { 0: mockValidFile, length: 1 } as unknown as FileList;
      const event = { target: { files: fileList, value: '' } } as unknown as Event;

      component.onSelected(event);

      expect(component.arquivoSelecionado()).toEqual(mockValidFile);
    });

    it('deve ignorar quando nenhum arquivo for selecionado', () => {
      const event = { target: { files: null } } as unknown as Event;

      component.onSelected(event);

      expect(component.arquivoSelecionado()).toBeNull();
    });

    it('deve limpar o valor do input ao tentar selecionar múltiplos arquivos', () => {
      const mockTarget = { files: { length: 2 } as FileList, value: 'fakepath' };
      const event = { target: mockTarget } as unknown as Event;

      component.onSelected(event);

      expect(mockTarget.value).toBe('');
      expect(component.arquivoSelecionado()).toBeNull();
    });
  });

  describe('dado o método acaoProcurarArquivo', () => {
    it('deve limpar os valores das variáveis arquivoSelecionado, erroDropzone', () => {
      component.arquivoSelecionado.set(new File([''], 'planilha.xlsx'));
      component.erroDropzone.set({
        titulo: 'Formato incompatível',
        subtitulo: '',
        botaoTitulo: '',
        botaoAcao: jest.fn(),
      });

      component['acaoProcurarArquivo']();

      expect(component.arquivoSelecionado()).toBeNull();
      expect(component.erroDropzone()).toBeNull();
    });

    it('deve chamar click() no fileInput quando fornecido', () => {
      const mockFileInput = { click: jest.fn() } as unknown as HTMLInputElement;

      component['acaoProcurarArquivo'](mockFileInput);

      expect(mockFileInput.click).toHaveBeenCalledTimes(1);
    });

    it('não deve lançar erro quando fileInput não é fornecido', () => {
      expect(() => component['acaoProcurarArquivo']()).not.toThrow();
    });
  });

  describe('dado o método enviarArquivo', () => {
    const mockFile = new File([''], 'planilha.xlsx', {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    });

    const respostaAceite: ResponseAPI<UploadResponse> = {
      status: 'OK',
      message: 'Upload recebido. O processamento está em andamento.',
      data: {
        importacaoId: 7,
        status: 'PROCESSANDO',
        totalSkus: 0,
        skusValidos: 0,
        skusInvalidos: 0,
        erros: [],
      },
    };

    beforeEach(() => {
      component.cicloSelecionado = '2024.1';
      component.arquivoSelecionado.set(mockFile);
      component.isUploading.set(false);
    });

    it('não deve chamar o service se isUploading for true', () => {
      component.isUploading.set(true);

      component.enviarArquivo();

      expect(mockUploadService.enviarCicloImportado).not.toHaveBeenCalled();
    });

    it('não deve chamar o service se cicloSelecionado estiver vazio', () => {
      component.cicloSelecionado = '';

      component.enviarArquivo();

      expect(mockUploadService.enviarCicloImportado).not.toHaveBeenCalled();
    });

    it('não deve chamar o service se arquivoSelecionado for null', () => {
      component.arquivoSelecionado.set(null);

      component.enviarArquivo();

      expect(mockUploadService.enviarCicloImportado).not.toHaveBeenCalled();
    });

    it('deve manter isUploading true enquanto o processamento está em andamento', () => {
      mockUploadService.enviarCicloImportado.mockReturnValue(of(respostaAceite));
      mockUploadService.observarDiagnosticoImportacao.mockReturnValue(
        of(mockDiagnostico('PROCESSANDO'))
      );

      component.enviarArquivo();

      expect(component.isUploading()).toBe(true);
      expect(mockUploadService.observarDiagnosticoImportacao).toHaveBeenCalledWith('2024.1');
    });

    it('deve concluir com sucesso quando o polling retorna PENDENTE', () => {
      mockUploadService.enviarCicloImportado.mockReturnValue(of(respostaAceite));
      mockUploadService.observarDiagnosticoImportacao.mockReturnValue(
        of(mockDiagnostico('PENDENTE', { totalSkus: 100, skusValidos: 100, skusInvalidos: 0 }))
      );

      component.enviarArquivo();

      expect(component.isUploading()).toBe(false);
      expect(component.statusImportacao()).toBe('sucesso');
      expect(component.resultadoImportacao()?.totalSkus).toBe(100);
      expect(component.resultadoImportacao()?.nomeArquivo).toBe(mockFile.name);
    });

    it('deve concluir com erro quando o polling retorna VALIDACAO_ERRO', () => {
      mockUploadService.enviarCicloImportado.mockReturnValue(of(respostaAceite));
      mockUploadService.observarDiagnosticoImportacao.mockReturnValue(
        of(
          mockDiagnostico('VALIDACAO_ERRO', {
            totalSkus: 100,
            skusValidos: 90,
            skusInvalidos: 10,
            erros: [{ linha: 2, coluna: 'B', descricao: 'Campo inválido' }],
          })
        )
      );

      component.enviarArquivo();

      expect(component.isUploading()).toBe(false);
      expect(component.statusImportacao()).toBe('erro');
      expect(component.resultadoImportacao()?.skusInvalidos).toBe(10);
      expect(component.resultadoImportacao()?.erros).toHaveLength(1);
    });

    it('deve exibir erro genérico quando o polling retorna ERRO_SISTEMA', () => {
      mockUploadService.enviarCicloImportado.mockReturnValue(of(respostaAceite));
      mockUploadService.observarDiagnosticoImportacao.mockReturnValue(
        of(mockDiagnostico('ERRO_SISTEMA'))
      );

      component.enviarArquivo();

      expect(component.isUploading()).toBe(false);
      expect(component.erroDropzone()?.titulo).toBe('Ocorreu uma falha ao importar o arquivo');
    });

    it('deve exibir erro genérico quando o polling do diagnóstico falha', () => {
      mockUploadService.enviarCicloImportado.mockReturnValue(of(respostaAceite));
      mockUploadService.observarDiagnosticoImportacao.mockReturnValue(
        throwError(() => new HttpErrorResponse({ status: 500 }))
      );

      component.enviarArquivo();

      expect(component.isUploading()).toBe(false);
      expect(component.erroDropzone()?.titulo).toBe('Ocorreu uma falha ao importar o arquivo');
    });

    it('deve definir erroDropzone com "Modelo incompatível" para erro HTTP 400 no aceite', () => {
      const error = new HttpErrorResponse({ status: 400 });
      mockUploadService.enviarCicloImportado.mockReturnValue(throwError(() => error));

      component.enviarArquivo();

      expect(component.isUploading()).toBe(false);
      expect(component.erroDropzone()?.titulo).toBe('Modelo incompatível');
    });

    it('deve definir erroDropzone com mensagem genérica para erros diferentes de 400 no aceite', () => {
      const error = new HttpErrorResponse({ status: 500 });
      mockUploadService.enviarCicloImportado.mockReturnValue(throwError(() => error));

      component.enviarArquivo();

      expect(component.isUploading()).toBe(false);
      expect(component.erroDropzone()?.titulo).toBe('Ocorreu uma falha ao importar o arquivo');
    });
  });

  describe('dado o método confirmarNovoEnvio', () => {
    it('deve resetar todo o estado do componente', () => {
      component.statusImportacao.set('sucesso');
      component.resultadoImportacao.set({
        nomeArquivo: 'planilha.xlsx',
        cicloId: '2024.1',
        totalSkus: 10,
        skusValidos: 10,
        skusInvalidos: 0,
      });
      component.arquivoSelecionado.set(new File([''], 'planilha.xlsx'));
      component.erroDropzone.set({
        titulo: '',
        subtitulo: '',
        botaoTitulo: '',
        botaoAcao: jest.fn(),
      });
      component.cicloSelecionado = '2024.1';
      component.selecionarArquivo.set(true);

      component.confirmarNovoEnvio();

      expect(component.statusImportacao()).toBeNull();
      expect(component.resultadoImportacao()).toBeNull();
      expect(component.arquivoSelecionado()).toBeNull();
      expect(component.erroDropzone()).toBeNull();
      expect(component.cicloSelecionado).toBe('2024.1');
      expect(component.selecionarArquivo()).toBe(true);
    });
  });

  describe('dado tiposArquivosPermitidos', () => {
    it('deve retornar as extensões e os MIMEs válidos', () => {
      const tipos = component.tiposArquivosPermitidos;

      expect(tipos).toContain('.xlsx');
      expect(tipos).toContain('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    });
  });

  describe('dado extensoesValidasFormatada', () => {
    it('deve formatar as extensões em português', () => {
      expect(component.extensoesValidasFormatada).toBe('.xlsx');
    });
  });

  describe('dado o método direcionarPublicacoes', () => {
    it('deve navegar para /app/publicacoes', () => {
      component.direcionarPublicacoes();

      expect(mockRouter.navigate).toHaveBeenCalledWith(['/app/publicacoes']);
    });
  });

  describe('dado o método loadCiclos', () => {
    it('deve gerar opcoesCiclos a partir do último ciclo importado, em ordem decrescente', () => {
      const mockResponse: ListagemCiclos = {
        status: 'OK',
        message: 'Sucesso',
        data: {
          ultimoUploadGeral: '2024-06-01',
          ciclos: [
            { id: '2023.2', label: '2023.2', dataUpload: '2023-07-01' },
            { id: '2024.1', label: '2024.1', dataUpload: '2024-01-01' },
          ],
        },
      };
      mockUploadService.obterCiclosImportados.mockReturnValue(of(mockResponse));

      component['loadCiclos']();

      expect(component.opcoesCiclos()).toEqual(['2024.1', '2024.2', '2025.1', '2025.2', '2026.1']);
    });

    it('deve gerar opcoesCiclos com base na data atual quando não há ciclos importados', () => {
      mockUploadService.obterCiclosImportados.mockReturnValue(of(mockCiclosVazios));

      jest.useFakeTimers().setSystemTime(new Date('2024-08-15'));

      component['loadCiclos']();

      expect(component.opcoesCiclos()).toEqual(['2024.2', '2025.1', '2025.2', '2026.1', '2026.2']);

      jest.useRealTimers();
    });
  });

  describe('verificando mudanças no HTML', () => {
    beforeEach(() => {
      fixture.detectChanges();
    });

    it('deve exibir #section-error quando exibirErroCarregamento é true', () => {
      component.exibirErroCarregamento.set(true);
      fixture.detectChanges();

      const errorSection = fixture.debugElement.query(By.css('#section-error'));

      expect(errorSection).not.toBeNull();
    });

    it('não deve exibir #section-error por padrão', () => {
      const errorSection = fixture.debugElement.query(By.css('#section-error'));

      expect(errorSection).toBeNull();
    });

    it('deve exibir o título da página quando statusImportacao é null', () => {
      component.statusImportacao.set(null);
      fixture.detectChanges();

      const title = fixture.debugElement.query(By.css('#pagina-titulo'));

      expect(title.nativeElement.textContent).toContain('Importar Dados do Ciclo');
    });

    it('deve exibir "Importação realizada!" quando statusImportacao é "sucesso"', () => {
      component.statusImportacao.set('sucesso');
      fixture.detectChanges();

      const title = fixture.debugElement.query(By.css('#import-sucesso-titulo'));

      expect(title.nativeElement.textContent).toContain('Importação realizada!');
    });

    it('deve exibir "Importação não realizada!" quando statusImportacao é "erro"', () => {
      component.statusImportacao.set('erro');
      fixture.detectChanges();

      const title = fixture.debugElement.query(By.css('#import-erro-titulo'));

      expect(title.nativeElement.textContent).toContain('Importação não realizada!');
    });

    it('deve exibir o empty state quando importacoes está vazio', () => {
      component.importacoes.set([]);
      fixture.detectChanges();

      const emptyState = fixture.debugElement.query(By.css('#sem-importacoes'));

      expect(emptyState).not.toBeNull();
    });

    it('deve exibir a lista de importações quando ciclosImportados tem itens', () => {
      component.importacoes.set([
        {
          importacaoId: 1,
          nomeArquivo: 'planilha.xlsx',
          cicloId: '2024.1',
          status: 'PUBLICADO',
          data: '2024-01-01',
          realizadoPor: 'usuario@cruzeirodosul.edu.br',
        },
        {
          importacaoId: 2,
          nomeArquivo: 'planilha2.xlsx',
          cicloId: '2024.2',
          status: 'PENDENTE',
          data: '2024-07-01',
          realizadoPor: 'usuario@cruzeirodosul.edu.br',
        },
      ]);
      fixture.detectChanges();

      const emptyState = fixture.debugElement.query(By.css('#sem-importacoes'));
      expect(emptyState).toBeNull();

      const importList = fixture.debugElement.query(By.css('#lista-importacoes'));
      expect(importList).not.toBeNull();
    });
  });
});
