export interface ErroImportacao {
  linha: number;
  coluna: string;
  descricao: string;
}

export interface ResultadoImportacao {
  nomeArquivo: string;
  cicloId: string;
  totalSkus: number;
  skusValidos: number;
  skusInvalidos: number;
  erros?: ErroImportacao[];
}
