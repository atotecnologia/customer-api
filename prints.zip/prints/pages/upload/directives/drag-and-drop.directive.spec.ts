import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DragAndDropDirective } from './drag-and-drop.directive';

@Component({
  standalone: true,
  imports: [DragAndDropDirective],
  template: `<div
    appDragAndDrop
    [disabled]="isDisabled"
    (filesDropped)="onFilesDropped($event)"></div>`,
})
class TestComponent {
  public isDisabled = false;
  public droppedFiles: FileList | null = null;
  public onFilesDropped(files: FileList) {
    this.droppedFiles = files;
  }
}

// Função auxiliar para criar um mock de FileList
function createMockFileList(files: File[] = []): FileList {
  return Object.assign([...files], {
    length: files.length,
    item: (index: number) => files[index] || null,
  }) as unknown as FileList;
}

describe('DragAndDropDirective', () => {
  let fixture: ComponentFixture<TestComponent>;
  let component: TestComponent;
  let divEl: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DragAndDropDirective, TestComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    divEl = fixture.debugElement.query(By.directive(DragAndDropDirective));
    fixture.detectChanges();
  });

  it('deve criar uma instância', () => {
    const directive = divEl.injector.get(DragAndDropDirective);
    expect(directive).toBeTruthy();
  });

  it('deve adicionar a classe "drag-over" no evento dragover', () => {
    const event = {
      preventDefault: jest.fn(),
      stopPropagation: jest.fn(),
    };

    divEl.triggerEventHandler('dragover', event);
    fixture.detectChanges();

    expect(event.preventDefault).toHaveBeenCalled();
    expect(event.stopPropagation).toHaveBeenCalled();
    expect(divEl.nativeElement.classList.contains('drag-over')).toBe(true);
  });

  it('deve remover a classe "drag-over" no evento dragleave', () => {
    divEl.triggerEventHandler('dragover', {
      preventDefault: jest.fn(),
      stopPropagation: jest.fn(),
    });
    fixture.detectChanges();
    expect(divEl.nativeElement.classList.contains('drag-over')).toBe(true);

    const event = {
      preventDefault: jest.fn(),
      stopPropagation: jest.fn(),
      relatedTarget: null,
    };

    divEl.triggerEventHandler('dragleave', event);
    fixture.detectChanges();

    expect(event.preventDefault).toHaveBeenCalled();
    expect(event.stopPropagation).toHaveBeenCalled();
    expect(divEl.nativeElement.classList.contains('drag-over')).toBe(false);
  });

  it('não deve remover a classe "drag-over" quando o relatedTarget for um elemento filho', () => {
    divEl.triggerEventHandler('dragover', {
      preventDefault: jest.fn(),
      stopPropagation: jest.fn(),
    });
    fixture.detectChanges();
    expect(divEl.nativeElement.classList.contains('drag-over')).toBe(true);

    const childEl = document.createElement('span');
    divEl.nativeElement.appendChild(childEl);

    const event = {
      preventDefault: jest.fn(),
      stopPropagation: jest.fn(),
      relatedTarget: childEl,
    };

    divEl.triggerEventHandler('dragleave', event);
    fixture.detectChanges();

    expect(divEl.nativeElement.classList.contains('drag-over')).toBe(true);
  });

  it('deve emitir os arquivos no evento drop', () => {
    const mockFile = new File(['content'], 'test.txt', { type: 'text/plain' });
    const mockFileList = createMockFileList([mockFile]);

    const event = {
      preventDefault: jest.fn(),
      stopPropagation: jest.fn(),
      dataTransfer: {
        files: mockFileList,
      },
    };

    divEl.triggerEventHandler('drop', event);
    fixture.detectChanges();

    expect(event.preventDefault).toHaveBeenCalled();
    expect(event.stopPropagation).toHaveBeenCalled();
    expect(divEl.nativeElement.classList.contains('drag-over')).toBe(false);
    expect(component.droppedFiles).toBe(mockFileList);
    expect(component.droppedFiles?.length).toBe(1);
    expect(component.droppedFiles?.[0].name).toBe('test.txt');
  });

  describe('quando disabled = true', () => {
    beforeEach(() => {
      component.isDisabled = true;
      fixture.detectChanges();
    });

    it('não deve adicionar a classe "drag-over" no evento dragover', () => {
      const event = {
        preventDefault: jest.fn(),
        stopPropagation: jest.fn(),
      };

      divEl.triggerEventHandler('dragover', event);
      fixture.detectChanges();

      expect(event.preventDefault).toHaveBeenCalled();
      expect(divEl.nativeElement.classList.contains('drag-over')).toBe(false);
    });

    it('não deve emitir arquivos no evento drop', () => {
      const mockFile = new File(['content'], 'test.txt', { type: 'text/plain' });
      const event = {
        preventDefault: jest.fn(),
        stopPropagation: jest.fn(),
        dataTransfer: { files: createMockFileList([mockFile]) },
      };
      jest.spyOn(component, 'onFilesDropped');

      divEl.triggerEventHandler('drop', event);
      fixture.detectChanges();

      expect(event.preventDefault).toHaveBeenCalled();
      expect(component.onFilesDropped).not.toHaveBeenCalled();
    });
  });

  it('não deve emitir arquivos no drop se nenhum arquivo estiver presente', () => {
    const emptyFileList = createMockFileList([]);
    const event = {
      preventDefault: jest.fn(),
      stopPropagation: jest.fn(),
      dataTransfer: {
        files: emptyFileList,
      },
    };
    jest.spyOn(component, 'onFilesDropped');

    divEl.triggerEventHandler('drop', event);
    fixture.detectChanges();

    expect(component.onFilesDropped).not.toHaveBeenCalled();
  });
});
