import {
  Directive,
  ElementRef,
  HostBinding,
  HostListener,
  inject,
  input,
  output,
} from '@angular/core';

@Directive({
  selector: '[appDragAndDrop]',
})
export class DragAndDropDirective {
  private readonly elementRef = inject(ElementRef);

  disabled = input(false);
  filesDropped = output<FileList>();
  @HostBinding('class.drag-over') isDragging = false;

  @HostListener('dragover', ['$event']) onDragOver(evt: DragEvent) {
    evt.preventDefault();
    evt.stopPropagation();

    if (this.disabled()) {
      return;
    }

    this.isDragging = true;
  }

  @HostListener('dragleave', ['$event']) onDragLeave(evt: DragEvent) {
    evt.preventDefault();
    evt.stopPropagation();

    const relatedTarget = evt.relatedTarget as Node;
    if (this.elementRef.nativeElement.contains(relatedTarget)) {
      return;
    }

    this.isDragging = false;
  }

  @HostListener('drop', ['$event']) onDrop(evt: DragEvent) {
    evt.preventDefault();
    evt.stopPropagation();
    this.isDragging = false;

    if (this.disabled()) {
      return;
    }

    const files = evt.dataTransfer?.files;

    if (files && files.length > 0) {
      this.filesDropped.emit(files);
    }
  }
}
