import { Component, DestroyRef, inject, OnInit, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { takeWhile } from 'rxjs';
import { DragAndDropDirective } from './directives/drag-and-drop.directive';
import { FormsModule } from '@angular/forms';
import { UploadService } from '@app/core/services/upload/upload.service';
import { DropdownComponent } from '@app/shared/components/dropdown/dropdown';
import {
  LucideFileText,
  LucideFileUp,
  LucideCircleCheck,
  LucideCircleX,
  LucideTriangleAlert,
  LucideCircleArrowDown,
  LucideCircleAlert,
  LucideCloudUpload,
} from '@lucide/angular';
import { ModalOrientacoesComponent } from './components/modal-orientacoes/modal-orientacoes.component';
import { ModalConfirmacaoComponent } from './components/modal-confirmacao/modal-confirmacao.component';
import { ModalRelatorioErrosComponent } from './components/modal-relatorio-erros/modal-relatorio-erros.component';
import { Importacoes } from '@app/shared/models/importacoes.model';
import { DiagnosticoImportacao } from '@app/shared/models/diagnostico-importacao.model';
import { ErrorStateComponent } from '@app/shared/components/error-state/error-state';
import { HttpErrorResponse } from '@angular/common/http';
import { ResultadoImportacao } from './models/resultado-importacao.model';
import { PublicacaoService } from '@app/core/services/publicacao/publicacao.service';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';

interface ErroDropzone {
  titulo: string;
  subtitulo: string;
  botaoTitulo: string;
  botaoAcao(fileInput?: HTMLInputElement): void;
}
type StatusImportacao = 'sucesso' | 'erro' | null;

@Component({
  selector: 'app-upload.component',
  imports: [
    DatePipe,
    DragAndDropDirective,
    FormsModule,
    DropdownComponent,
    LucideFileText,
    LucideFileUp,
    LucideCloudUpload,
    ModalOrientacoesComponent,
    ModalConfirmacaoComponent,
    ModalRelatorioErrosComponent,
    ErrorStateComponent,
    LucideCircleCheck,
    LucideCircleX,
    LucideTriangleAlert,
    LucideCircleArrowDown,
    LucideCircleAlert,
  ],
  templateUrl: './upload.component.html',
  styleUrl: './upload.component.scss',
})
export class UploadComponent implements OnInit {
  protected readonly uploadService = inject(UploadService);
  protected readonly publicacaoService = inject(PublicacaoService);
  protected readonly router = inject(Router);
  private readonly destroyRef = inject(DestroyRef);

  protected readonly TAMANHO_MAX_ARQUIVO_FORMATADO = '5MB';
  private readonly TAMANHO_MAX_ARQUIVO_PERMITIDO = 5 * 1024 * 1024; // 5MB

  private readonly EXTENSOES_VALIDAS = ['.xlsx'];
  private readonly MIMES_VALIDOS = [
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  ];

  readonly tiposArquivosPermitidos = [...this.EXTENSOES_VALIDAS, ...this.MIMES_VALIDOS];
  readonly extensoesValidasFormatada = new Intl.ListFormat('pt-BR', {
    style: 'long',
    type: 'conjunction',
  }).format(this.EXTENSOES_VALIDAS);

  exibirErroCarregamento = signal(false);
  publicacaoEmAndamento = signal(false);
  isUploading = signal(false);

  importacoes = signal<Importacoes[]>([]);
  opcoesCiclos = signal<string[]>([]);

  cicloSelecionado = '';
  selecionarArquivo = signal(false);
  arquivoSelecionado = signal<File | null>(null);

  erroDropzone = signal<ErroDropzone | null>(null);
  statusImportacao = signal<StatusImportacao>(null);
  resultadoImportacao = signal<ResultadoImportacao | null>(null);
  nomeArquivoEmProcessamento = signal<string | null>(null);

  ngOnInit(): void {
    this.loadOpcoesCiclos('2026.1');
    this.loadImportacoes();
    this.verificaStatusPublicacao();
  }

  onCicloSelected(ciclo: string): void {
    this.cicloSelecionado = ciclo;

    this.verificarUploadExistente();
  }

  onFilesDropped(files: FileList): void {
    if (files.length > 1) {
      return;
    }

    this.validarEProcessarArquivo(files[0]);
  }

  onSelected(event: Event): void {
    const target = event.target as HTMLInputElement;
    const files = target.files;

    if (!files || files.length === 0) {
      return;
    }

    if (files.length > 1) {
      target.value = '';

      return;
    }

    this.validarEProcessarArquivo(files[0]);
    target.value = '';
  }

  private validarEProcessarArquivo(file: File): void {
    this.erroDropzone.set(null);
    this.arquivoSelecionado.set(null);

    const nomeArquivo = file.name.toLowerCase();
    const extensaoValida = this.EXTENSOES_VALIDAS.some(ext => nomeArquivo.endsWith(ext));
    const mimeValido = this.MIMES_VALIDOS.includes(file.type);

    if (!extensaoValida && !mimeValido) {
      this.erroDropzone.set({
        titulo: 'Formato incompatível',
        subtitulo: `O formato permitido é ${this.extensoesValidasFormatada}. Por favor, selecione um arquivo compatível.`,
        botaoTitulo: 'Procurar arquivo',
        botaoAcao: this.acaoProcurarArquivo,
      });

      return;
    }

    if (file.size > this.TAMANHO_MAX_ARQUIVO_PERMITIDO) {
      this.erroDropzone.set({
        titulo: 'Tamanho máximo excedido',
        subtitulo: `O tamanho máximo permitido é de ${this.TAMANHO_MAX_ARQUIVO_FORMATADO}. Por favor, selecione um arquivo menor.`,
        botaoTitulo: 'Procurar arquivo',
        botaoAcao: this.acaoProcurarArquivo,
      });

      return;
    }

    this.arquivoSelecionado.set(file);
  }

  private readonly acaoProcurarArquivo = (fileInput?: HTMLInputElement) => {
    this.arquivoSelecionado.set(null);
    this.erroDropzone.set(null);

    fileInput?.click();
  };

  enviarArquivo(): void {
    if (this.isUploading() || !this.cicloSelecionado || !this.arquivoSelecionado()) {
      return;
    }

    this.isUploading.set(true);

    const cicloId = this.cicloSelecionado;
    const file = this.arquivoSelecionado()!;

    // O upload é assíncrono: o POST responde imediatamente (202, status PROCESSANDO) e o desfecho é
    // obtido por polling do diagnóstico — evitando timeout enquanto a planilha é processada.
    this.uploadService.enviarCicloImportado(cicloId, file).subscribe({
      next: () => this.acompanharProcessamento(cicloId, file.name),
      error: (err: HttpErrorResponse) => {
        this.isUploading.set(false);
        this.handleError('Upload', err);

        if (err.status === 400) {
          this.erroDropzone.set({
            titulo: 'Modelo incompatível',
            subtitulo:
              'A planilha de preços deve seguir as orientações de envio. Revise o arquivo e envie novamente.',
            botaoTitulo: 'Recarregar página',
            botaoAcao: this.recarregarPagina,
          });
        } else {
          this.definirErroDropzoneGenerico();
        }
      },
    });
  }

  // Acompanha o processamento assíncrono por polling do diagnóstico até um estado terminal
  // (PENDENTE = sucesso, VALIDACAO_ERRO = erros na planilha, ERRO_SISTEMA = falha). Encerra o
  // polling na primeira emissão terminal e também junto com o componente.
  private acompanharProcessamento(cicloId: string, nomeArquivo: string): void {
    this.uploadService
      .observarDiagnosticoImportacao(cicloId)
      .pipe(
        takeWhile(res => !this.isDiagnosticoTerminal(res.data), true),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: res => {
          if (!this.isDiagnosticoTerminal(res.data)) {
            return;
          }

          this.isUploading.set(false);
          this.nomeArquivoEmProcessamento.set(null);
          this.aplicarDiagnostico(res.data!, nomeArquivo, cicloId);
          this.loadImportacoes();
        },
        error: err => {
          this.isUploading.set(false);
          this.nomeArquivoEmProcessamento.set(null);
          this.definirErroDropzoneGenerico();
          this.handleError('Diagnóstico', err);
        },
      });
  }

  private isDiagnosticoTerminal(diagnostico: DiagnosticoImportacao | null): boolean {
    const status = diagnostico?.ultimaImportacao?.status;

    return !!status && status !== 'PROCESSANDO';
  }

  // Traduz o diagnóstico terminal na tela de resultado (sucesso/erro).
  private aplicarDiagnostico(
    diagnostico: DiagnosticoImportacao,
    nomeArquivo: string,
    cicloId: string
  ): void {
    const importacao = diagnostico.ultimaImportacao;
    const nome = importacao.nomeArquivo ?? nomeArquivo;

    switch (importacao.status) {
      case 'PENDENTE':
      case 'PUBLICADO':
        this.statusImportacao.set('sucesso');
        this.resultadoImportacao.set({
          nomeArquivo: nome,
          cicloId,
          totalSkus: importacao.totalSkus ?? 0,
          skusValidos: diagnostico.skusValidos ?? importacao.totalSkus ?? 0,
          skusInvalidos: diagnostico.skusInvalidos ?? 0,
        });
        break;
      case 'VALIDACAO_ERRO':
      case 'INVALIDO':
        this.statusImportacao.set('erro');
        this.resultadoImportacao.set({
          nomeArquivo: nome,
          cicloId,
          totalSkus: importacao.totalSkus ?? 0,
          skusValidos: diagnostico.skusValidos ?? 0,
          skusInvalidos: diagnostico.skusInvalidos ?? diagnostico.erros?.length ?? 0,
          erros: diagnostico.erros ?? [],
        });
        break;
      default:
        this.definirErroDropzoneGenerico();
    }
  }

  private definirErroDropzoneGenerico(): void {
    this.erroDropzone.set({
      titulo: 'Ocorreu uma falha ao importar o arquivo',
      subtitulo: 'Recarregue a página para tentar novamente.',
      botaoTitulo: 'Recarregar página',
      botaoAcao: this.recarregarPagina,
    });
  }

  confirmarNovoEnvio(): void {
    this.statusImportacao.set(null);
    this.resultadoImportacao.set(null);
    this.arquivoSelecionado.set(null);
    this.erroDropzone.set(null);
    this.nomeArquivoEmProcessamento.set(null);
    this.selecionarArquivo.set(true);
  }

  recarregarPagina(): void {
    globalThis.location.reload();
  }

  direcionarPublicacoes(): void {
    this.router.navigate(['/app/publicacoes']);
  }

  direcionarHistorico(): void {
    this.router.navigate(['/app/historico']);
  }

  private loadCiclos(): void {
    this.uploadService.obterCiclosImportados().subscribe({
      next: res => {
        const ciclos = res.data.ciclos || [];

        ciclos.sort((a, b) => b.id.localeCompare(a.id));

        this.loadOpcoesCiclos(ciclos[0]?.id ?? '');
      },
      error: err => {
        this.loadOpcoesCiclos('');

        this.handleError('Ciclos', err);
      },
    });
  }

  private loadImportacoes(): void {
    this.uploadService
      .obterImportacoes()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: res => {
          this.importacoes.set(res.data ?? []);
        },
        error: err => {
          this.handleError('Importações', err);
        },
      });
  }

  private loadOpcoesCiclos(ultimoCicloImportado: string): void {
    let ciclos!: string[];

    if (ultimoCicloImportado) {
      const ciclosGerados = this.gerarProximosCiclos(ultimoCicloImportado);

      ciclos = [ultimoCicloImportado, ...ciclosGerados];
    } else {
      const ano = new Date().getFullYear();
      const mes = new Date().getMonth() + 1;

      const semestre = mes <= 6 ? 1 : 2;
      const cicloInicial = `${ano}.${semestre}`;

      ciclos = [cicloInicial, ...this.gerarProximosCiclos(cicloInicial)];
    }

    this.opcoesCiclos.set(ciclos);
  }

  private gerarProximosCiclos(ultimoCicloId: string): string[] {
    const [anoStr, semestreStr] = ultimoCicloId.split('.');

    let ano = Number.parseInt(anoStr, 10);
    let semestre = Number.parseInt(semestreStr, 10);

    const nextCiclos: string[] = [];

    for (let i = 0; i < 4; i++) {
      semestre++;

      if (semestre > 2) {
        semestre = 1;
        ano++;
      }

      nextCiclos.push(`${ano}.${semestre}`);
    }

    return nextCiclos;
  }

  private verificarUploadExistente() {
    const cicloId = this.cicloSelecionado;
    this.uploadService.diagnosticoImportacao(cicloId).subscribe({
      next: res => {
        const data = res.data;
        const status = data?.ultimaImportacao?.status;

        if (status === 'PROCESSANDO') {
          // Upload iniciado em outra sessão ainda em processamento: retoma o acompanhamento.
          this.isUploading.set(true);
          this.nomeArquivoEmProcessamento.set(data!.ultimaImportacao.nomeArquivo);
          this.acompanharProcessamento(cicloId, data!.ultimaImportacao.nomeArquivo);
        } else if (status === 'PENDENTE' || status === 'VALIDACAO_ERRO') {
          this.nomeArquivoEmProcessamento.set(null);
          this.aplicarDiagnostico(data!, data!.ultimaImportacao.nomeArquivo, cicloId);
        } else {
          this.nomeArquivoEmProcessamento.set(null);
          this.selecionarArquivo.set(true);
        }
      },
      error: err => {
        this.exibirErroCarregamento.set(true);

        this.handleError('Diagnóstico', err);
      },
    });
  }

  // Acompanha o stream compartilhado de status (polling adaptativo no PublicacaoService) para
  // refletir quando uma publicação inicia/conclui sem exigir refresh. Falhas de consulta são
  // toleradas pelo próprio service (o stream nunca erra). Encerra junto com o componente.
  private verificaStatusPublicacao(): void {
    this.publicacaoService
      .observarStatusPublicacao()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(res => {
        this.publicacaoEmAndamento.set(res.data?.status === 'EM_PUBLICACAO');
      });
  }

  private handleError(origemErro: string, erro: HttpErrorResponse): void {
    const mensagemErro = `[${origemErro}] Erro ao processar ${origemErro}`;

    console.error(mensagemErro, erro.error);
  }
}
