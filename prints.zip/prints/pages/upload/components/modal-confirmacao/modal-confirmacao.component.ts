import { Component, EventEmitter, Output } from '@angular/core';
import { LucideX } from '@lucide/angular';
import { BaseModal } from '@shared/directives/base-modal';

@Component({
  selector: 'app-modal-confirmacao',
  imports: [LucideX],
  templateUrl: './modal-confirmacao.component.html',
  styleUrl: './modal-confirmacao.component.scss',
})
export class ModalConfirmacaoComponent extends BaseModal {
  @Output() confirmed = new EventEmitter<void>();

  confirm(): void {
    this.confirmed.emit();
    this.close();
  }
}
