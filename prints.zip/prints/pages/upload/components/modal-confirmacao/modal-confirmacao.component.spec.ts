import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ModalConfirmacaoComponent } from './modal-confirmacao.component';

describe('ModalConfirmacaoComponent', () => {
  let component: ModalConfirmacaoComponent;
  let fixture: ComponentFixture<ModalConfirmacaoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ModalConfirmacaoComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ModalConfirmacaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    document.body.style.overflow = '';
  });

  it('deve criar o componente', () => {
    expect(component).toBeTruthy();
  });

  describe('dado o estado inicial', () => {
    it('não deve renderizar o overlay quando fechado', () => {
      const overlay = fixture.nativeElement.querySelector('#modal-confirmacao');

      expect(overlay).toBeNull();
    });
  });

  describe('dado o método open()', () => {
    it('deve renderizar o overlay após abrir', () => {
      component.open();
      fixture.detectChanges();

      const overlay = fixture.nativeElement.querySelector('#modal-confirmacao');

      expect(overlay).not.toBeNull();
    });

    it('deve renderizar o modal-box após abrir', () => {
      component.open();
      fixture.detectChanges();

      const modalBox = fixture.nativeElement.querySelector('#modal-box');

      expect(modalBox).not.toBeNull();
    });
  });

  describe('dado o método close()', () => {
    it('deve remover o overlay após fechar', () => {
      component.open();
      fixture.detectChanges();

      component.close();
      fixture.detectChanges();

      const overlay = fixture.nativeElement.querySelector('#modal-confirmacao');

      expect(overlay).toBeNull();
    });
  });

  describe('dado o método confirm()', () => {
    it('deve emitir o evento confirmed', () => {
      jest.spyOn(component.confirmed, 'emit');

      component.confirm();

      expect(component.confirmed.emit).toHaveBeenCalledTimes(1);
    });

    it('deve fechar o modal após confirmar', () => {
      component.isOpen = true;

      component.confirm();

      expect(component.isOpen).toBe(false);
    });
  });

  describe('interações via DOM', () => {
    beforeEach(() => {
      component.open();
      fixture.detectChanges();
    });

    it('deve fechar ao clicar no botão de fechar (X)', () => {
      const closeBtn = fixture.nativeElement.querySelector('#btn-fechar');

      closeBtn.click();

      expect(component.isOpen).toBe(false);
    });

    it('deve fechar ao clicar no botão Cancelar', () => {
      const cancelBtn = fixture.nativeElement.querySelector('#btn-cancelar');

      cancelBtn.click();

      expect(component.isOpen).toBe(false);
    });

    it('deve chamar confirm() ao clicar no botão de confirmação', () => {
      jest.spyOn(component, 'confirm');

      const confirmBtn = fixture.nativeElement.querySelector('#btn-confirmar');

      confirmBtn.click();

      expect(component.confirm).toHaveBeenCalledTimes(1);
    });

    it('deve emitir confirmed ao clicar no botão de confirmação', () => {
      jest.spyOn(component.confirmed, 'emit');

      const confirmBtn = fixture.nativeElement.querySelector('#btn-confirmar');

      confirmBtn.click();

      expect(component.confirmed.emit).toHaveBeenCalledTimes(1);
    });

    it('deve renderizar o atributo aria-modal="true" no modal-box', () => {
      const dialog = fixture.nativeElement.querySelector('[aria-modal="true"]');

      expect(dialog).not.toBeNull();
    });
  });
});
