import { Component, computed, input, signal } from '@angular/core';
import { LucideArrowDown, LucideCircleAlert, LucideX } from '@lucide/angular';
import { BaseModal } from '@shared/directives/base-modal';
import { ErroImportacao } from '../../models/resultado-importacao.model';

@Component({
  selector: 'app-modal-relatorio-erros',
  imports: [LucideX, LucideArrowDown, LucideCircleAlert],
  templateUrl: './modal-relatorio-erros.component.html',
  styleUrl: './modal-relatorio-erros.component.scss',
})
export class ModalRelatorioErrosComponent extends BaseModal {
  erros = input<ErroImportacao[]>([]);
  ordemCrescente = signal(true);

  errosOrdenados = computed(() =>
    [...this.erros()].sort((a, b) =>
      this.ordemCrescente() ? a.linha - b.linha : b.linha - a.linha
    )
  );

  override open(): void {
    this.ordemCrescente.set(true);
    super.open();
  }

  toggleOrdem(): void {
    this.ordemCrescente.update(v => !v);
  }
}
