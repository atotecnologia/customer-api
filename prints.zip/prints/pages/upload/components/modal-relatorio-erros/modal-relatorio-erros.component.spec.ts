import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ModalRelatorioErrosComponent } from './modal-relatorio-erros.component';
import { ErroImportacao } from '../../models/resultado-importacao.model';

const ERROS_MOCK: ErroImportacao[] = [
  { linha: 2, coluna: 'A', descricao: 'Valor inválido' },
  { linha: 5, coluna: 'C', descricao: 'Campo obrigatório' },
  { linha: 10, coluna: 'B', descricao: 'Formato incorreto' },
];

describe('ModalRelatorioErrosComponent', () => {
  let component: ModalRelatorioErrosComponent;
  let fixture: ComponentFixture<ModalRelatorioErrosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ModalRelatorioErrosComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ModalRelatorioErrosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    document.body.style.overflow = '';
  });

  it('deve criar o componente corretamente', () => {
    expect(component).toBeTruthy();
  });

  describe('dado o estado inicial', () => {
    it('deve iniciar com a lista de erros vazia', () => {
      expect(component.erros()).toEqual([]);
    });

    it('não deve renderizar o overlay quando fechado', () => {
      const overlay = fixture.nativeElement.querySelector('#modal-relatorio-erros');

      expect(overlay).toBeNull();
    });
  });

  describe('dado o método open()', () => {
    it('deve renderizar o overlay após abrir', () => {
      component.open();
      fixture.detectChanges();

      const overlay = fixture.nativeElement.querySelector('#modal-relatorio-erros');

      expect(overlay).not.toBeNull();
    });

    it('deve renderizar o modal-box após abrir', () => {
      component.open();
      fixture.detectChanges();

      const modalBox = fixture.nativeElement.querySelector('#modal-box');

      expect(modalBox).not.toBeNull();
    });

    it('deve resetar a ordenação para crescente ao abrir', () => {
      component.toggleOrdem();
      expect(component.ordemCrescente()).toBe(false);

      component.open();

      expect(component.ordemCrescente()).toBe(true);
    });
  });

  describe('dado o método close()', () => {
    it('deve remover o overlay após fechar', () => {
      component.open();
      fixture.detectChanges();

      component.close();
      fixture.detectChanges();

      const overlay = fixture.nativeElement.querySelector('#modal-relatorio-erros');

      expect(overlay).toBeNull();
    });
  });

  describe('dado o input erros', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('erros', ERROS_MOCK);
      component.open();
      fixture.detectChanges();
    });

    it('deve exibir a contagem correta de erros no sumário', () => {
      const summarySpan = fixture.nativeElement.querySelector('#error-summary span');

      expect(summarySpan.textContent.trim()).toBe('3 erros encontrados');
    });

    it('deve renderizar uma linha na tabela para cada erro', () => {
      const rows = fixture.nativeElement.querySelectorAll('tbody tr');

      expect(rows.length).toBe(3);
    });

    it('deve renderizar o número da linha corretamente em ordem crescente', () => {
      const rows = fixture.nativeElement.querySelectorAll('tbody tr');

      expect(rows[0].cells[0].textContent.trim()).toBe('2');
      expect(rows[1].cells[0].textContent.trim()).toBe('5');
      expect(rows[2].cells[0].textContent.trim()).toBe('10');
    });

    it('deve renderizar a coluna corretamente', () => {
      const rows = fixture.nativeElement.querySelectorAll('tbody tr');

      expect(rows[0].cells[1].textContent.trim()).toBe('A');
      expect(rows[1].cells[1].textContent.trim()).toBe('C');
      expect(rows[2].cells[1].textContent.trim()).toBe('B');
    });

    it('deve renderizar a descrição dentro de um badge', () => {
      const badges = fixture.nativeElement.querySelectorAll('tbody .cruz-badge');

      expect(badges[0].textContent.trim()).toBe('Valor inválido');
      expect(badges[1].textContent.trim()).toBe('Campo obrigatório');
      expect(badges[2].textContent.trim()).toBe('Formato incorreto');
    });

    it('deve atualizar a contagem ao receber nova lista de erros', () => {
      fixture.componentRef.setInput('erros', [{ linha: 1, coluna: 'A', descricao: 'Erro único' }]);
      fixture.detectChanges();

      const summarySpan = fixture.nativeElement.querySelector('#error-summary span');

      expect(summarySpan.textContent.trim()).toBe('1 erros encontrados');
    });
  });

  describe('dado erros com lista vazia', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('erros', []);
      component.open();
      fixture.detectChanges();
    });

    it('deve exibir "0 erros encontrados" no sumário', () => {
      const summarySpan = fixture.nativeElement.querySelector('#error-summary span');

      expect(summarySpan.textContent.trim()).toBe('0 erros encontrados');
    });

    it('não deve renderizar linhas na tabela', () => {
      const rows = fixture.nativeElement.querySelectorAll('tbody tr');

      expect(rows.length).toBe(0);
    });
  });

  describe('dado o método toggleOrdem()', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('erros', ERROS_MOCK);
      component.open();
      fixture.detectChanges();
    });

    it('deve iniciar com ordemCrescente = true ao abrir', () => {
      expect(component.ordemCrescente()).toBe(true);
    });

    it('deve alternar para decrescente ao chamar toggleOrdem()', () => {
      component.toggleOrdem();

      expect(component.ordemCrescente()).toBe(false);
    });

    it('deve retornar para crescente ao chamar toggleOrdem() duas vezes', () => {
      component.toggleOrdem();
      component.toggleOrdem();

      expect(component.ordemCrescente()).toBe(true);
    });

    it('deve ordenar linhas de forma decrescente após toggleOrdem()', () => {
      component.toggleOrdem();
      fixture.detectChanges();

      const rows = fixture.nativeElement.querySelectorAll('tbody tr');

      expect(rows[0].cells[0].textContent.trim()).toBe('10');
      expect(rows[1].cells[0].textContent.trim()).toBe('5');
      expect(rows[2].cells[0].textContent.trim()).toBe('2');
    });

    it('deve restaurar ordem crescente após dois toggles', () => {
      component.toggleOrdem();
      component.toggleOrdem();
      fixture.detectChanges();

      const rows = fixture.nativeElement.querySelectorAll('tbody tr');

      expect(rows[0].cells[0].textContent.trim()).toBe('2');
      expect(rows[1].cells[0].textContent.trim()).toBe('5');
      expect(rows[2].cells[0].textContent.trim()).toBe('10');
    });
  });

  describe('interações via DOM', () => {
    beforeEach(() => {
      component.open();
      fixture.detectChanges();
    });

    it('deve fechar ao clicar no botão de fechar (X)', () => {
      const btnFechar = fixture.nativeElement.querySelector('#btn-fechar');

      btnFechar.click();

      expect(component.isOpen).toBe(false);
    });

    it('deve fechar ao clicar no botão Entendi', () => {
      const btnEntendi = fixture.nativeElement.querySelector('#btn-entendi');

      btnEntendi.click();

      expect(component.isOpen).toBe(false);
    });

    it('deve renderizar o atributo aria-modal="true" no modal-box', () => {
      const dialog = fixture.nativeElement.querySelector('[aria-modal="true"]');

      expect(dialog).not.toBeNull();
    });
  });
});
