import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ModalOrientacoesComponent } from './modal-orientacoes.component';

describe('ModalOrientacoesComponent', () => {
  let component: ModalOrientacoesComponent;
  let fixture: ComponentFixture<ModalOrientacoesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ModalOrientacoesComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ModalOrientacoesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    document.body.style.overflow = '';
  });

  it('deve criar o componente corretamente', () => {
    expect(component).toBeTruthy();
  });

  describe('estado inicial', () => {
    it('não deve renderizar o modal quando isOpen é false', () => {
      const overlay = fixture.nativeElement.querySelector('#modal-orientacoes');

      expect(overlay).toBeNull();
    });
  });

  describe('open()', () => {
    it('deve renderizar o modal após abrir', () => {
      component.open();
      fixture.detectChanges();

      const overlay = fixture.nativeElement.querySelector('#modal-orientacoes');

      expect(overlay).not.toBeNull();
    });
  });

  describe('close()', () => {
    it('deve remover o modal do DOM após fechar', () => {
      component.open();
      fixture.detectChanges();

      component.close();
      fixture.detectChanges();

      const overlay = fixture.nativeElement.querySelector('#modal-orientacoes');

      expect(overlay).toBeNull();
    });
  });

  describe('botões de fechar', () => {
    beforeEach(() => {
      component.open();
      fixture.detectChanges();
    });

    it('deve chamar close() ao clicar no botão X', () => {
      jest.spyOn(component, 'close');

      fixture.nativeElement.querySelector('#btn-fechar').click();

      expect(component.close).toHaveBeenCalled();
    });

    it('deve chamar close() ao clicar no botão "Entendi"', () => {
      jest.spyOn(component, 'close');

      fixture.nativeElement.querySelector('#btn-entendi').click();

      expect(component.close).toHaveBeenCalled();
    });
  });
});
