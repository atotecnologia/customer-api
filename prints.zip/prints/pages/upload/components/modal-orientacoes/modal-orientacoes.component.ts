import { Component, Input } from '@angular/core';
import { LucideX } from '@lucide/angular';
import { BaseModal } from '@shared/directives/base-modal';

@Component({
  selector: 'app-modal-orientacoes',
  imports: [LucideX],
  templateUrl: './modal-orientacoes.component.html',
  styleUrl: './modal-orientacoes.component.scss',
})
export class ModalOrientacoesComponent extends BaseModal {
  @Input() extensoesValidasFormatada!: string;
  @Input() tamanhoMaxArquivoFormatado!: string;
}
