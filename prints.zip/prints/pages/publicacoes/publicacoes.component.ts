import { Component, computed, DestroyRef, inject, OnInit, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import {
  LucideCircleX,
  LucideFileText,
  LucideCloudUpload,
  LucideClock4,
  LucideCloudCheck,
  LucideCircleAlert,
} from '@lucide/angular';
import {
  PublicacaoService,
  STATUS_PUBLICACAO_INDISPONIVEL,
} from '@app/core/services/publicacao/publicacao.service';
import { ErrorStateComponent } from '@app/shared/components/error-state/error-state';
import { HttpErrorResponse } from '@angular/common/http';
import { MinhasPublicacoes, StatusPublicacao } from '@app/shared/models/publicacao.model';
import { AuthService } from '@app/core/services/auth/auth.service';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { ModalNovoCicloComponent } from './components/modal-novo-ciclo/modal-novo-ciclo.component';
import { ModalRelatorioErrosComponent } from './components/modal-relatorio-erros/modal-relatorio-erros.component';

type StatusView = 'vazio' | 'pendente' | 'publicando' | 'sucesso' | 'erro' | 'erro-sistema';

@Component({
  selector: 'app-publicacoes',
  imports: [
    DatePipe,
    ErrorStateComponent,
    ModalNovoCicloComponent,
    ModalRelatorioErrosComponent,
    LucideCircleX,
    LucideFileText,
    LucideCloudUpload,
    LucideClock4,
    LucideCloudCheck,
    LucideCircleAlert,
  ],
  templateUrl: './publicacoes.component.html',
  styleUrl: './publicacoes.component.scss',
})
export class PublicacoesComponent implements OnInit {
  private readonly publicacaoService = inject(PublicacaoService);
  private readonly authService = inject(AuthService);
  private readonly router = inject(Router);
  private readonly destroyRef = inject(DestroyRef);

  exibirErroCarregamento = signal(false);
  exibirOverlayPublicando = signal(false);
  /** Guarda de reentrância: bloqueia disparos duplicados de publicação (ex.: duplo-clique). */
  publicacaoEmAndamento = signal(false);
  /**
   * Ativado após `publicarCiclo()` completar. Impede que emissões do polling de outro usuário
   * sobrescrevam o estado terminal (sucesso/erro) enquanto o usuário permanece na tela.
   * Resetado ao sair via `direcionarUpload()` ou `direcionarHistorico()`.
   */
  publicouCicloAtual = signal(false);
  private readonly cicloPublicadoImportacaoId = signal<number | null>(null);
  private verificandoTerminal = false;

  statusView = signal<StatusView>('vazio');
  cicloAtual = signal<StatusPublicacao | null>(null);
  publicacoes = signal<MinhasPublicacoes[]>([]);

  podePublicar = computed(() => {
    const ciclo = this.cicloAtual();
    const usuario = this.authService.currentUserProfile();
    if (!ciclo || !usuario) return true;
    return ciclo.realizadoPorOid !== usuario.oid;
  });

  ngOnInit(): void {
    this.observarStatusPublicacao();
    this.loadPublicacoes();
  }

  direcionarUpload(): void {
    this.publicouCicloAtual.set(false);
    this.cicloPublicadoImportacaoId.set(null);
    this.router.navigate(['/app/upload']);
  }

  direcionarHistorico(): void {
    this.publicouCicloAtual.set(false);
    this.cicloPublicadoImportacaoId.set(null);
    this.router.navigate(['/app/historico']);
  }

  recarregarPagina(): void {
    globalThis.location.reload();
  }

  iniciarPublicacao(): void {
    // Bloqueia reentrância: sem esta guarda, um duplo-clique agendaria dois disparos e o backend
    // poderia receber POSTs concorrentes de publicação.
    if (this.publicacaoEmAndamento()) {
      return;
    }

    this.publicacaoEmAndamento.set(true);
    this.exibirOverlayPublicando.set(true);

    setTimeout(() => {
      this.exibirOverlayPublicando.set(false);
      this.publicar();
    }, 1500);
  }

  private publicar(): void {
    const ciclo = this.cicloAtual();

    // Revalida o estado no momento do disparo: durante o overlay, o polling pode ter atualizado o
    // ciclo para EM_PUBLICACAO/PUBLICADO (outra sessão/aba). Evita um POST redundante que voltaria 409.
    if (!ciclo || ciclo.status === 'EM_PUBLICACAO' || ciclo.status === 'PUBLICADO') {
      this.publicacaoEmAndamento.set(false);
      this.processarStatusPublicacao();
      return;
    }

    this.statusView.set('publicando');

    this.publicacaoService.publicarCiclo(ciclo.importacaoId).subscribe({
      next: res => {
        // O service reinicia o polling após publicar; as próximas atualizações chegam pelo stream.
        this.cicloAtual.set(res.data);
        this.processarStatusPublicacao();
        this.publicouCicloAtual.set(true);
        this.cicloPublicadoImportacaoId.set(ciclo.importacaoId);
        this.publicacaoEmAndamento.set(false);
      },
      error: (err: HttpErrorResponse) => {
        this.publicacaoEmAndamento.set(false);

        // 409: já existe uma publicação em andamento para este ciclo. Não é erro fatal de página —
        // reavalia o estado real via polling e mantém a UI consistente.
        if (err.status === 409) {
          this.publicacaoService.reiniciarConsultaStatus();
          this.processarStatusPublicacao();
          return;
        }

        this.exibirErroCarregamento.set(true);
        this.handleError('Publicação', err);
      },
    });
  }

  /**
   * Acompanha o stream compartilhado de status (polling adaptativo no PublicacaoService): emissão
   * imediata na assinatura, cadência curta enquanto EM_PUBLICACAO e ociosa nos demais estados.
   * Recarrega publicações quando uma publicação em andamento atinge estado terminal.
   */
  private observarStatusPublicacao(): void {
    this.publicacaoService
      .observarStatusPublicacao()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(res => {
        if (res.status === STATUS_PUBLICACAO_INDISPONIVEL) {
          // Sem dado já carregado não há o que exibir: mostra o estado de erro da página.
          if (!this.cicloAtual()) {
            this.exibirErroCarregamento.set(true);
          }
          return;
        }

        // Enquanto publicouCicloAtual estiver ativo, ignora emissões de ciclos diferentes do publicado.
        // Se ainda em 'publicando', verifica via histórico se o ciclo publicado atingiu estado terminal.
        if (
          this.publicouCicloAtual() &&
          res.data !== null &&
          res.data.importacaoId !== this.cicloPublicadoImportacaoId()
        ) {
          if (this.statusView() === 'publicando' && !this.verificandoTerminal) {
            this.verificarTerminalCicloPublicado();
          }
          return;
        }

        // Após publicar, protege estado terminal contra emissões de outro usuário.
        const estadosTerminais: StatusView[] = ['sucesso', 'erro', 'erro-sistema'];
        if (this.publicouCicloAtual() && estadosTerminais.includes(this.statusView())) {
          return;
        }

        // Após publicar, null indica que nosso registro concluiu (o backend filtra PUBLICADO do
        // stream). Força sucesso em vez de mostrar a tela vazia.
        if (this.publicouCicloAtual() && res.data === null) {
          this.statusView.set('sucesso');
          this.loadPublicacoes();
          return;
        }

        const statusAnterior = this.cicloAtual()?.status;

        this.cicloAtual.set(res.data);
        this.processarStatusPublicacao();

        if (statusAnterior === 'EM_PUBLICACAO' && res.data?.status !== 'EM_PUBLICACAO') {
          this.loadPublicacoes();
        }
      });
  }

  private processarStatusPublicacao(): void {
    const status = this.cicloAtual()?.status;

    switch (status) {
      case 'PENDENTE':
        this.statusView.set('pendente');
        break;
      case 'EM_PUBLICACAO':
        this.statusView.set('publicando');
        break;
      case 'PUBLICADO':
        this.statusView.set('sucesso');
        break;
      case 'INVALIDO':
        this.statusView.set('erro');
        break;
      case 'ERRO_SISTEMA':
        this.statusView.set('erro-sistema');
        break;
      default:
        this.statusView.set('vazio');
    }
  }

  private verificarTerminalCicloPublicado(): void {
    const targetId = this.cicloPublicadoImportacaoId();
    this.verificandoTerminal = true;
    this.publicacaoService
      .obterPublicacoesRecentes()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: publicacoes => {
          this.verificandoTerminal = false;
          const pub = publicacoes.find(p => p.importacaoId === targetId);
          if (pub) {
            let terminalView: StatusView = 'erro';
            if (pub.status === 'PUBLICADO') terminalView = 'sucesso';
            else if (pub.status === 'ERRO_SISTEMA') terminalView = 'erro-sistema';
            this.statusView.set(terminalView);
            this.publicacoes.set(publicacoes);
          }
        },
        error: () => {
          this.verificandoTerminal = false;
        },
      });
  }

  private loadPublicacoes(): void {
    this.publicacaoService
      .obterPublicacoesRecentes()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: publicacoes => {
          this.publicacoes.set(publicacoes);
        },
        error: (err: HttpErrorResponse) => {
          this.handleError('Publicações', err);
        },
      });
  }

  private handleError(origem: string, erro: HttpErrorResponse): void {
    console.error(`[${origem}] Erro ao processar ${origem}`, erro.error);
  }
}
