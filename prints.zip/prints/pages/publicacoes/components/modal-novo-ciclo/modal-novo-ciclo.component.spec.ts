import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ModalNovoCicloComponent } from './modal-novo-ciclo.component';

describe('ModalNovoCicloComponent', () => {
  let component: ModalNovoCicloComponent;
  let fixture: ComponentFixture<ModalNovoCicloComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ModalNovoCicloComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ModalNovoCicloComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    document.body.style.overflow = '';
  });

  it('deve criar o componente corretamente', () => {
    expect(component).toBeTruthy();
  });

  describe('dado o método confirm()', () => {
    it('deve emitir o evento confirmed', () => {
      jest.spyOn(component.confirmed, 'emit');

      component.confirm();

      expect(component.confirmed.emit).toHaveBeenCalledTimes(1);
    });

    it('deve fechar o modal após confirmar', () => {
      component.isOpen = true;

      component.confirm();

      expect(component.isOpen).toBe(false);
    });
  });

  describe('interações via DOM', () => {
    beforeEach(() => {
      component.open();
      fixture.detectChanges();
    });

    it('deve chamar confirm() ao clicar no botão de confirmação', () => {
      jest.spyOn(component, 'confirm');

      const confirmBtn = fixture.nativeElement.querySelector('#modal-confirmacao-confirmar');
      confirmBtn.click();

      expect(component.confirm).toHaveBeenCalledTimes(1);
    });

    it('deve emitir confirmed ao clicar no botão de confirmação', () => {
      jest.spyOn(component.confirmed, 'emit');

      const confirmBtn = fixture.nativeElement.querySelector('#modal-confirmacao-confirmar');
      confirmBtn.click();

      expect(component.confirmed.emit).toHaveBeenCalledTimes(1);
    });
  });
});
