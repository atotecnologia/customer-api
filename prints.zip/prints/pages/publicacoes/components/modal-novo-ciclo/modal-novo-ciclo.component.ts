import { Component, output } from '@angular/core';
import { BaseModal } from '@app/shared/directives/base-modal';
import { LucideX } from '@lucide/angular';

@Component({
  selector: 'app-modal-novo-ciclo',
  imports: [LucideX],
  templateUrl: './modal-novo-ciclo.component.html',
  styleUrl: './modal-novo-ciclo.component.scss',
})
export class ModalNovoCicloComponent extends BaseModal {
  confirmed = output<void>();

  confirm(): void {
    this.confirmed.emit();
    this.close();
  }
}
