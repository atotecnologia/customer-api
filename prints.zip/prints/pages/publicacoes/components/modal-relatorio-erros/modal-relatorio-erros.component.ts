import { Component, input, signal } from '@angular/core';
import { BaseModal } from '@app/shared/directives/base-modal';
import { ErroStatusPublicacao } from '@app/shared/models/publicacao.model';
import { LucideX, LucideCircleAlert, LucideChevronDown } from '@lucide/angular';

@Component({
  selector: 'app-modal-relatorio-erros',
  imports: [LucideX, LucideCircleAlert, LucideChevronDown],
  templateUrl: './modal-relatorio-erros.component.html',
  styleUrl: './modal-relatorio-erros.component.scss',
})
export class ModalRelatorioErrosComponent extends BaseModal {
  erros = input<ErroStatusPublicacao[]>([]);

  isValorDivergenteOpen = signal(false);
  isPrecoNaoCadastradoOpen = signal(false);

  override close(): void {
    this.isValorDivergenteOpen.set(false);
    this.isPrecoNaoCadastradoOpen.set(false);

    super.close();
  }
}
