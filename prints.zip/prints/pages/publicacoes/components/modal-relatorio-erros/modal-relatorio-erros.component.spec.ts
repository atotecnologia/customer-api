import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ErroStatusPublicacao } from '@app/shared/models/publicacao.model';
import { ModalRelatorioErrosComponent } from './modal-relatorio-erros.component';

const errosMock: ErroStatusPublicacao[] = [
  { sku: 'SKU-001', tipo: 'FIN-001', mensagem: 'Valor Divergente' },
  { sku: 'SKU-002', tipo: 'FIN-002', mensagem: 'Preço não cadastrado' },
];

describe('ModalRelatorioErrosComponent', () => {
  let component: ModalRelatorioErrosComponent;
  let fixture: ComponentFixture<ModalRelatorioErrosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ModalRelatorioErrosComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ModalRelatorioErrosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    document.body.style.overflow = '';
  });

  it('deve criar o componente corretamente', () => {
    expect(component).toBeTruthy();
  });

  describe('dado o estado inicial', () => {
    it('deve iniciar isValorDivergenteOpen como false', () => {
      expect(component.isValorDivergenteOpen()).toBe(false);
    });

    it('deve iniciar isPrecoNaoCadastradoOpen como false', () => {
      expect(component.isPrecoNaoCadastradoOpen()).toBe(false);
    });

    it('deve iniciar erros como array vazio', () => {
      expect(component.erros()).toEqual([]);
    });
  });

  describe('dado o método close()', () => {
    it('deve resetar isValorDivergenteOpen para false', () => {
      component.open();
      component.isValorDivergenteOpen.set(true);

      component.close();

      expect(component.isValorDivergenteOpen()).toBe(false);
    });

    it('deve resetar isPrecoNaoCadastradoOpen para false', () => {
      component.open();
      component.isPrecoNaoCadastradoOpen.set(true);

      component.close();

      expect(component.isPrecoNaoCadastradoOpen()).toBe(false);
    });

    it('deve fechar o modal ao chamar o super.close()', () => {
      component.open();

      component.close();

      expect(component.isOpen).toBe(false);
    });
  });

  describe('dado o input erros', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('erros', errosMock);
      component.open();
      fixture.detectChanges();
    });

    it('deve exibir a contagem correta de erros no resumo', () => {
      const summary = fixture.nativeElement.querySelector('#error-summary span');

      expect(summary.textContent).toContain('2 erros encontrados');
    });

    it('deve renderizar uma linha por erro na tabela', () => {
      const rows = fixture.nativeElement.querySelectorAll('tbody tr');

      expect(rows).toHaveLength(errosMock.length);
    });
  });

  describe('dado o accordion Valor Divergente', () => {
    beforeEach(() => {
      component.open();
      fixture.detectChanges();
    });

    it('deve alternar isValorDivergenteOpen para true ao clicar no header', () => {
      const header = fixture.nativeElement.querySelector(
        '#accordion-valor-divergente .accordion__header'
      );

      header.click();

      expect(component.isValorDivergenteOpen()).toBe(true);
    });

    it('deve fechar o accordion ao clicar novamente no header', () => {
      component.isValorDivergenteOpen.set(true);
      fixture.detectChanges();

      const header = fixture.nativeElement.querySelector(
        '#accordion-valor-divergente .accordion__header'
      );

      header.click();
      fixture.detectChanges();

      expect(component.isValorDivergenteOpen()).toBe(false);
    });

    it('deve exibir o conteúdo do accordion quando aberto', () => {
      component.isValorDivergenteOpen.set(true);
      fixture.detectChanges();

      const content = fixture.nativeElement.querySelector(
        '#accordion-valor-divergente .accordion__content'
      );

      expect(content).not.toBeNull();
    });

    it('não deve exibir o conteúdo do accordion quando fechado', () => {
      const content = fixture.nativeElement.querySelector(
        '#accordion-valor-divergente .accordion__content'
      );

      expect(content).toBeNull();
    });

    it('deve aplicar a classe --open no header quando aberto', () => {
      component.isValorDivergenteOpen.set(true);
      fixture.detectChanges();

      const header = fixture.nativeElement.querySelector(
        '#accordion-valor-divergente .accordion__header'
      );

      expect(header.classList).toContain('accordion__header--open');
    });
  });

  describe('dado o accordion Preço não cadastrado', () => {
    beforeEach(() => {
      component.open();
      fixture.detectChanges();
    });

    it('deve alternar isPrecoNaoCadastradoOpen para true ao clicar no header', () => {
      const header = fixture.nativeElement.querySelector(
        '#accordion-preco-nao-cadastrado .accordion__header'
      );

      header.click();

      expect(component.isPrecoNaoCadastradoOpen()).toBe(true);
    });

    it('deve fechar o accordion ao clicar novamente no header', () => {
      component.isPrecoNaoCadastradoOpen.set(true);
      fixture.detectChanges();

      const header = fixture.nativeElement.querySelector(
        '#accordion-preco-nao-cadastrado .accordion__header'
      );

      header.click();
      fixture.detectChanges();

      expect(component.isPrecoNaoCadastradoOpen()).toBe(false);
    });

    it('deve exibir o conteúdo do accordion quando aberto', () => {
      component.isPrecoNaoCadastradoOpen.set(true);
      fixture.detectChanges();

      const content = fixture.nativeElement.querySelector(
        '#accordion-preco-nao-cadastrado .accordion__content'
      );

      expect(content).not.toBeNull();
    });

    it('não deve exibir o conteúdo do accordion quando fechado', () => {
      const content = fixture.nativeElement.querySelector(
        '#accordion-preco-nao-cadastrado .accordion__content'
      );

      expect(content).toBeNull();
    });

    it('deve aplicar a classe --open no header quando aberto', () => {
      component.isPrecoNaoCadastradoOpen.set(true);
      fixture.detectChanges();

      const header = fixture.nativeElement.querySelector(
        '#accordion-preco-nao-cadastrado .accordion__header'
      );

      expect(header.classList).toContain('accordion__header--open');
    });
  });
});
