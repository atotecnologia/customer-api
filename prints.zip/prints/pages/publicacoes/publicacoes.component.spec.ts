import { ComponentFixture, TestBed } from '@angular/core/testing';
import { signal } from '@angular/core';
import { PublicacoesComponent } from './publicacoes.component';
import {
  PublicacaoService,
  STATUS_PUBLICACAO_INDISPONIVEL,
} from '@app/core/services/publicacao/publicacao.service';
import { AuthService } from '@app/core/services/auth/auth.service';
import { throwError, of } from 'rxjs';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { StatusPublicacao } from '@app/shared/models/publicacao.model';
import { User } from '@app/shared/models/user.model';
import {
  obterPublicacoesResponse,
  obterStatusPublicacaoNuloResponse,
  obterStatusPublicacaoResponse,
  publicarCicloResponse,
  statusPublicacaoComStatus,
} from '@shared/mocks/fixtures/publicacao.fixture';

describe('PublicacoesComponent', () => {
  let component: PublicacoesComponent;
  let fixture: ComponentFixture<PublicacoesComponent>;
  let mockPublicacaoService: jest.Mocked<PublicacaoService>;
  let mockRouter: jest.Mocked<Router>;
  let mockUserProfile: ReturnType<typeof signal<User | null>>;

  const erroHttp = new HttpErrorResponse({ status: 500 });

  beforeEach(async () => {
    jest.spyOn(console, 'error').mockImplementation(jest.fn());

    mockUserProfile = signal<User | null>(null);

    const publicacaoServiceSpy = {
      observarStatusPublicacao: jest.fn().mockReturnValue(of(obterStatusPublicacaoNuloResponse())),
      publicarCiclo: jest.fn().mockReturnValue(of(publicarCicloResponse())),
      reiniciarConsultaStatus: jest.fn(),
      obterPublicacoesRecentes: jest.fn().mockReturnValue(of([])),
    };

    const authServiceSpy = { currentUserProfile: mockUserProfile };

    const routerSpy = { navigate: jest.fn() };

    await TestBed.configureTestingModule({
      imports: [PublicacoesComponent],
      providers: [
        { provide: PublicacaoService, useValue: publicacaoServiceSpy },
        { provide: AuthService, useValue: authServiceSpy },
        { provide: Router, useValue: routerSpy },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(PublicacoesComponent);
    component = fixture.componentInstance;
    mockPublicacaoService = TestBed.inject(PublicacaoService) as jest.Mocked<PublicacaoService>;
    mockRouter = TestBed.inject(Router) as jest.Mocked<Router>;
    fixture.detectChanges();
  });

  it('deve criar o componente corretamente', () => {
    expect(component).toBeTruthy();
  });

  describe('dado o método ngOnInit()', () => {
    it('deve assinar o stream de status e carregar publicações ao inicializar', () => {
      expect(mockPublicacaoService.observarStatusPublicacao).toHaveBeenCalledTimes(1);
      expect(mockPublicacaoService.obterPublicacoesRecentes).toHaveBeenCalledTimes(1);
    });

    it('deve definir statusView como "vazio" quando data é null', () => {
      expect(component.statusView()).toBe('vazio');
    });

    const statusTestCases: {
      statusApi: StatusPublicacao['status'];
      statusViewEsperado: string;
    }[] = [
      { statusApi: 'PENDENTE', statusViewEsperado: 'pendente' },
      { statusApi: 'EM_PUBLICACAO', statusViewEsperado: 'publicando' },
      { statusApi: 'PUBLICADO', statusViewEsperado: 'sucesso' },
      { statusApi: 'INVALIDO', statusViewEsperado: 'erro' },
      { statusApi: 'ERRO_SISTEMA', statusViewEsperado: 'erro-sistema' },
    ];

    it.each(statusTestCases)(
      'deve definir statusView como "$statusViewEsperado" quando status da API é $statusApi',
      ({ statusApi, statusViewEsperado }) => {
        mockPublicacaoService.observarStatusPublicacao.mockReturnValue(
          of(statusPublicacaoComStatus(statusApi))
        );

        component.ngOnInit();

        expect(component.statusView()).toBe(statusViewEsperado);
      }
    );

    it('deve definir statusView como "vazio" quando status da API é desconhecido (default)', () => {
      const base = obterStatusPublicacaoResponse();
      mockPublicacaoService.observarStatusPublicacao.mockReturnValue(
        of({ ...base, data: { ...base.data, status: 'DESCONHECIDO' as never } })
      );

      component.ngOnInit();

      expect(component.statusView()).toBe('vazio');
    });

    it('deve preencher cicloAtual com os dados retornados pela API', () => {
      const resposta = obterStatusPublicacaoResponse();
      mockPublicacaoService.observarStatusPublicacao.mockReturnValue(of(resposta));

      component.ngOnInit();

      expect(component.cicloAtual()).toEqual(resposta.data);
    });

    it('deve definir exibirErroCarregamento como true quando a consulta de status falha sem dado carregado', () => {
      mockPublicacaoService.observarStatusPublicacao.mockReturnValue(
        of({ status: STATUS_PUBLICACAO_INDISPONIVEL, message: '', data: null })
      );

      component.ngOnInit();

      expect(component.exibirErroCarregamento()).toBe(true);
    });

    it('não deve exibir erro quando a consulta falha mas já há status carregado', () => {
      mockPublicacaoService.observarStatusPublicacao.mockReturnValue(
        of(statusPublicacaoComStatus('PENDENTE'), {
          status: STATUS_PUBLICACAO_INDISPONIVEL,
          message: '',
          data: null,
        })
      );

      component.ngOnInit();

      expect(component.exibirErroCarregamento()).toBe(false);
      expect(component.statusView()).toBe('pendente');
    });

    it('deve preencher publicacoes com os dados retornados pela API', () => {
      const resposta = obterPublicacoesResponse();
      mockPublicacaoService.obterPublicacoesRecentes.mockReturnValue(of(resposta));

      component.ngOnInit();

      expect(component.publicacoes()).toEqual(resposta);
      expect(component.publicacoes()).toHaveLength(2);
    });

    it('deve manter publicacoes vazio quando obterPublicacoesRecentes falha', () => {
      mockPublicacaoService.obterPublicacoesRecentes.mockReturnValue(throwError(() => erroHttp));

      component.ngOnInit();

      expect(component.publicacoes()).toEqual([]);
    });
  });

  describe('acompanhamento do status pelo stream compartilhado', () => {
    it('deve transitar para estado terminal e recarregar publicações quando a publicação conclui', () => {
      mockPublicacaoService.observarStatusPublicacao.mockReturnValue(
        of(statusPublicacaoComStatus('EM_PUBLICACAO'), statusPublicacaoComStatus('PUBLICADO'))
      );
      mockPublicacaoService.obterPublicacoesRecentes.mockClear();

      component.ngOnInit();

      expect(component.statusView()).toBe('sucesso');
      // 1 chamada do ngOnInit + 1 recarga na transição EM_PUBLICACAO → PUBLICADO
      expect(mockPublicacaoService.obterPublicacoesRecentes).toHaveBeenCalledTimes(2);
    });

    it('não deve recarregar publicações quando o status já chega em estado terminal', () => {
      mockPublicacaoService.observarStatusPublicacao.mockReturnValue(
        of(statusPublicacaoComStatus('PUBLICADO'))
      );
      mockPublicacaoService.obterPublicacoesRecentes.mockClear();

      component.ngOnInit();

      expect(component.statusView()).toBe('sucesso');
      expect(mockPublicacaoService.obterPublicacoesRecentes).toHaveBeenCalledTimes(1);
    });

    it('deve forçar sucesso quando polling retorna null após publicação (backend filtra PUBLICADO)', () => {
      // Simula: publicou, ciclo está em publicando, publicouCicloAtual ativo
      component.statusView.set('publicando');
      component.publicouCicloAtual.set(true);

      // Polling retorna null (nosso registro virou PUBLICADO, backend não retorna mais)
      mockPublicacaoService.observarStatusPublicacao.mockReturnValue(
        of(obterStatusPublicacaoNuloResponse())
      );
      component.ngOnInit();

      expect(component.statusView()).toBe('sucesso');
      expect(mockPublicacaoService.obterPublicacoesRecentes).toHaveBeenCalled();
    });

    it('deve proteger estado sucesso contra emissões de outro usuário após publicação', () => {
      // Após publicar, statusView chega em sucesso via polling
      mockPublicacaoService.observarStatusPublicacao.mockReturnValue(
        of(statusPublicacaoComStatus('PUBLICADO'))
      );
      component.ngOnInit();
      expect(component.statusView()).toBe('sucesso');

      // Marca que o usuário atual publicou e qual ciclo foi publicado (importacaoId=1)
      component.publicouCicloAtual.set(true);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (component as any).cicloPublicadoImportacaoId.set(1);

      // Polling emite PENDENTE do mesmo ciclo (ex.: outro usuário atualizou) — deve permanecer sucesso
      mockPublicacaoService.observarStatusPublicacao.mockReturnValue(
        of(statusPublicacaoComStatus('PENDENTE'))
      );
      component.ngOnInit();

      expect(component.statusView()).toBe('sucesso');
    });

    it('deve manter statusView como "erro" e não sobrescrevê-lo por null do polling após publicação', () => {
      // Publicação concluiu com INVALIDO → statusView = 'erro'
      component.statusView.set('erro');
      component.publicouCicloAtual.set(true);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (component as any).cicloPublicadoImportacaoId.set(1);

      // Polling retorna null (backend removeu o registro do stream)
      mockPublicacaoService.observarStatusPublicacao.mockReturnValue(
        of(obterStatusPublicacaoNuloResponse())
      );
      component.ngOnInit();

      // Deve permanecer 'erro', não virar 'sucesso'
      expect(component.statusView()).toBe('erro');
    });

    it('deve ignorar emissão de ciclo diferente enquanto publicouCicloAtual estiver ativo e chamar histórico para resolver terminal', () => {
      const respostaBase = obterStatusPublicacaoResponse();
      // Usuário publicou o ciclo com importacaoId=1
      component.cicloAtual.set(respostaBase.data);
      component.statusView.set('publicando');
      component.publicouCicloAtual.set(true);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (component as any).cicloPublicadoImportacaoId.set(1);
      mockPublicacaoService.obterPublicacoesRecentes.mockClear();

      // Polling retorna ciclo diferente (importacaoId=2, ciclo 2024.2 PENDENTE)
      const ciclo2 = {
        ...respostaBase,
        data: { ...respostaBase.data, importacaoId: 2, cicloId: '2024.2' },
      };
      // Histórico ainda não tem ciclo 1 como terminal (ainda EM_PUBLICACAO)
      mockPublicacaoService.obterPublicacoesRecentes.mockReturnValue(of([]));
      mockPublicacaoService.observarStatusPublicacao.mockReturnValue(of(ciclo2));
      component.ngOnInit();

      // statusView não deve trocar para 'pendente' do ciclo 2
      expect(component.statusView()).toBe('publicando');
      expect(component.cicloAtual()?.importacaoId).toBe(1);
      // deve ter consultado o histórico para tentar resolver o terminal
      expect(mockPublicacaoService.obterPublicacoesRecentes).toHaveBeenCalled();
    });

    it('deve resolver publicando→sucesso via histórico quando ciclo 1 finaliza com PUBLICADO', () => {
      const respostaBase = obterStatusPublicacaoResponse();
      component.cicloAtual.set(respostaBase.data);
      component.statusView.set('publicando');
      component.publicouCicloAtual.set(true);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (component as any).cicloPublicadoImportacaoId.set(1);

      // Histórico retorna ciclo 1 como PUBLICADO
      const historico = [
        {
          importacaoId: 1,
          cicloId: '2024.1',
          nomeArquivo: 'precos.xlsx',
          status: 'PUBLICADO' as const,
          totalSkus: 100,
          importadoPor: 'a@cruzeirodosul.edu.br',
          publicadoPor: 'b@cruzeirodosul.edu.br',
          dataImportacao: '2024-01-15T10:00:00Z',
          dataPublicacao: '2024-01-16T08:00:00Z',
        },
      ];
      mockPublicacaoService.obterPublicacoesRecentes.mockReturnValue(of(historico));

      // Polling retorna ciclo 2 (outro ciclo PENDENTE)
      const ciclo2 = {
        ...respostaBase,
        data: { ...respostaBase.data, importacaoId: 2, cicloId: '2024.2' },
      };
      mockPublicacaoService.observarStatusPublicacao.mockReturnValue(of(ciclo2));
      component.ngOnInit();

      expect(component.statusView()).toBe('sucesso');
      expect(component.publicacoes()).toEqual(historico);
    });

    it('deve resolver publicando→erro via histórico quando ciclo 1 finaliza com INVALIDO', () => {
      const respostaBase = obterStatusPublicacaoResponse();
      component.cicloAtual.set(respostaBase.data);
      component.statusView.set('publicando');
      component.publicouCicloAtual.set(true);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (component as any).cicloPublicadoImportacaoId.set(1);

      const historico = [
        {
          importacaoId: 1,
          cicloId: '2024.1',
          nomeArquivo: 'precos.xlsx',
          status: 'INVALIDO' as const,
          totalSkus: 100,
          importadoPor: 'a@cruzeirodosul.edu.br',
          publicadoPor: 'b@cruzeirodosul.edu.br',
          dataImportacao: '2024-01-15T10:00:00Z',
          dataPublicacao: '2024-01-16T08:00:00Z',
        },
      ];
      mockPublicacaoService.obterPublicacoesRecentes.mockReturnValue(of(historico));

      const ciclo2 = {
        ...respostaBase,
        data: { ...respostaBase.data, importacaoId: 2, cicloId: '2024.2' },
      };
      mockPublicacaoService.observarStatusPublicacao.mockReturnValue(of(ciclo2));
      component.ngOnInit();

      expect(component.statusView()).toBe('erro');
    });

    it('deve evitar chamadas paralelas ao histórico quando verificandoTerminal está ativo', () => {
      const respostaBase = obterStatusPublicacaoResponse();
      component.cicloAtual.set(respostaBase.data);
      component.statusView.set('publicando');
      component.publicouCicloAtual.set(true);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (component as any).cicloPublicadoImportacaoId.set(1);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (component as any).verificandoTerminal = true; // simula fetch em andamento

      const ciclo2 = {
        ...respostaBase,
        data: { ...respostaBase.data, importacaoId: 2, cicloId: '2024.2' },
      };
      mockPublicacaoService.obterPublicacoesRecentes.mockClear();
      mockPublicacaoService.observarStatusPublicacao.mockReturnValue(of(ciclo2));
      component.ngOnInit();

      // ngOnInit chama loadPublicacoes (1 vez); verificarTerminalCicloPublicado NÃO deve ser chamado
      expect(mockPublicacaoService.obterPublicacoesRecentes).toHaveBeenCalledTimes(1);
    });
  });

  describe('dado o método direcionarUpload()', () => {
    it('deve navegar para /app/upload', () => {
      component.direcionarUpload();

      expect(mockRouter.navigate).toHaveBeenCalledWith(['/app/upload']);
    });

    it('deve resetar publicouCicloAtual ao navegar para upload', () => {
      component.publicouCicloAtual.set(true);

      component.direcionarUpload();

      expect(component.publicouCicloAtual()).toBe(false);
    });
  });

  describe('dado o método direcionarHistorico()', () => {
    it('deve navegar para /app/historico', () => {
      component.direcionarHistorico();

      expect(mockRouter.navigate).toHaveBeenCalledWith(['/app/historico']);
    });
  });

  describe('dado o método iniciarPublicacao()', () => {
    beforeEach(() => {
      jest.useFakeTimers();

      mockPublicacaoService.observarStatusPublicacao.mockReturnValue(
        of(obterStatusPublicacaoResponse())
      );

      component.ngOnInit();
    });

    afterAll(() => {
      jest.useRealTimers();
    });

    it('deve exibir o overlay de publicando imediatamente', () => {
      component.iniciarPublicacao();

      expect(component.exibirOverlayPublicando()).toBe(true);

      jest.runAllTimers();
    });

    it('deve ocultar o overlay e chamar publicarCiclo com o importacaoId correto', () => {
      const { importacaoId } = obterStatusPublicacaoResponse().data;

      component.iniciarPublicacao();
      jest.runAllTimers();

      expect(component.exibirOverlayPublicando()).toBe(false);
      expect(mockPublicacaoService.publicarCiclo).toHaveBeenCalledWith(importacaoId);
    });

    it('deve atualizar cicloAtual, definir statusView como "publicando" e ativar publicouCicloAtual após publicação bem-sucedida', () => {
      const respostaPublicacao = publicarCicloResponse();

      component.iniciarPublicacao();
      jest.runAllTimers();

      expect(component.cicloAtual()).toEqual(respostaPublicacao.data);
      expect(component.statusView()).toBe('publicando');
      expect(component.publicouCicloAtual()).toBe(true);
    });

    it('deve definir exibirErroCarregamento como true quando publicarCiclo falha', () => {
      mockPublicacaoService.publicarCiclo.mockReturnValue(throwError(() => erroHttp));

      component.iniciarPublicacao();
      jest.runAllTimers();

      expect(component.exibirErroCarregamento()).toBe(true);
    });

    it('não deve chamar publicarCiclo quando cicloAtual é null', () => {
      component.cicloAtual.set(null);

      component.iniciarPublicacao();
      jest.runAllTimers();

      expect(mockPublicacaoService.publicarCiclo).not.toHaveBeenCalled();
    });

    it('deve disparar publicarCiclo apenas uma vez mesmo com cliques repetidos (guarda de reentrância)', () => {
      component.iniciarPublicacao();
      component.iniciarPublicacao();
      component.iniciarPublicacao();
      jest.runAllTimers();

      expect(mockPublicacaoService.publicarCiclo).toHaveBeenCalledTimes(1);
    });

    it('não deve chamar publicarCiclo quando o ciclo já está EM_PUBLICACAO no disparo', () => {
      component.cicloAtual.set(statusPublicacaoComStatus('EM_PUBLICACAO').data);

      component.iniciarPublicacao();
      jest.runAllTimers();

      expect(mockPublicacaoService.publicarCiclo).not.toHaveBeenCalled();
      expect(component.statusView()).toBe('publicando');
      expect(component.publicacaoEmAndamento()).toBe(false);
    });

    it('deve tratar 409 sem erro fatal, reavaliando o status e liberando a guarda', () => {
      mockPublicacaoService.publicarCiclo.mockReturnValue(
        throwError(() => new HttpErrorResponse({ status: 409 }))
      );

      component.iniciarPublicacao();
      jest.runAllTimers();

      expect(component.exibirErroCarregamento()).toBe(false);
      expect(mockPublicacaoService.reiniciarConsultaStatus).toHaveBeenCalledTimes(1);
      expect(component.publicacaoEmAndamento()).toBe(false);
    });
  });

  describe('dado o computed podePublicar', () => {
    const cicloBase = obterStatusPublicacaoResponse().data;

    it('deve retornar true quando não há ciclo carregado', () => {
      expect(component.podePublicar()).toBe(true);
    });

    it('deve retornar true quando não há usuário logado', () => {
      component.cicloAtual.set(cicloBase);
      mockUserProfile.set(null);
      fixture.detectChanges();

      expect(component.podePublicar()).toBe(true);
    });

    it('deve retornar false quando o OID do usuário logado é igual ao OID de quem importou', () => {
      const usuario: User = {
        oid: cicloBase.realizadoPorOid,
        nome: cicloBase.realizadoPor,
        email: 'usuario@cruzeirodosul.edu.br',
        grupos: [],
      };
      component.cicloAtual.set(cicloBase);
      mockUserProfile.set(usuario);
      fixture.detectChanges();

      expect(component.podePublicar()).toBe(false);
    });

    it('deve retornar true quando o OID do usuário logado é diferente de quem importou', () => {
      const usuario: User = {
        oid: 'oid-outro-usuario',
        nome: 'Outro Usuário',
        email: 'outro@cruzeirodosul.edu.br',
        grupos: [],
      };
      component.cicloAtual.set(cicloBase);
      mockUserProfile.set(usuario);
      fixture.detectChanges();

      expect(component.podePublicar()).toBe(true);
    });
  });
});
