import { Component, OnInit, inject } from '@angular/core';
import { Router } from '@angular/router';
import { Spinner } from '@app/shared/components/spinner/spinner';
import { OidcSecurityService } from 'angular-auth-oidc-client';

@Component({
  selector: 'app-callback',
  standalone: true,
  imports: [Spinner],
  template: `
    <div class="callback-container">
      <app-spinner />
    </div>
  `,
  styles: [
    `
      .callback-container {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        width: 100%;
      }
    `,
  ],
})
export class CallbackComponent implements OnInit {
  private readonly oidcSecurityService = inject(OidcSecurityService);
  private readonly router = inject(Router);

  ngOnInit() {
    this.oidcSecurityService.checkAuth().subscribe(({ isAuthenticated }) => {
      if (isAuthenticated) {
        this.router.navigate(['/app/dashboard']);
      } else {
        this.router.navigate(['/login']);
      }
    });
  }
}
