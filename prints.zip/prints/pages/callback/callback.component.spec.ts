import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { OidcSecurityService } from 'angular-auth-oidc-client';
import { of } from 'rxjs';
import { CallbackComponent } from './callback.component';

describe('CallbackComponent', () => {
  let component: CallbackComponent;
  let fixture: ComponentFixture<CallbackComponent>;
  let oidcSecurityServiceMock: jest.Mocked<Pick<OidcSecurityService, 'checkAuth'>>;
  let routerMock: jest.Mocked<Pick<Router, 'navigate'>>;

  beforeEach(async () => {
    oidcSecurityServiceMock = {
      checkAuth: jest.fn(),
    };

    routerMock = {
      navigate: jest.fn(),
    };

    await TestBed.configureTestingModule({
      imports: [CallbackComponent],
      providers: [
        { provide: OidcSecurityService, useValue: oidcSecurityServiceMock },
        { provide: Router, useValue: routerMock },
      ],
    }).compileComponents();
  });

  const createComponent = () => {
    fixture = TestBed.createComponent(CallbackComponent);
    component = fixture.componentInstance;
  };

  it('deve criar o componente corretamente', () => {
    oidcSecurityServiceMock.checkAuth.mockReturnValue(of({ isAuthenticated: false } as any));
    createComponent();
    fixture.detectChanges();

    expect(component).toBeTruthy();
  });

  it('deve navegar para /app/dashboard quando autenticado', () => {
    oidcSecurityServiceMock.checkAuth.mockReturnValue(of({ isAuthenticated: true } as any));
    createComponent();
    fixture.detectChanges();

    expect(routerMock.navigate).toHaveBeenCalledWith(['/app/dashboard']);
  });

  it('deve navegar para /login quando não autenticado', () => {
    oidcSecurityServiceMock.checkAuth.mockReturnValue(of({ isAuthenticated: false } as any));
    createComponent();
    fixture.detectChanges();

    expect(routerMock.navigate).toHaveBeenCalledWith(['/login']);
  });

  it('deve chamar checkAuth no ngOnInit', () => {
    oidcSecurityServiceMock.checkAuth.mockReturnValue(of({ isAuthenticated: false } as any));
    createComponent();
    fixture.detectChanges();

    expect(oidcSecurityServiceMock.checkAuth).toHaveBeenCalledTimes(1);
  });
});
