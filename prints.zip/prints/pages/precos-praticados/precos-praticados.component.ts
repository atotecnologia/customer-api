import { Component, computed, DestroyRef, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { LucideSearch } from '@lucide/angular';
import { DropdownComponent } from '@shared/components/dropdown/dropdown';
import { EMPTY, Subject, switchMap, tap, timer } from 'rxjs';

@Component({
  selector: 'app-precos-praticados',
  standalone: true,
  imports: [DropdownComponent, LucideSearch],
  templateUrl: './precos-praticados.component.html',
  styleUrl: './precos-praticados.component.scss',
})
export class PrecosPraticadosComponent {
  private readonly destroyRef = inject(DestroyRef);
  private readonly buscar$ = new Subject<void>();

  readonly cicloSelecionado = signal<string | null>(null);
  readonly empresaSelecionada = signal('Todas');
  readonly busca = signal('');
  readonly carregando = signal(false);
  readonly resultados = signal<unknown[]>([]);

  readonly opcoesCiclos = ['2026.2', '2026.1', '2025.2', '2025.1'];
  readonly opcoesEmpresas = ['Todas', 'UNICSUL', 'UNICID'];
  readonly skeletonRows = Array(7);

  readonly filtroAplicado = computed(() => !!this.cicloSelecionado());
  readonly semResultados = computed(
    () => this.filtroAplicado() && !this.carregando() && this.resultados().length === 0
  );

  constructor() {
    this.buscar$
      .pipe(
        switchMap(() => {
          if (!this.cicloSelecionado()) {
            this.carregando.set(false);
            this.resultados.set([]);
            return EMPTY;
          }

          this.carregando.set(true);
          return timer(800).pipe(
            tap(() => {
              this.resultados.set([]);
              this.carregando.set(false);
            })
          );
        }),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe();
  }

  onCicloChange(ciclo: string): void {
    this.cicloSelecionado.set(ciclo);
    this.buscar$.next();
  }

  onEmpresaChange(empresa: string): void {
    this.empresaSelecionada.set(empresa);
    this.buscar$.next();
  }

  onBuscaChange(valor: string): void {
    this.busca.set(valor);
    this.buscar$.next();
  }
}
