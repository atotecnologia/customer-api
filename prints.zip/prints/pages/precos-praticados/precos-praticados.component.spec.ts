import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { PrecosPraticadosComponent } from './precos-praticados.component';

describe('PrecosPraticadosComponent', () => {
  let component: PrecosPraticadosComponent;
  let fixture: ComponentFixture<PrecosPraticadosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PrecosPraticadosComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(PrecosPraticadosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('deve criar o componente', () => {
    expect(component).toBeTruthy();
  });

  it('deve exibir empty state quando nenhum ciclo está selecionado', () => {
    const emptyState = fixture.nativeElement.querySelector('.cruz-empty-state');
    expect(emptyState).toBeTruthy();
    expect(emptyState.textContent).toContain('Nenhum filtro aplicado');
    expect(emptyState.textContent).toContain(
      'Selecione um ciclo acima para consultar os preços praticados.'
    );
  });

  it('deve exibir skeleton ao alterar o ciclo', fakeAsync(() => {
    component.onCicloChange('2026.1');
    fixture.detectChanges();

    expect(component.carregando()).toBe(true);
    expect(fixture.nativeElement.querySelector('.precos-praticados-skeleton')).toBeTruthy();
    expect(fixture.nativeElement.querySelectorAll('.skeleton-row').length).toBe(7);

    tick(800);
    fixture.detectChanges();

    expect(component.carregando()).toBe(false);
    expect(fixture.nativeElement.querySelector('.precos-praticados-skeleton')).toBeFalsy();
  }));

  it('deve exibir estado sem resultados após a busca', fakeAsync(() => {
    component.onCicloChange('2026.1');
    tick(800);
    fixture.detectChanges();

    expect(component.semResultados()).toBe(true);
    const emptyState = fixture.nativeElement.querySelector('.cruz-empty-state');
    expect(emptyState.textContent).toContain('Não encontramos resultados.');
    expect(emptyState.textContent).toContain('Ajuste os filtros e tente novamente.');
  }));

  it('deve ter as opções de ciclo e empresa conforme o print', () => {
    expect(component.opcoesCiclos).toEqual(['2026.2', '2026.1', '2025.2', '2025.1']);
    expect(component.opcoesEmpresas).toEqual(['Todas', 'UNICSUL', 'UNICID']);
    expect(component.empresaSelecionada()).toBe('Todas');
  });

  it('deve atualizar empresa selecionada e disparar busca', fakeAsync(() => {
    component.onCicloChange('2026.2');
    tick(800);

    component.onEmpresaChange('UNICSUL');
    expect(component.empresaSelecionada()).toBe('UNICSUL');
    expect(component.carregando()).toBe(true);

    tick(800);
    expect(component.carregando()).toBe(false);
  }));

  it('deve atualizar o texto de busca', fakeAsync(() => {
    component.onCicloChange('2026.1');
    tick(800);

    component.onBuscaChange('Cinema');
    expect(component.busca()).toBe('Cinema');
    expect(component.carregando()).toBe(true);

    tick(800);
    expect(component.carregando()).toBe(false);
  }));

  it('deve exibir título e subtítulo da página', () => {
    const titulo = fixture.nativeElement.querySelector('.cruz-page-title__title');
    const subtitulo = fixture.nativeElement.querySelector('.cruz-page-title__subtitle');

    expect(titulo.textContent.trim()).toBe('Preços praticados');
    expect(subtitulo.textContent).toContain(
      'Consulte o preço que está valendo em cada ponto de venda'
    );
  });

  it('deve renderizar os três filtros', () => {
    const labels = Array.from(
      fixture.nativeElement.querySelectorAll('.filtro-grupo__label') as NodeListOf<HTMLElement>
    ).map(el => el.textContent?.trim());

    expect(labels).toContain('Obrigatório');
    expect(labels).toContain('Opcional');
    expect(fixture.nativeElement.querySelector('.filtro-busca__input')).toBeTruthy();
  });
});
