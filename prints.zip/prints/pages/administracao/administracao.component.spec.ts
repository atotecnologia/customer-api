import { Component, Input } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdministracaoComponent } from './administracao.component';
import { AbaGruposComponent } from './components/aba-grupos/aba-grupos.component';
import { AbaPerfisComponent } from './components/aba-perfis/aba-perfis.component';
import { GrupoResumo } from '@shared/models/administracao.model';

@Component({ selector: 'app-aba-grupos', standalone: true, template: '' })
class AbaGruposStub {}

@Component({ selector: 'app-aba-perfis', standalone: true, template: '' })
class AbaPerfisStub {
  @Input() grupoFiltroInicial: string | null = null;
}

describe('AdministracaoComponent', () => {
  let component: AdministracaoComponent;
  let fixture: ComponentFixture<AdministracaoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdministracaoComponent],
    })
      .overrideComponent(AdministracaoComponent, {
        remove: { imports: [AbaGruposComponent, AbaPerfisComponent] },
        add: { imports: [AbaGruposStub, AbaPerfisStub] },
      })
      .compileComponents();

    fixture = TestBed.createComponent(AdministracaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('deve criar o componente', () => {
    expect(component).toBeTruthy();
  });

  it('deve iniciar com aba grupos ativa', () => {
    expect(component.abaAtiva()).toBe('grupos');
  });

  it('deve iniciar com grupoFiltroPreSelecionado nulo', () => {
    expect(component.grupoFiltroPreSelecionado()).toBeNull();
  });

  it('deve trocar para aba perfis ao chamar selecionarAba com "perfis"', () => {
    component.selecionarAba('perfis');
    expect(component.abaAtiva()).toBe('perfis');
  });

  it('deve limpar grupoFiltroPreSelecionado ao trocar de aba', () => {
    const grupoDummy: GrupoResumo = {
      id: 'admin_geral',
      nome: 'admin_geral',
      descricao: 'Administrador',
      totalUsuarios: 1,
    };
    component.irParaPerfisComFiltro(grupoDummy);
    expect(component.grupoFiltroPreSelecionado()).toBe('admin_geral');

    component.selecionarAba('grupos');
    expect(component.grupoFiltroPreSelecionado()).toBeNull();
  });

  it('deve nao trocar aba quando a aba solicitada ja esta ativa', () => {
    component.selecionarAba('grupos');
    expect(component.abaAtiva()).toBe('grupos');
  });

  it('deve definir grupoFiltroPreSelecionado e mudar para aba perfis ao chamar irParaPerfisComFiltro', () => {
    const grupo: GrupoResumo = {
      id: 'analista_precificacao',
      nome: 'analista_precificacao',
      descricao: 'Analista de Precificação',
      totalUsuarios: 3,
    };

    component.irParaPerfisComFiltro(grupo);

    expect(component.grupoFiltroPreSelecionado()).toBe('analista_precificacao');
    expect(component.abaAtiva()).toBe('perfis');
  });
});
