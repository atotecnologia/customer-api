import {
  Component,
  computed,
  DestroyRef,
  EventEmitter,
  inject,
  OnInit,
  Output,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { AdministracaoService } from '@core/services/administracao/administracao.service';
import { ErrorStateComponent } from '@shared/components/error-state/error-state';
import { GrupoResumo } from '@shared/models/administracao.model';
import { GrupoLabelPipe, grupoLabel } from '@shared/pipes/grupo-label.pipe';

type Estado = 'loading' | 'success' | 'error';

@Component({
  selector: 'app-aba-grupos',
  standalone: true,
  imports: [FormsModule, ErrorStateComponent, GrupoLabelPipe],
  templateUrl: './aba-grupos.component.html',
  styleUrl: './aba-grupos.component.scss',
})
export class AbaGruposComponent implements OnInit {
  @Output() grupoClicado = new EventEmitter<GrupoResumo>();

  private readonly service = inject(AdministracaoService);
  private readonly destroyRef = inject(DestroyRef);

  readonly estado = signal<Estado>('loading');
  readonly grupos = signal<GrupoResumo[]>([]);
  readonly termoBusca = signal('');
  readonly skeletonRows = Array(4);

  readonly gruposFiltrados = computed(() => {
    const termo = this.termoBusca().toLowerCase().trim();
    if (!termo) return this.grupos();
    return this.grupos().filter(
      g =>
        g.nome.toLowerCase().includes(termo) ||
        g.descricao.toLowerCase().includes(termo) ||
        grupoLabel(g.nome).toLowerCase().includes(termo)
    );
  });

  ngOnInit(): void {
    this.carregarGrupos();
  }

  carregarGrupos(): void {
    this.estado.set('loading');
    this.service
      .listarGrupos()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: grupos => {
          this.grupos.set(grupos);
          this.estado.set('success');
        },
        error: () => this.estado.set('error'),
      });
  }

  onGrupoClick(grupo: GrupoResumo): void {
    this.grupoClicado.emit(grupo);
  }
}
