import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of, throwError, NEVER } from 'rxjs';
import { AbaGruposComponent } from './aba-grupos.component';
import { AdministracaoService } from '@core/services/administracao/administracao.service';
import { GrupoResumo } from '@shared/models/administracao.model';

const GRUPOS_MOCK: GrupoResumo[] = [
  { id: 'admin_geral', nome: 'admin_geral', descricao: 'Administrador Geral', totalUsuarios: 3 },
  {
    id: 'analista_precificacao',
    nome: 'analista_precificacao',
    descricao: 'Analista de Precificação',
    totalUsuarios: 7,
  },
  {
    id: 'leitor_basico',
    nome: 'leitor_basico',
    descricao: 'Leitor Básico',
    totalUsuarios: 12,
  },
];

describe('AbaGruposComponent', () => {
  let component: AbaGruposComponent;
  let fixture: ComponentFixture<AbaGruposComponent>;
  let mockService: { listarGrupos: jest.Mock };

  beforeEach(async () => {
    mockService = { listarGrupos: jest.fn() };

    await TestBed.configureTestingModule({
      imports: [AbaGruposComponent],
      providers: [{ provide: AdministracaoService, useValue: mockService }],
    }).compileComponents();
  });

  function criarFixture(): void {
    fixture = TestBed.createComponent(AbaGruposComponent);
    component = fixture.componentInstance;
  }

  it('deve criar o componente', () => {
    mockService.listarGrupos.mockReturnValue(of(GRUPOS_MOCK));
    criarFixture();
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('deve exibir estado de carregamento inicialmente', () => {
    mockService.listarGrupos.mockReturnValue(NEVER);
    criarFixture();
    fixture.detectChanges();
    expect(component.estado()).toBe('loading');
  });

  it('deve exibir grupos apos carregamento bem-sucedido', () => {
    mockService.listarGrupos.mockReturnValue(of(GRUPOS_MOCK));
    criarFixture();
    fixture.detectChanges();

    expect(component.estado()).toBe('success');
    expect(component.grupos()).toEqual(GRUPOS_MOCK);
  });

  it('deve exibir estado de erro quando servico falha', () => {
    mockService.listarGrupos.mockReturnValue(throwError(() => new Error('falha de rede')));
    criarFixture();
    fixture.detectChanges();

    expect(component.estado()).toBe('error');
  });

  it('deve recarregar grupos ao chamar carregarGrupos novamente', () => {
    mockService.listarGrupos.mockReturnValue(throwError(() => new Error('falha')));
    criarFixture();
    fixture.detectChanges();
    expect(component.estado()).toBe('error');

    mockService.listarGrupos.mockReturnValue(of(GRUPOS_MOCK));
    component.carregarGrupos();
    expect(component.estado()).toBe('success');
  });

  describe('gruposFiltrados (computed)', () => {
    beforeEach(() => {
      mockService.listarGrupos.mockReturnValue(of(GRUPOS_MOCK));
      criarFixture();
      fixture.detectChanges();
    });

    it('deve retornar todos os grupos quando termoBusca esta vazio', () => {
      expect(component.gruposFiltrados()).toHaveLength(3);
    });

    it('deve filtrar grupos pelo nome', () => {
      component.termoBusca.set('admin');
      expect(component.gruposFiltrados()).toHaveLength(1);
      expect(component.gruposFiltrados()[0].id).toBe('admin_geral');
    });

    it('deve filtrar grupos pela descricao', () => {
      component.termoBusca.set('Leitor');
      expect(component.gruposFiltrados()).toHaveLength(1);
      expect(component.gruposFiltrados()[0].id).toBe('leitor_basico');
    });

    it('deve retornar lista vazia quando termoBusca nao tem correspondencia', () => {
      component.termoBusca.set('xyz-inexistente');
      expect(component.gruposFiltrados()).toHaveLength(0);
    });
  });

  it('deve emitir grupoClicado ao chamar onGrupoClick', () => {
    mockService.listarGrupos.mockReturnValue(of(GRUPOS_MOCK));
    criarFixture();
    fixture.detectChanges();

    const grupo = GRUPOS_MOCK[0];
    const emitSpy = jest.spyOn(component.grupoClicado, 'emit');

    component.onGrupoClick(grupo);

    expect(emitSpy).toHaveBeenCalledWith(grupo);
  });
});
