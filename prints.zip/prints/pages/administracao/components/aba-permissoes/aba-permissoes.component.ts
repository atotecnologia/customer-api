import { Component, computed, DestroyRef, inject, OnInit, signal, ViewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { AdministracaoService } from '@core/services/administracao/administracao.service';
import { NotificationService } from '@core/services/notification/notification.service';
import { ErrorStateComponent } from '@shared/components/error-state/error-state';
import {
  AlteracaoPermissao,
  CelulaPermissao,
  MatrizPermissoes,
} from '@shared/models/administracao.model';
import { ModalHistoricoPermissoesComponent } from './modal-historico-permissoes/modal-historico-permissoes.component';
import { PermissaoIconeComponent } from './permissao-icone/permissao-icone.component';

type EstadoAba = 'loading' | 'leitura' | 'edicao' | 'salvando' | 'error';

@Component({
  selector: 'app-aba-permissoes',
  standalone: true,
  imports: [ErrorStateComponent, ModalHistoricoPermissoesComponent, PermissaoIconeComponent],
  templateUrl: './aba-permissoes.component.html',
  styleUrl: './aba-permissoes.component.scss',
})
export class AbaPermissoesComponent implements OnInit {
  @ViewChild(ModalHistoricoPermissoesComponent)
  modalHistorico!: ModalHistoricoPermissoesComponent;

  private readonly service = inject(AdministracaoService);
  private readonly notifications = inject(NotificationService);
  private readonly destroyRef = inject(DestroyRef);

  readonly estado = signal<EstadoAba>('loading');
  readonly matrizOriginal = signal<MatrizPermissoes | null>(null);
  readonly matrizEditada = signal<MatrizPermissoes | null>(null);
  readonly skeletonRows = Array(5);
  readonly skeletonCols = Array(5);

  readonly estaEditando = computed(
    () => this.estado() === 'edicao' || this.estado() === 'salvando'
  );

  readonly alteracoesAcumuladas = computed<AlteracaoPermissao[]>(() => {
    const original = this.matrizOriginal();
    const editada = this.matrizEditada();
    if (!original || !editada) return [];

    const alteracoes: AlteracaoPermissao[] = [];
    for (const linhaEditada of editada.permissoes) {
      const linhaOriginal = original.permissoes.find(p => p.roleNome === linhaEditada.roleNome);
      if (!linhaOriginal) continue;

      for (const grupoId of Object.keys(linhaEditada.celulas)) {
        const celulaOriginal = linhaOriginal.celulas[grupoId];
        const celulaEditada = linhaEditada.celulas[grupoId];
        if (celulaOriginal?.editavel && celulaOriginal.estado !== celulaEditada.estado) {
          alteracoes.push({
            grupoId,
            roleNome: linhaEditada.roleNome,
            conceder: celulaEditada.estado === 'CONCEDIDA',
          });
        }
      }
    }
    return alteracoes;
  });

  ngOnInit(): void {
    this.carregar();
  }

  carregar(): void {
    this.estado.set('loading');
    this.service
      .obterMatrizPermissoes()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: matriz => {
          this.matrizOriginal.set(matriz);
          this.matrizEditada.set(null);
          this.estado.set('leitura');
        },
        error: () => this.estado.set('error'),
      });
  }

  entrarEdicao(): void {
    const original = this.matrizOriginal();
    if (!original) return;
    this.matrizEditada.set(this.clonarMatriz(original));
    this.estado.set('edicao');
  }

  cancelarEdicao(): void {
    this.matrizEditada.set(null);
    this.estado.set('leitura');
  }

  toggleCelula(grupoId: string, roleNome: string): void {
    const editada = this.matrizEditada();
    if (!editada) return;

    const linha = editada.permissoes.find(p => p.roleNome === roleNome);
    const celula = linha?.celulas[grupoId];
    if (!celula?.editavel) return;

    const novoEstado = celula.estado === 'CONCEDIDA' ? 'NEGADA' : 'CONCEDIDA';
    const novaMatriz = this.clonarMatriz(editada);
    const novaLinha = novaMatriz.permissoes.find(p => p.roleNome === roleNome)!;
    novaLinha.celulas[grupoId] = { ...celula, estado: novoEstado };
    this.matrizEditada.set(novaMatriz);
  }

  salvar(): void {
    const alteracoes = this.alteracoesAcumuladas();
    if (!alteracoes.length) {
      this.cancelarEdicao();
      return;
    }

    this.estado.set('salvando');
    this.service
      .salvarMatrizPermissoes(alteracoes)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => {
          this.notifications.success(
            'As ações foram associadas ao perfil de acesso.',
            'Permissões alteradas com sucesso!'
          );
          this.carregar();
        },
        error: () => {
          this.notifications.error(
            'Suas alterações não foram salvas. Tente novamente em alguns instantes.',
            'Não foi possível inserir ações.'
          );
          this.estado.set('edicao');
        },
      });
  }

  abrirHistorico(): void {
    this.modalHistorico.abrirECarregar();
  }

  getCelula(grupoId: string, roleNome: string): CelulaPermissao | undefined {
    const matriz = this.estaEditando() ? this.matrizEditada() : this.matrizOriginal();
    return matriz?.permissoes.find(p => p.roleNome === roleNome)?.celulas[grupoId];
  }

  private clonarMatriz(matriz: MatrizPermissoes): MatrizPermissoes {
    return {
      grupos: [...matriz.grupos],
      permissoes: matriz.permissoes.map(linha => ({
        ...linha,
        celulas: Object.fromEntries(Object.entries(linha.celulas).map(([k, v]) => [k, { ...v }])),
      })),
    };
  }
}
