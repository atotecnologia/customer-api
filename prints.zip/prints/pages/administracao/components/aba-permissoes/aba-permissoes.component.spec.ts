import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of, throwError } from 'rxjs';
import { AbaPermissoesComponent } from './aba-permissoes.component';
import { AdministracaoService } from '@core/services/administracao/administracao.service';
import { NotificationService } from '@core/services/notification/notification.service';
import { MatrizPermissoes } from '@shared/models/administracao.model';

const matrizMock: MatrizPermissoes = {
  grupos: [
    { id: 'grupo-1', nome: 'Administrador' },
    { id: 'grupo-2', nome: 'Analista' },
  ],
  permissoes: [
    {
      roleNome: 'View_report',
      descricao: 'Visualizar relatórios',
      celulas: {
        'grupo-1': { estado: 'CONCEDIDA', editavel: false },
        'grupo-2': { estado: 'CONCEDIDA', editavel: true },
      },
    },
    {
      roleNome: 'Edit_pricing',
      descricao: 'Editar precificação',
      celulas: {
        'grupo-1': { estado: 'CONCEDIDA', editavel: false },
        'grupo-2': { estado: 'NEGADA', editavel: true },
      },
    },
  ],
};

describe('AbaPermissoesComponent', () => {
  let fixture: ComponentFixture<AbaPermissoesComponent>;
  let component: AbaPermissoesComponent;
  let mockService: jest.Mocked<Partial<AdministracaoService>>;
  let mockNotification: jest.Mocked<Partial<NotificationService>>;

  beforeEach(async () => {
    mockService = {
      obterMatrizPermissoes: jest.fn().mockReturnValue(of(matrizMock)),
      salvarMatrizPermissoes: jest.fn().mockReturnValue(of(void 0)),
      obterHistoricoPermissoes: jest.fn().mockReturnValue(of([])),
    };

    mockNotification = {
      success: jest.fn(),
      error: jest.fn(),
    };

    await TestBed.configureTestingModule({
      imports: [AbaPermissoesComponent],
      providers: [
        { provide: AdministracaoService, useValue: mockService },
        { provide: NotificationService, useValue: mockNotification },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(AbaPermissoesComponent);
    component = fixture.componentInstance;
  });

  it('deve exibir skeleton durante carregamento', () => {
    mockService.obterMatrizPermissoes = jest.fn().mockReturnValue(of(matrizMock));
    expect(component.estado()).toBe('loading');
  });

  it('deve exibir error-state quando serviço falha', () => {
    mockService.obterMatrizPermissoes = jest
      .fn()
      .mockReturnValue(throwError(() => new Error('Erro de rede')));
    fixture.detectChanges();
    expect(component.estado()).toBe('error');
  });

  it('deve carregar e exibir a matriz', () => {
    fixture.detectChanges();
    expect(component.estado()).toBe('leitura');
    expect(component.matrizOriginal()).toEqual(matrizMock);
  });

  it('deve entrar em modo de edição ao acionar entrarEdicao', () => {
    fixture.detectChanges();
    component.entrarEdicao();
    expect(component.estado()).toBe('edicao');
    expect(component.matrizEditada()).not.toBeNull();
    expect(component.estaEditando()).toBe(true);
  });

  it('deve cancelar edição e restaurar estado original', () => {
    fixture.detectChanges();
    component.entrarEdicao();
    component.cancelarEdicao();
    expect(component.estado()).toBe('leitura');
    expect(component.matrizEditada()).toBeNull();
    expect(component.estaEditando()).toBe(false);
  });

  it('deve acumular alterações ao fazer toggle de célula editável', () => {
    fixture.detectChanges();
    component.entrarEdicao();
    component.toggleCelula('grupo-2', 'Edit_pricing');
    const alteracoes = component.alteracoesAcumuladas();
    expect(alteracoes).toHaveLength(1);
    expect(alteracoes[0]).toEqual({ grupoId: 'grupo-2', roleNome: 'Edit_pricing', conceder: true });
  });

  it('deve ignorar toggle em célula não editável', () => {
    fixture.detectChanges();
    component.entrarEdicao();
    component.toggleCelula('grupo-1', 'View_report');
    expect(component.alteracoesAcumuladas()).toHaveLength(0);
  });

  it('deve chamar salvarMatrizPermissoes com alterações acumuladas', () => {
    fixture.detectChanges();
    component.entrarEdicao();
    component.toggleCelula('grupo-2', 'Edit_pricing');
    component.salvar();
    expect(mockService.salvarMatrizPermissoes).toHaveBeenCalledWith([
      { grupoId: 'grupo-2', roleNome: 'Edit_pricing', conceder: true },
    ]);
  });

  it('deve exibir toast de sucesso e recarregar após salvar', () => {
    mockService.salvarMatrizPermissoes = jest.fn().mockReturnValue(of(void 0));
    fixture.detectChanges();
    component.entrarEdicao();
    component.toggleCelula('grupo-2', 'Edit_pricing');
    component.salvar();
    expect(mockNotification.success).toHaveBeenCalled();
  });

  it('deve exibir toast de erro e manter modo edição quando salvar falha', () => {
    mockService.salvarMatrizPermissoes = jest
      .fn()
      .mockReturnValue(throwError(() => new Error('Erro ao salvar')));
    fixture.detectChanges();
    component.entrarEdicao();
    component.toggleCelula('grupo-2', 'Edit_pricing');
    component.salvar();
    expect(mockNotification.error).toHaveBeenCalled();
    expect(component.estado()).toBe('edicao');
  });

  it('deve cancelar sem chamar serviço quando não há alterações', () => {
    fixture.detectChanges();
    component.entrarEdicao();
    component.salvar();
    expect(mockService.salvarMatrizPermissoes).not.toHaveBeenCalled();
    expect(component.estado()).toBe('leitura');
  });

  it('deve retornar célula correta via getCelula em modo leitura', () => {
    fixture.detectChanges();
    const celula = component.getCelula('grupo-2', 'View_report');
    expect(celula).toEqual({ estado: 'CONCEDIDA', editavel: true });
  });
});
