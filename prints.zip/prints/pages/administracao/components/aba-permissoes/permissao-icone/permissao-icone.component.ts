import { Component, Input } from '@angular/core';

const ROLE_ICON_MAP: Record<string, string> = {
  View_report: '/images/analytics.svg',
  View_candidate: '/images/eye.svg',
  Edit_pricing: '/images/settings.svg',
  Approve_cycle: '/images/refresh.svg',
  Group_management: '/images/users.svg',
};

@Component({
  selector: 'app-permissao-icone',
  standalone: true,
  template: `
    @if (iconSrc) {
      <img
        [src]="iconSrc"
        width="16"
        height="16"
        aria-hidden="true"
        alt=""
        class="permissao-icone-img" />
    }
  `,
  styles: [
    `
      :host {
        display: inline-flex;
        align-items: center;
        flex-shrink: 0;
        margin-top: 1px;
      }

      .permissao-icone-img {
        display: block;
        opacity: 0.65;
      }
    `,
  ],
})
export class PermissaoIconeComponent {
  @Input({ required: true }) set roleNome(value: string) {
    this.iconSrc = ROLE_ICON_MAP[value] ?? null;
  }

  iconSrc: string | null = null;
}
