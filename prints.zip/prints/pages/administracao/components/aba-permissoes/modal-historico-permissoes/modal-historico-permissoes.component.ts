import { Component, DestroyRef, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { DatePipe } from '@angular/common';
import { AdministracaoService } from '@core/services/administracao/administracao.service';
import { ErrorStateComponent } from '@shared/components/error-state/error-state';
import { BaseModal } from '@shared/directives/base-modal';
import { HistoricoPermissao } from '@shared/models/administracao.model';

type Estado = 'loading' | 'success' | 'error';

@Component({
  selector: 'app-modal-historico-permissoes',
  standalone: true,
  imports: [DatePipe, ErrorStateComponent],
  templateUrl: './modal-historico-permissoes.component.html',
  styleUrl: './modal-historico-permissoes.component.scss',
})
export class ModalHistoricoPermissoesComponent extends BaseModal {
  private readonly service = inject(AdministracaoService);
  // Nome diferente de 'destroyRef' para não colidir com o campo private da classe base
  private readonly selfDestroyRef = inject(DestroyRef);

  readonly estado = signal<Estado>('loading');
  readonly historico = signal<HistoricoPermissao[]>([]);

  abrirECarregar(): void {
    this.open();
    this.carregar();
  }

  carregar(): void {
    this.estado.set('loading');
    this.service
      .obterHistoricoPermissoes()
      .pipe(takeUntilDestroyed(this.selfDestroyRef))
      .subscribe({
        next: lista => {
          this.historico.set(lista);
          this.estado.set('success');
        },
        error: () => this.estado.set('error'),
      });
  }
}
