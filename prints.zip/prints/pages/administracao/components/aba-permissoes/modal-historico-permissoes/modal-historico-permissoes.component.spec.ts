import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of, throwError } from 'rxjs';
import { ModalHistoricoPermissoesComponent } from './modal-historico-permissoes.component';
import { AdministracaoService } from '@core/services/administracao/administracao.service';
import { HistoricoPermissao } from '@shared/models/administracao.model';
import { ScrollLockService } from '@core/scroll-lock/scroll-lock.service';

const historicoMock: HistoricoPermissao[] = [
  {
    dataHora: '2026-09-08T14:00:00Z',
    perfil: 'Analista',
    permissao: 'Editar precificação',
    acao: 'ADICIONADA',
    responsavel: 'usuario@empresa.com',
  },
  {
    dataHora: '2026-09-07T10:30:00Z',
    perfil: 'Suporte',
    permissao: 'Visualizar relatórios',
    acao: 'REMOVIDA',
    responsavel: 'admin@empresa.com',
  },
];

describe('ModalHistoricoPermissoesComponent', () => {
  let fixture: ComponentFixture<ModalHistoricoPermissoesComponent>;
  let component: ModalHistoricoPermissoesComponent;
  let mockService: jest.Mocked<Partial<AdministracaoService>>;
  let mockScrollLock: jest.Mocked<Partial<ScrollLockService>>;

  beforeEach(async () => {
    mockService = {
      obterHistoricoPermissoes: jest.fn().mockReturnValue(of(historicoMock)),
    };

    mockScrollLock = {
      lock: jest.fn(),
      unlock: jest.fn(),
    };

    await TestBed.configureTestingModule({
      imports: [ModalHistoricoPermissoesComponent],
      providers: [
        { provide: AdministracaoService, useValue: mockService },
        { provide: ScrollLockService, useValue: mockScrollLock },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(ModalHistoricoPermissoesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('deve abrir o modal e carregar histórico ao chamar abrirECarregar', () => {
    component.abrirECarregar();
    expect(component.isOpen).toBe(true);
    expect(mockService.obterHistoricoPermissoes).toHaveBeenCalled();
    expect(component.historico()).toEqual(historicoMock);
    expect(component.estado()).toBe('success');
  });

  it('deve exibir lista de registros quando há dados', () => {
    component.abrirECarregar();
    expect(component.historico()).toHaveLength(2);
    expect(component.historico()[0].perfil).toBe('Analista');
  });

  it('deve exibir empty-state quando histórico está vazio', () => {
    mockService.obterHistoricoPermissoes = jest.fn().mockReturnValue(of([]));
    component.abrirECarregar();
    expect(component.historico()).toHaveLength(0);
    expect(component.estado()).toBe('success');
  });

  it('deve exibir error-state quando serviço falha', () => {
    mockService.obterHistoricoPermissoes = jest
      .fn()
      .mockReturnValue(throwError(() => new Error('Erro de rede')));
    component.abrirECarregar();
    expect(component.estado()).toBe('error');
  });

  it('deve fechar o modal ao chamar close', () => {
    component.abrirECarregar();
    expect(component.isOpen).toBe(true);
    component.close();
    expect(component.isOpen).toBe(false);
    expect(mockScrollLock.unlock).toHaveBeenCalled();
  });

  it('deve reiniciar estado para loading ao chamar carregar novamente', () => {
    component.abrirECarregar();
    expect(component.estado()).toBe('success');
    component.carregar();
    expect(component.estado()).toBe('success');
    expect(mockService.obterHistoricoPermissoes).toHaveBeenCalledTimes(2);
  });
});
