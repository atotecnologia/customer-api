import {
  Component,
  computed,
  DestroyRef,
  inject,
  Input,
  OnChanges,
  OnInit,
  signal,
  SimpleChanges,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { AdministracaoService } from '@core/services/administracao/administracao.service';
import { ErrorStateComponent } from '@shared/components/error-state/error-state';
import { GrupoResumo, PaginatedResult, UsuarioPerfil } from '@shared/models/administracao.model';
import { PaginationInfo } from '@shared/models/pagination-info.model';
import { GrupoLabelPipe, grupoLabel, LABEL_TO_ID } from '@shared/pipes/grupo-label.pipe';

type Estado = 'loading' | 'success' | 'error';

@Component({
  selector: 'app-aba-perfis',
  standalone: true,
  imports: [FormsModule, ErrorStateComponent, GrupoLabelPipe],
  templateUrl: './aba-perfis.component.html',
  styleUrl: './aba-perfis.component.scss',
})
export class AbaPerfisComponent implements OnInit, OnChanges {
  @Input() grupoFiltroInicial: string | null = null;

  private readonly service = inject(AdministracaoService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly searchSubject = new Subject<string>();

  readonly estado = signal<Estado>('loading');
  readonly usuarios = signal<UsuarioPerfil[]>([]);
  readonly paginacao = signal<PaginationInfo | null>(null);
  readonly grupos = signal<GrupoResumo[]>([]);
  readonly gruposSelecionados = signal<string[]>([]);

  readonly totalGruposSelecionados = computed(() => this.gruposSelecionados().length);

  readonly dropdownAberto = signal<boolean>(false);

  readonly sortBy = signal<'nome' | 'email'>('nome');
  readonly sortDir = signal<'asc' | 'desc'>('asc');

  readonly labelBotaoGrupo = computed(() => {
    const sel = this.gruposSelecionados();
    if (sel.length === 0) return 'Todos os grupos';
    if (sel.length === 1) {
      const descricao = this.grupos().find(g => g.id === sel[0])?.descricao;
      return descricao ? grupoLabel(descricao) : 'Todos os grupos';
    }
    return `${sel.length} grupos`;
  });

  toggleDropdown(): void {
    this.dropdownAberto.update(v => !v);
  }

  toggleSort(coluna: 'nome' | 'email'): void {
    if (this.sortBy() === coluna) {
      this.sortDir.update(d => (d === 'asc' ? 'desc' : 'asc'));
    } else {
      this.sortBy.set(coluna);
      this.sortDir.set('asc');
    }
    this.paginaAtual.set(0);
    this.carregar();
  }

  readonly termoBusca = signal('');

  readonly filtrosAtivos = computed(
    () => this.termoBusca().trim() !== '' || this.gruposSelecionados().length > 0
  );

  readonly paginaAtual = signal(0);
  readonly pageSize = signal(10);
  readonly pageSizeOptions = [10, 20, 50];
  readonly skeletonRows = Array(5);

  ngOnInit(): void {
    this.carregarGrupos();

    this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged(), takeUntilDestroyed(this.destroyRef))
      .subscribe(() => {
        this.paginaAtual.set(0);
        this.carregar();
      });
  }

  ngOnChanges(changes: SimpleChanges): void {
    const novoFiltro = changes['grupoFiltroInicial']?.currentValue;
    if (novoFiltro !== null && novoFiltro !== undefined) {
      this.gruposSelecionados.set([novoFiltro]);
      this.paginaAtual.set(0);
      this.carregar();
    }
  }

  private carregarGrupos(): void {
    this.service
      .listarGrupos()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: grupos => {
          this.grupos.set(grupos);
          this.carregar();
        },
        error: () => this.carregar(),
      });
  }

  carregar(): void {
    this.estado.set('loading');
    const termo = this.termoBusca().trim();
    const grupoIdPorLabel = LABEL_TO_ID[termo.toLowerCase()];
    const grupoIds = this.gruposSelecionados();
    let grupoIdsFiltrados: string[] | undefined;
    if (grupoIdPorLabel) {
      grupoIdsFiltrados = [...new Set([...grupoIds, grupoIdPorLabel])];
    } else if (grupoIds.length) {
      grupoIdsFiltrados = grupoIds;
    }

    this.service
      .listarUsuarios({
        search: grupoIdPorLabel ? undefined : termo || undefined,
        grupoIds: grupoIdsFiltrados,
        page: this.paginaAtual(),
        pageSize: this.pageSize(),
        sortBy: this.sortBy(),
        sortDir: this.sortDir(),
      })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (result: PaginatedResult<UsuarioPerfil>) => {
          this.usuarios.set(result.content);
          this.paginacao.set(result.pagination);
          this.estado.set('success');
        },
        error: () => this.estado.set('error'),
      });
  }

  onBuscaChange(valor: string): void {
    this.termoBusca.set(valor);
    this.searchSubject.next(valor);
  }

  isGrupoSelecionado(id: string): boolean {
    return this.gruposSelecionados().includes(id);
  }

  onToggleGrupo(id: string): void {
    const atual = this.gruposSelecionados();
    if (atual.includes(id)) {
      this.gruposSelecionados.set(atual.filter(g => g !== id));
    } else {
      this.gruposSelecionados.set([...atual, id]);
    }
    this.paginaAtual.set(0);
    this.carregar();
  }

  limparGrupos(): void {
    this.gruposSelecionados.set([]);
    this.paginaAtual.set(0);
    this.carregar();
  }

  irParaPagina(pagina: number): void {
    const total = this.paginacao()?.totalPages ?? 0;
    if (pagina < 0 || pagina >= total) return;
    this.paginaAtual.set(pagina);
    this.carregar();
  }

  alterarPageSize(size: number): void {
    this.pageSize.set(size);
    this.paginaAtual.set(0);
    this.carregar();
  }
}
