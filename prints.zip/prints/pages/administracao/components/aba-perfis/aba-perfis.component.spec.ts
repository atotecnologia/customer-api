import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SimpleChange } from '@angular/core';
import { of, throwError, NEVER } from 'rxjs';
import { AbaPerfisComponent } from './aba-perfis.component';
import { AdministracaoService } from '@core/services/administracao/administracao.service';
import { GrupoResumo, PaginatedResult, UsuarioPerfil } from '@shared/models/administracao.model';

const GRUPOS_MOCK: GrupoResumo[] = [
  { id: 'admin_geral', nome: 'admin_geral', descricao: 'Administrador Geral', totalUsuarios: 2 },
  {
    id: 'analista_precificacao',
    nome: 'analista_precificacao',
    descricao: 'Analista de Precificação',
    totalUsuarios: 5,
  },
];

const USUARIOS_PAGINADOS: PaginatedResult<UsuarioPerfil> = {
  content: [
    { nome: 'Ana Souza', email: 'ana@cruzeiro.com', grupos: ['admin_geral'] },
    { nome: 'Bruno Lima', email: 'bruno@cruzeiro.com', grupos: ['analista_precificacao'] },
  ],
  pagination: { page: 0, pageSize: 10, totalPages: 1, totalElements: 2 },
};

describe('AbaPerfisComponent', () => {
  let component: AbaPerfisComponent;
  let fixture: ComponentFixture<AbaPerfisComponent>;
  let mockService: { listarGrupos: jest.Mock; listarUsuarios: jest.Mock };

  beforeEach(async () => {
    mockService = {
      listarGrupos: jest.fn().mockReturnValue(of(GRUPOS_MOCK)),
      listarUsuarios: jest.fn().mockReturnValue(of(USUARIOS_PAGINADOS)),
    };

    await TestBed.configureTestingModule({
      imports: [AbaPerfisComponent],
      providers: [{ provide: AdministracaoService, useValue: mockService }],
    }).compileComponents();

    fixture = TestBed.createComponent(AbaPerfisComponent);
    component = fixture.componentInstance;
  });

  it('deve criar o componente', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('deve iniciar com estado de carregamento', () => {
    expect(component.estado()).toBe('loading');
  });

  it('deve carregar grupos e usuarios no ngOnInit', () => {
    fixture.detectChanges();

    expect(mockService.listarGrupos).toHaveBeenCalledTimes(1);
    expect(mockService.listarUsuarios).toHaveBeenCalledTimes(1);
    expect(component.grupos()).toEqual(GRUPOS_MOCK);
    expect(component.usuarios()).toEqual(USUARIOS_PAGINADOS.content);
    expect(component.estado()).toBe('success');
  });

  it('deve exibir estado de erro quando listarUsuarios falha', () => {
    mockService.listarUsuarios.mockReturnValue(throwError(() => new Error('falha')));
    fixture.detectChanges();

    expect(component.estado()).toBe('error');
  });

  it('deve manter estado de carregamento quando listarUsuarios nao responde', () => {
    mockService.listarGrupos.mockReturnValue(of(GRUPOS_MOCK));
    mockService.listarUsuarios.mockReturnValue(NEVER);
    fixture.detectChanges();

    expect(component.estado()).toBe('loading');
  });

  it('deve aplicar grupoFiltroInicial via ngOnChanges e carregar usuarios filtrados', () => {
    fixture.detectChanges();
    jest.clearAllMocks();

    mockService.listarUsuarios.mockReturnValue(of(USUARIOS_PAGINADOS));

    component.ngOnChanges({
      grupoFiltroInicial: new SimpleChange(null, 'admin_geral', false),
    });

    expect(component.gruposSelecionados()).toEqual(['admin_geral']);
    expect(component.paginaAtual()).toBe(0);
    expect(mockService.listarUsuarios).toHaveBeenCalledTimes(1);
  });

  it('deve ignorar ngOnChanges quando grupoFiltroInicial e nulo', () => {
    fixture.detectChanges();
    jest.clearAllMocks();

    component.ngOnChanges({
      grupoFiltroInicial: new SimpleChange('admin_geral', null, false),
    });

    expect(mockService.listarUsuarios).not.toHaveBeenCalled();
  });

  describe('toggleSort()', () => {
    beforeEach(() => fixture.detectChanges());

    it('deve alternar sortDir para desc quando mesma coluna ja esta selecionada com asc', () => {
      expect(component.sortBy()).toBe('nome');
      expect(component.sortDir()).toBe('asc');

      component.toggleSort('nome');

      expect(component.sortBy()).toBe('nome');
      expect(component.sortDir()).toBe('desc');
    });

    it('deve voltar para asc ao chamar toggleSort na mesma coluna que ja esta desc', () => {
      component.toggleSort('nome');
      expect(component.sortDir()).toBe('desc');

      component.toggleSort('nome');
      expect(component.sortDir()).toBe('asc');
    });

    it('deve mudar sortBy e resetar sortDir para asc ao trocar de coluna', () => {
      component.toggleSort('email');

      expect(component.sortBy()).toBe('email');
      expect(component.sortDir()).toBe('asc');
    });

    it('deve resetar paginaAtual para 0 ao ordenar', () => {
      component.paginaAtual.set(3);
      component.toggleSort('nome');
      expect(component.paginaAtual()).toBe(0);
    });
  });

  describe('toggleDropdown()', () => {
    beforeEach(() => fixture.detectChanges());

    it('deve abrir o dropdown ao chamar toggleDropdown', () => {
      expect(component.dropdownAberto()).toBe(false);
      component.toggleDropdown();
      expect(component.dropdownAberto()).toBe(true);
    });

    it('deve fechar o dropdown na segunda chamada', () => {
      component.toggleDropdown();
      component.toggleDropdown();
      expect(component.dropdownAberto()).toBe(false);
    });
  });
});
