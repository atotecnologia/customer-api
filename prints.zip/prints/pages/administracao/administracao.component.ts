import { Component, signal } from '@angular/core';
import { AbaGruposComponent } from './components/aba-grupos/aba-grupos.component';
import { AbaPerfisComponent } from './components/aba-perfis/aba-perfis.component';
import { AbaPermissoesComponent } from './components/aba-permissoes/aba-permissoes.component';
import { GrupoResumo } from '@shared/models/administracao.model';

type Aba = 'grupos' | 'perfis' | 'permissoes';

@Component({
  selector: 'app-administracao',
  standalone: true,
  imports: [AbaGruposComponent, AbaPerfisComponent, AbaPermissoesComponent],
  templateUrl: './administracao.component.html',
  styleUrl: './administracao.component.scss',
})
export class AdministracaoComponent {
  readonly abaAtiva = signal<Aba>('grupos');
  readonly grupoFiltroPreSelecionado = signal<string | null>(null);

  irParaPerfisComFiltro(grupo: GrupoResumo): void {
    this.grupoFiltroPreSelecionado.set(grupo.id);
    this.abaAtiva.set('perfis');
  }

  selecionarAba(aba: Aba): void {
    if (aba !== this.abaAtiva()) {
      this.grupoFiltroPreSelecionado.set(null);
      this.abaAtiva.set(aba);
    }
  }
}
