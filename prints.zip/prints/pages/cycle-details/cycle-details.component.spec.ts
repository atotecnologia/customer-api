import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { of } from 'rxjs';

import { CycleDetailsComponent } from './cycle-details.component';
import { CycleDetailsService } from '../../core/services/detail/cycle-details.service';
import { PaginationInfo } from '../../shared/models/pagination-info.model';

describe('CycleDetailsComponent', () => {
  let component: CycleDetailsComponent;
  let fixture: ComponentFixture<CycleDetailsComponent>;
  let serviceMock: jest.Mocked<CycleDetailsService>;

  beforeEach(async () => {
    serviceMock = {
      getCycles: jest.fn(),
      getFilters: jest.fn(),
      getDetails: jest.fn(),
      exportDetails: jest.fn(),
    } as any;

    await TestBed.configureTestingModule({
      imports: [CycleDetailsComponent],
      providers: [{ provide: CycleDetailsService, useValue: serviceMock }],
    }).compileComponents();

    fixture = TestBed.createComponent(CycleDetailsComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    serviceMock.getCycles.mockReturnValue(
      of([{ id: '2026.1', label: 'Ciclo Atual', data_upload: '2026-01-01' }])
    );
    serviceMock.getFilters.mockReturnValue(
      of({
        empresas: [],
        statusRevisado: [],
        cursos: [],
        bus: [],
        areasConhecimento: [],
      })
    );
    serviceMock.getDetails.mockReturnValue(
      of({
        itens: [],
        pagination: {
          page: 0,
          pageSize: 100,
          totalElements: 0,
          totalPages: 0,
        } as PaginationInfo,
      })
    );

    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('should clear suggestions if less than 3 letters', fakeAsync(() => {
    component.cursosOriginais = ['ADMINISTRACAO'];
    component.cursoCtrl.setValue('ad');
    tick(300);

    expect(component.cursosSugestao.length).toBe(0);
  }));

  it('should toggle export menu', () => {
    expect(component.showExportMenu).toBe(false);
    component.toggleExportMenu();
    expect(component.showExportMenu).toBe(true);
  });

  it('should call exportDetails on export', () => {
    serviceMock.exportDetails.mockReturnValue(of(new Blob(['csv'], { type: 'text/csv' })));

    component.selectedCiclo = '2026.1';
    component.exportar('csv');

    expect(serviceMock.exportDetails).toHaveBeenCalledWith({
      ciclo: '2026.1',
      empresa: undefined,
      curso: undefined,
      statusRevisado: undefined,
      formato: 'csv',
    });
  });

  describe('goToPage', () => {
    it('should change page and reload table', () => {
      component.pagination = {
        page: 0,
        pageSize: 100,
        totalElements: 200,
        totalPages: 2,
      };

      serviceMock.getDetails.mockReturnValue(
        of({
          itens: [],
          pagination: component.pagination,
        })
      );

      component.goToPage(1);
      expect(component.currentPage).toBe(1);
    });

    it('should not navigate when pagination is undefined', () => {
      component.pagination = undefined;
      component.currentPage = 0;

      component.goToPage(1);

      expect(component.currentPage).toBe(0);
      expect(serviceMock.getDetails).not.toHaveBeenCalled();
    });

    it('should not navigate when the page is negative', () => {
      component.pagination = { totalPages: 2 } as PaginationInfo;
      component.currentPage = 0;

      component.goToPage(-1);

      expect(component.currentPage).toBe(0);
      expect(serviceMock.getDetails).not.toHaveBeenCalled();
    });

    it('should not navigate when page equals totalPages', () => {
      component.pagination = { totalPages: 2 } as PaginationInfo;
      component.currentPage = 0;

      component.goToPage(2);

      expect(component.currentPage).toBe(0);
      expect(serviceMock.getDetails).not.toHaveBeenCalled();
    });

    it('should not navigate when page is greater than the totalPages', () => {
      component.pagination = { totalPages: 2 } as PaginationInfo;
      component.currentPage = 0;

      component.goToPage(5);

      expect(component.currentPage).toBe(0);
      expect(serviceMock.getDetails).not.toHaveBeenCalled();
    });
  });

  describe('ngOnInit', () => {
    it('deve chamar getCycles ao inicializar', () => {
      serviceMock.getCycles.mockReturnValue(
        of([{ id: '2026.1', label: 'Ciclo Atual', data_upload: '2026-01-01' }])
      );
      serviceMock.getFilters.mockReturnValue(
        of({ empresas: [], statusRevisado: [], cursos: [], bus: [], areasConhecimento: [] })
      );
      serviceMock.getDetails.mockReturnValue(
        of({
          itens: [],
          pagination: { page: 0, pageSize: 100, totalElements: 0, totalPages: 0 } as PaginationInfo,
        })
      );

      fixture.detectChanges();

      expect(serviceMock.getCycles).toHaveBeenCalledTimes(1);
    });

    it('deve popular ciclos, empresas, status e cursosOriginais após ngOnInit', () => {
      const mockFiltros = {
        empresas: ['Empresa A'],
        statusRevisado: ['OK'],
        cursos: ['ADMINISTRACAO', 'PEDAGOGIA'],
        bus: [],
        areasConhecimento: [],
      };

      serviceMock.getCycles.mockReturnValue(
        of([{ id: '2026.1', label: 'Ciclo Atual', data_upload: '2026-01-01' }])
      );
      serviceMock.getFilters.mockReturnValue(of(mockFiltros));
      serviceMock.getDetails.mockReturnValue(
        of({
          itens: [],
          pagination: { page: 0, pageSize: 100, totalElements: 0, totalPages: 0 } as PaginationInfo,
        })
      );

      fixture.detectChanges();

      expect(component.ciclos).toEqual([
        { id: '2026.1', label: 'Ciclo Atual', data_upload: '2026-01-01' },
      ]);
      expect(component.selectedCiclo).toBe('2026.1');
      expect(component.empresas).toEqual(mockFiltros.empresas);
      expect(component.status).toEqual(mockFiltros.statusRevisado);
      expect(component.cursosOriginais).toEqual(mockFiltros.cursos);
    });

    it('deve filtrar cursosSugestao e chamar aplicarFiltro quando cursoCtrl tem 3 ou mais caracteres', fakeAsync(() => {
      serviceMock.getCycles.mockReturnValue(
        of([{ id: '2026.1', label: 'Ciclo Atual', data_upload: '2026-01-01' }])
      );
      serviceMock.getFilters.mockReturnValue(
        of({ empresas: [], statusRevisado: [], cursos: [], bus: [], areasConhecimento: [] })
      );
      serviceMock.getDetails.mockReturnValue(
        of({
          itens: [],
          pagination: { page: 0, pageSize: 100, totalElements: 0, totalPages: 0 } as PaginationInfo,
        })
      );

      fixture.detectChanges();
      serviceMock.getDetails.mockClear();

      component.cursosOriginais = ['ADMINISTRACAO', 'PEDAGOGIA', 'LETRAS'];
      component.cursoCtrl.setValue('adm');
      tick(300);

      expect(component.cursosSugestao).toEqual(['ADMINISTRACAO']);
      expect(serviceMock.getDetails).toHaveBeenCalled();
    }));

    it('deve retornar todos os cursos que contenham o termo buscado', fakeAsync(() => {
      serviceMock.getCycles.mockReturnValue(
        of([{ id: '2026.1', label: 'Ciclo Atual', data_upload: '2026-01-01' }])
      );
      serviceMock.getFilters.mockReturnValue(
        of({ empresas: [], statusRevisado: [], cursos: [], bus: [], areasConhecimento: [] })
      );
      serviceMock.getDetails.mockReturnValue(
        of({
          itens: [],
          pagination: { page: 0, pageSize: 100, totalElements: 0, totalPages: 0 } as PaginationInfo,
        })
      );

      fixture.detectChanges();

      component.cursosOriginais = ['LETRAS', 'ADMINISTRACAO', 'CIENCIAS LETRAS'];
      component.cursoCtrl.setValue('let');
      tick(300);

      expect(component.cursosSugestao).toEqual(['LETRAS', 'CIENCIAS LETRAS']);
    }));
  });

  describe('aplicarFiltro', () => {
    it('deve resetar currentPage para 0 ao chamar aplicarFiltro', () => {
      serviceMock.getDetails.mockReturnValue(
        of({
          itens: [],
          pagination: { page: 0, pageSize: 100, totalElements: 0, totalPages: 0 } as PaginationInfo,
        })
      );
      component.currentPage = 3;

      component.aplicarFiltro();

      expect(component.currentPage).toBe(0);
    });

    it('deve chamar getDetails ao aplicarFiltro', () => {
      serviceMock.getDetails.mockReturnValue(
        of({
          itens: [],
          pagination: { page: 0, pageSize: 100, totalElements: 0, totalPages: 0 } as PaginationInfo,
        })
      );
      component.currentPage = 2;
      component.selectedCiclo = '2026.1';

      component.aplicarFiltro();

      expect(serviceMock.getDetails).toHaveBeenCalledWith(
        expect.objectContaining({ ciclo: '2026.1', page: 0 })
      );
    });
  });

  describe('changePageSize', () => {
    it('deve resetar currentPage para 0 ao chamar changePageSize', () => {
      serviceMock.getDetails.mockReturnValue(
        of({
          itens: [],
          pagination: { page: 0, pageSize: 100, totalElements: 0, totalPages: 0 } as PaginationInfo,
        })
      );
      component.currentPage = 5;

      component.changePageSize();

      expect(component.currentPage).toBe(0);
    });

    it('deve chamar getDetails com o novo pageSize ao chamar changePageSize', () => {
      serviceMock.getDetails.mockReturnValue(
        of({
          itens: [],
          pagination: { page: 0, pageSize: 50, totalElements: 0, totalPages: 0 } as PaginationInfo,
        })
      );
      component.currentPage = 2;
      component.selectedCiclo = '2026.1';
      component.pageSize = 50;

      component.changePageSize();

      expect(serviceMock.getDetails).toHaveBeenCalledWith(
        expect.objectContaining({ ciclo: '2026.1', page: 0, pageSize: 50 })
      );
    });
  });

  describe('visiblePages', () => {
    it('deve retornar [] quando pagination é undefined', () => {
      component.pagination = undefined;

      expect(component.visiblePages).toEqual([]);
    });

    it('deve retornar as primeiras páginas quando currentPage está no início', () => {
      component.pagination = { totalPages: 10 } as PaginationInfo;
      component.currentPage = 0;

      expect(component.visiblePages).toEqual([0, 1, 2, 3, 4]);
    });

    it('deve retornar janela de 5 páginas centrada em currentPage', () => {
      component.pagination = { totalPages: 10 } as PaginationInfo;
      component.currentPage = 5;

      expect(component.visiblePages).toEqual([3, 4, 5, 6, 7]);
    });

    it('deve limitar as páginas ao total disponível quando currentPage está no final', () => {
      component.pagination = { totalPages: 10 } as PaginationInfo;
      component.currentPage = 9;

      expect(component.visiblePages).toEqual([7, 8, 9]);
    });

    it('deve retornar apenas as páginas existentes quando totalPages é menor que 5', () => {
      component.pagination = { totalPages: 3 } as PaginationInfo;
      component.currentPage = 0;

      expect(component.visiblePages).toEqual([0, 1, 2]);
    });
  });

  describe('startItem', () => {
    it('deve retornar 0 quando pagination é undefined', () => {
      component.pagination = undefined;

      expect(component.startItem).toBe(0);
    });

    it('deve retornar 1 na primeira página', () => {
      component.pagination = {
        page: 0,
        pageSize: 100,
      } as PaginationInfo;

      expect(component.startItem).toBe(1);
    });

    it('deve retornar o índice correto na segunda página', () => {
      component.pagination = {
        page: 1,
        pageSize: 100,
      } as PaginationInfo;

      expect(component.startItem).toBe(101);
    });

    it('deve calcular corretamente com pageSize diferente', () => {
      component.pagination = {
        page: 2,
        pageSize: 25,
      } as PaginationInfo;

      expect(component.startItem).toBe(51);
    });
  });

  describe('endItem', () => {
    it('deve retornar 0 quando pagination é undefined', () => {
      component.pagination = undefined;

      expect(component.endItem).toBe(0);
    });

    it('deve retornar o fim da página quando não é a última', () => {
      component.pagination = {
        page: 0,
        pageSize: 100,
        totalElements: 250,
      } as PaginationInfo;

      expect(component.endItem).toBe(100);
    });

    it('deve retornar totalElements na última página incompleta', () => {
      component.pagination = {
        page: 2,
        pageSize: 100,
        totalElements: 250,
      } as PaginationInfo;

      expect(component.endItem).toBe(250);
    });

    it('deve retornar totalElements quando a última página está completa', () => {
      component.pagination = {
        page: 1,
        pageSize: 100,
        totalElements: 200,
      } as PaginationInfo;

      expect(component.endItem).toBe(200);
    });
  });
});
