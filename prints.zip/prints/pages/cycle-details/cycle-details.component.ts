import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormControl } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil, switchMap, debounceTime, distinctUntilChanged } from 'rxjs/operators';

import { CycleDetailsService, FiltrosData } from '../../core/services/detail/cycle-details.service';
import { CourseItem } from '../../shared/models/course-item.model';
import { Cycle } from '../../shared/models/cycle.model';
import { PaginationInfo } from '../../shared/models/pagination-info.model';

@Component({
  selector: 'app-cycle-details',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './cycle-details.component.html',
  styleUrls: ['./cycle-details.component.scss'],
})
export class CycleDetailsComponent implements OnInit, OnDestroy {
  private readonly destroy$ = new Subject<void>();

  selectedCiclo = '';
  selectedEmpresa = '';
  selectedStatus = '';

  cursoCtrl = new FormControl('');

  ciclos: Cycle[] = [];
  empresas: string[] = [];
  status: string[] = [];

  cursosOriginais: string[] = [];

  cursosSugestao: string[] = [];

  listagem: CourseItem[] = [];

  currentPage = 0;
  pageSize = 100;
  pageSizeOptions = [25, 50, 100, 200];
  pagination?: PaginationInfo;

  showExportMenu = false;

  constructor(private readonly service: CycleDetailsService) {}

  ngOnInit(): void {
    this.loadFilters();

    this.cursoCtrl.valueChanges
      .pipe(debounceTime(300), distinctUntilChanged(), takeUntil(this.destroy$))
      .subscribe(valor => {
        if (!valor || valor.length < 3) {
          this.cursosSugestao = [];
          return;
        }

        const termo = valor.toLowerCase();

        this.cursosSugestao = this.cursosOriginais.filter(curso =>
          curso.toLowerCase().includes(termo)
        );

        this.aplicarFiltro();
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  toggleExportMenu(): void {
    this.showExportMenu = !this.showExportMenu;
  }

  exportar(tipo: 'csv' | 'xlsx'): void {
    this.showExportMenu = false;

    this.service
      .exportDetails({
        ciclo: this.selectedCiclo,
        empresa: this.selectedEmpresa || undefined,
        curso: this.cursoCtrl.value || undefined,
        statusRevisado: this.selectedStatus || undefined,
        formato: tipo,
      })
      .subscribe(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `detalhes-ciclo.${tipo}`;
        a.click();
        window.URL.revokeObjectURL(url);
      });
  }

  loadFilters(): void {
    this.service
      .getCycles()
      .pipe(
        switchMap(ciclos => {
          this.ciclos = ciclos;
          this.selectedCiclo = ciclos[0]?.id ?? '';

          this.loadTable();

          return this.service.getFilters(this.selectedCiclo);
        }),
        takeUntil(this.destroy$)
      )
      .subscribe((filtros: FiltrosData) => {
        this.empresas = filtros.empresas;
        this.status = filtros.statusRevisado;

        this.cursosOriginais = filtros.cursos;

        this.cursosSugestao = [];
      });
  }

  loadTable(): void {
    this.service
      .getDetails({
        ciclo: this.selectedCiclo,
        empresa: this.selectedEmpresa || undefined,
        curso: this.cursoCtrl.value || undefined,
        statusRevisado: this.selectedStatus || undefined,
        page: this.currentPage,
        pageSize: this.pageSize,
      })
      .pipe(takeUntil(this.destroy$))
      .subscribe(data => {
        this.listagem = data.itens;
        this.pagination = data.pagination;
      });
  }

  aplicarFiltro(): void {
    this.currentPage = 0;
    this.loadTable();
  }

  goToPage(page: number): void {
    if (!this.pagination) return;
    if (page < 0 || page >= this.pagination.totalPages) return;

    this.currentPage = page;
    this.loadTable();
  }

  changePageSize(): void {
    this.currentPage = 0;
    this.loadTable();
  }

  get visiblePages(): number[] {
    if (!this.pagination) return [];

    const start = Math.max(this.currentPage - 2, 0);
    const end = Math.min(start + 5, this.pagination.totalPages);

    return Array.from({ length: end - start }, (_, i) => start + i);
  }

  get startItem(): number {
    if (!this.pagination) return 0;
    return this.pagination.page * this.pagination.pageSize + 1;
  }

  get endItem(): number {
    if (!this.pagination) return 0;
    return Math.min(
      (this.pagination.page + 1) * this.pagination.pageSize,
      this.pagination.totalElements
    );
  }
}
