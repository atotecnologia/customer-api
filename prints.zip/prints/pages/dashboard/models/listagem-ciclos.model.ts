import { Ciclo } from './ciclos.model';

export interface ListagemCiclos {
  status: string;
  message: string;
  data: {
    ultimoUploadGeral: Date;
    ciclos: Ciclo[];
  };
}
