export interface DashboardMetric {
  label: string;
  value: string;
  tone: 'primary' | 'success' | 'warning' | 'danger' | 'info';
  icon: string;
  helper: string;
}

export interface SummaryKpis {
  label: string;
  valor: string;
  status: DashboardMetric['tone'];
  descricaoTooltip: string;
}

export interface Charts {
  bu: string;
  ok: number;
  retirar: number;
}

export interface TopUnidadesDescontinuadas {
  empresa: string;
  areaPredominante: string;
  qtdRetirar: number;
}

export interface DashboardData {
  status: string;
  message: string;
  data: {
    cicloId: string;
    summaryKpis: SummaryKpis[];
    charts: Charts[];
    topUnidadesDescontinuadas: TopUnidadesDescontinuadas[];
  };
}
