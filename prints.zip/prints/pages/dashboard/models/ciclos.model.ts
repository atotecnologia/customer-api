export interface Ciclo {
  id: string;
  label: string;
  data_upload: string;
}
