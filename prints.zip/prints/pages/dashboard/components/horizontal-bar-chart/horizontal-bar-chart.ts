import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { NgxChartsModule, Color, ScaleType } from '@swimlane/ngx-charts';
import { Charts } from '@app/pages/dashboard/models/dashboard.models';

@Component({
  selector: 'app-horizontal-bar-chart',
  standalone: true,
  imports: [NgxChartsModule],
  templateUrl: './horizontal-bar-chart.component.html',
  styleUrl: './horizontal-bar-chart.scss',
})
export class HorizontalBarChartComponent implements OnChanges {
  @Input() chartData: Charts[] = [];

  // options
  showXAxis = false;
  showYAxis = true;
  gradient = false;
  showLegend = false;
  showXAxisLabel = true;
  xAxisLabel = 'BU';
  showYAxisLabel = true;
  yAxisLabel = 'Indicadores';

  colorScheme: Color = {
    name: 'custom',
    selectable: false,
    group: ScaleType.Ordinal,
    domain: ['#1eba0fff', '#b30e2fff'],
  };

  public data: { name: string; series: { name: string; value: number }[] }[] = [];

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['chartData'] && this.chartData) {
      this.data = this.chartData.map(chart => ({
        name: chart.bu,
        series: [
          {
            name: 'OK',
            value: chart.ok,
          },
          {
            name: 'RETIRAR',
            value: chart.retirar,
          },
        ],
      }));
    }
  }
}
