import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AlertTableComponent } from './alert-table';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('AlertTable', () => {
  let component: AlertTableComponent;
  let fixture: ComponentFixture<AlertTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AlertTableComponent, HttpClientTestingModule],
    }).compileComponents();

    fixture = TestBed.createComponent(AlertTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
