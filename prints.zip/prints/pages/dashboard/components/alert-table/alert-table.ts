import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TopUnidadesDescontinuadas } from '@app/pages/dashboard/models/dashboard.models';

export interface Alert {
  empresa: string;
  areaDeConhecimento: string;
  qtdRetirar: number;
}

@Component({
  selector: 'app-alert-table',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './alert-table.component.html',
  styleUrl: './alert-table.scss',
})
export class AlertTableComponent implements OnChanges {
  @Input() data: TopUnidadesDescontinuadas[] = [];
  public alerts: Alert[] = [];

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['data'] && this.data) {
      this.alerts = this.data.map(item => ({
        empresa: item.empresa,
        areaDeConhecimento: item.areaPredominante,
        qtdRetirar: item.qtdRetirar,
      }));
    }
  }
}
