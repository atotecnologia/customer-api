import { Component, input } from '@angular/core';

@Component({
  selector: 'app-status-chip',
  standalone: true,
  templateUrl: './status-chip.component.html',
  styleUrls: ['./status-chip.scss'],
})
export class StatusChipComponent {
  readonly label = input.required<string>();
  readonly tone = input<'primary' | 'success' | 'warning' | 'danger' | 'info'>('primary');

  toneClass(): string {
    return `tone-${this.tone()}`;
  }
}
