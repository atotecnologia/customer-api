import { ComponentFixture, TestBed } from '@angular/core/testing';
import { KpiCardComponent } from './kpi-card';
import { DashboardMetric } from '../../models/dashboard.models';

describe('KpiCardComponent', () => {
  let component: KpiCardComponent;
  let fixture: ComponentFixture<KpiCardComponent>;

  const mockMetric: DashboardMetric | any = {
    key: 'test',
    label: 'Test Metric',
    value: '100',
    icon: 'heroCube',
    tone: 'primary',
    helper: 'This is a test metric',
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [KpiCardComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(KpiCardComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('metric', mockMetric);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
