import { Component, input } from '@angular/core';
import { NgClass } from '@angular/common';
import { NgIconComponent, provideIcons } from '@ng-icons/core';
import {
  heroCube,
  heroCheckCircle,
  heroArchiveBoxXMark,
  heroArrowPath,
  heroInformationCircle,
} from '@ng-icons/heroicons/outline';
import { DashboardMetric } from '../../models/dashboard.models';

@Component({
  selector: 'app-kpi-card',
  standalone: true,
  imports: [NgClass, NgIconComponent],
  viewProviders: [
    provideIcons({
      heroCube,
      heroCheckCircle,
      heroArchiveBoxXMark,
      heroArrowPath,
      heroInformationCircle,
    }),
  ],
  templateUrl: './kpi-card.component.html',
  styleUrls: ['./kpi-card.scss'],
})
export class KpiCardComponent {
  readonly metric = input.required<DashboardMetric>();
}
