import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideNoopAnimations } from '@angular/platform-browser/animations';
import { DashboardComponent } from './dashboard.component';
import { AuthService } from '@app/core/services/auth/auth.service';
import { DashboardService } from '@app/core/services/dashboard/dashboard.service';
import { signal } from '@angular/core';
import { of, throwError } from 'rxjs';
import { ListagemCiclos } from '@app/pages/dashboard/models/listagem-ciclos.model';
import { DashboardData } from '@app/pages/dashboard/models/dashboard.models';

jest.mock('@env/environment', () => ({
  environment: {
    NG_BASE_BFF_URL: 'http://localhost:8080',
    endpoints: {
      listagemCiclos: '/api/v1/listagem-ciclos',
      ciclo_dashboard: '/api/v1/ciclo-dashboard',
      user: '/api/v1/user',
    },
  },
}));

describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;
  let mockAuthService: Partial<AuthService>;
  let mockDashboardService: Partial<DashboardService>;

  beforeEach(async () => {
    mockAuthService = {
      isAuthenticated: jest.fn(() => true),
      currentUserProfile: signal({
        oid: 'mock-oid',
        nome: 'Mock User',
        email: 'mock@example.com',
        grupos: ['user'],
      }),
    };

    mockDashboardService = {
      obterCiclosImportados: jest.fn(() =>
        of({
          status: 'success',
          message: 'Ciclos found',
          data: {
            ciclos: [{ id: '2023.01' }, { id: '2023.02' }],
            // Add other properties of ListagemCiclos if needed by component
          },
        } as ListagemCiclos)
      ), // Cast to ListagemCiclos
      obterDashboardCiclo: jest.fn(() =>
        of({
          status: 'success',
          message: 'Dashboard data',
          data: {
            charts: [],
            topUnidadesDescontinuadas: [],
            summaryKpis: [],
            // Add other properties of DashboardData if needed by component
          },
        } as unknown as DashboardData)
      ), // Cast to DashboardData
    };

    await TestBed.configureTestingModule({
      imports: [DashboardComponent],
      providers: [
        provideNoopAnimations(),
        provideHttpClient(),
        provideHttpClientTesting(),
        { provide: AuthService, useValue: mockAuthService },
        { provide: DashboardService, useValue: mockDashboardService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('onCicloChange', () => {
    it('deve atualizar selectedCiclo com o novo cicloId', () => {
      component.onCicloChange('2023.02');

      expect(component.selectedCiclo).toBe('2023.02');
    });

    it('deve chamar obterDashboardCiclo com o novo cicloId', () => {
      component.onCicloChange('2023.02');

      expect(mockDashboardService.obterDashboardCiclo).toHaveBeenCalledWith('2023.02');
    });

    it('deve atualizar os dados do dashboard após trocar o ciclo', () => {
      const mockDashboardData: DashboardData = {
        status: 'success',
        message: 'OK',
        data: {
          cicloId: '2023.02',
          charts: [{ bu: 'BU1', ok: 10, retirar: 2 }],
          topUnidadesDescontinuadas: [],
          summaryKpis: [],
        },
      };

      (mockDashboardService.obterDashboardCiclo as jest.Mock).mockReturnValue(
        of(mockDashboardData)
      );

      component.onCicloChange('2023.02');

      expect(component.chartsData).toEqual(mockDashboardData.data.charts);
    });
  });

  describe('carregarCiclos', () => {
    it('deve definir hasError como true quando ocorrer erro ao carregar ciclos', () => {
      (mockDashboardService.obterCiclosImportados as jest.Mock).mockReturnValue(
        throwError(() => new Error('Erro de rede'))
      );
      component.carregarCiclos();
      expect(component.hasError).toBe(true);
      expect(component.isLoadingCiclos).toBe(false);
    });

    it('deve definir isLoadingDashboard como false quando não há ciclos disponíveis', () => {
      (mockDashboardService.obterCiclosImportados as jest.Mock).mockReturnValue(
        of({ status: 'success', message: '', data: { ciclos: [] } } as ListagemCiclos)
      );
      component.carregarCiclos();
      expect(component.isLoadingDashboard).toBe(false);
    });
  });

  describe('carregarDadosDashboard', () => {
    it('deve definir hasError como true quando ocorrer erro ao carregar dados do dashboard', () => {
      (mockDashboardService.obterDashboardCiclo as jest.Mock).mockReturnValue(
        throwError(() => new Error('Erro de rede'))
      );
      component.carregarDadosDashboard('2023.01');
      expect(component.hasError).toBe(true);
      expect(component.isLoadingDashboard).toBe(false);
    });

    it('deve mapear summaryKpis para dashboardMetrics com label, valor e ícone corretos', () => {
      const mockData: DashboardData = {
        status: 'success',
        message: 'OK',
        data: {
          cicloId: '2023.01',
          charts: [],
          topUnidadesDescontinuadas: [],
          summaryKpis: [
            {
              label: 'Base Total',
              valor: '1.250',
              status: 'primary',
              descricaoTooltip: 'Tooltip 1',
            },
            {
              label: 'Disponíveis',
              valor: '980',
              status: 'success',
              descricaoTooltip: 'Tooltip 2',
            },
          ],
        },
      };
      (mockDashboardService.obterDashboardCiclo as jest.Mock).mockReturnValue(of(mockData));

      component.carregarDadosDashboard('2023.01');

      expect(component.dashboardMetrics.length).toBe(2);
      expect(component.dashboardMetrics[0]).toEqual(
        expect.objectContaining({ label: 'Base Total', value: '1.250', icon: 'heroCube' })
      );
      expect(component.dashboardMetrics[1]).toEqual(
        expect.objectContaining({ label: 'Disponíveis', value: '980', icon: 'heroCheckCircle' })
      );
    });
  });

  describe('getIconForStatus', () => {
    it.each([
      ['primary', 'heroCube'],
      ['success', 'heroCheckCircle'],
      ['warning', 'heroArrowPath'],
      ['danger', 'heroArchiveBoxXMark'],
      ['info', 'heroInformationCircle'],
      ['qualquer-outro', 'heroCube'],
    ])('deve retornar "%s" para o status "%s"', (status, expectedIcon) => {
      const icon = component['getIconForStatus'](status as any);

      expect(icon).toBe(expectedIcon);
    });
  });
});
