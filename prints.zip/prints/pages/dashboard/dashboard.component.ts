import { Component, inject, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { tap } from 'rxjs/operators';
import { DashboardService } from '@app/core/services/dashboard/dashboard.service';
import { ListagemCiclos } from '@app/pages/dashboard/models/listagem-ciclos.model';
import { DropdownComponent } from '@app/shared/components/dropdown/dropdown';
import { Spinner } from '@app/shared/components/spinner/spinner';
import { KpiCardComponent } from './components/kpi-card/kpi-card';
import { HorizontalBarChartComponent } from './components/horizontal-bar-chart/horizontal-bar-chart';
import { AlertTableComponent } from './components/alert-table/alert-table';
import { Charts, DashboardMetric, TopUnidadesDescontinuadas } from './models/dashboard.models';
import { AuthService } from '@app/core/services/auth/auth.service';

import { ErrorStateComponent } from '@app/shared/components/error-state/error-state';
import { catchError, of } from 'rxjs';

@Component({
  selector: 'app-dashboard.component',
  imports: [
    DatePipe,
    DropdownComponent,
    KpiCardComponent,
    HorizontalBarChartComponent,
    AlertTableComponent,
    Spinner,
    ErrorStateComponent,
  ],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss',
})
export class DashboardComponent implements OnInit {
  protected readonly dashboardService = inject(DashboardService);
  authService = inject(AuthService);

  listagemCiclos?: ListagemCiclos;
  cicloOptions: string[] = [];
  selectedCiclo = '';

  dashboardMetrics: DashboardMetric[] = [];
  chartsData: Charts[] = [];
  topUnidadesData: TopUnidadesDescontinuadas[] = [];

  isLoadingCiclos = true;
  isLoadingDashboard = true;
  hasError = false;

  ngOnInit(): void {
    this.carregarCiclos();
  }

  carregarCiclos(): void {
    this.isLoadingCiclos = true;
    this.hasError = false;
    this.dashboardService
      .obterCiclosImportados()
      .pipe(
        tap(listagem => {
          this.listagemCiclos = listagem;
          this.cicloOptions = listagem.data?.ciclos?.map(c => c.id) ?? [];
          this.selectedCiclo = this.cicloOptions[0] ?? '';
          this.isLoadingCiclos = false;
        }),
        catchError(err => {
          console.error('Erro ao carregar ciclos:', err);
          this.isLoadingCiclos = false;
          this.hasError = true;
          return of(null);
        })
      )
      .subscribe(listagem => {
        if (listagem) {
          const firstCicloId = listagem.data?.ciclos?.[0]?.id || this.selectedCiclo;
          if (firstCicloId) {
            this.carregarDadosDashboard(firstCicloId);
          } else {
            this.isLoadingDashboard = false;
          }
        }
      });
  }

  onCicloChange(cicloId: string): void {
    this.selectedCiclo = cicloId;
    this.carregarDadosDashboard(cicloId);
  }

  carregarDadosDashboard(cicloId: string): void {
    this.isLoadingDashboard = true;
    this.hasError = false;
    this.dashboardService
      .obterDashboardCiclo(cicloId)
      .pipe(
        catchError(err => {
          console.error('Erro ao carregar dashboard:', err);
          this.isLoadingDashboard = false;
          this.hasError = true;
          return of(null);
        })
      )
      .subscribe(dashboardData => {
        if (dashboardData) {
          this.chartsData = dashboardData.data?.charts ?? [];
          this.topUnidadesData = dashboardData.data?.topUnidadesDescontinuadas ?? [];
          this.dashboardMetrics =
            dashboardData.data?.summaryKpis?.map(kpi => ({
              label: kpi.label,
              value: kpi.valor,
              tone: kpi.status,
              helper: kpi.descricaoTooltip,
              icon: this.getIconForStatus(kpi.status),
            })) ?? [];
          this.isLoadingDashboard = false;
        }
      });
  }

  private getIconForStatus(status: DashboardMetric['tone']): string {
    switch (status) {
      case 'primary':
        return 'heroCube';
      case 'success':
        return 'heroCheckCircle';
      case 'danger':
        return 'heroArchiveBoxXMark';
      case 'warning':
        return 'heroArrowPath';
      case 'info':
        return 'heroInformationCircle';
      default:
        return 'heroCube';
    }
  }
}
