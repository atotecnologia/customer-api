import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ControleAcessosComponent } from './controle-acessos.component';
import { NotificationService } from '@app/core/services/notification/notification.service';
import { ControleAcessoService } from '@app/core/services/controle-acesso/controle-acesso.service';
import { of, Subject, throwError } from 'rxjs';
import {
  obterGrupoAdResponse,
  salvarAteracaoGrupoAdResponse,
} from '@app/shared/mocks/fixtures/controle-acessos.fixture';
import { MockNotificationService } from '@app/shared/mocks/services/mock-notification-service';
import { ResponseAPI } from '@app/shared/models/response-api.model';
import { GrupoAds, Roles } from '@app/shared/models/controle-acesso.model';

describe('ControleAcessosComponent', () => {
  let component: ControleAcessosComponent;
  let fixture: ComponentFixture<ControleAcessosComponent>;
  let mockControleAcessoService: ControleAcessoService;
  let mockNotificationService: MockNotificationService;

  beforeEach(async () => {
    mockNotificationService = new MockNotificationService();
    mockControleAcessoService = {
      obterGrupoAd: jest.fn().mockReturnValue(of(obterGrupoAdResponse())),
      salvarAteracaoGrupoAd: jest.fn().mockReturnValue(of(salvarAteracaoGrupoAdResponse())),
    } as unknown as ControleAcessoService;

    await TestBed.configureTestingModule({
      imports: [ControleAcessosComponent],
      providers: [
        { provide: ControleAcessoService, useValue: mockControleAcessoService },
        { provide: NotificationService, useValue: mockNotificationService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(ControleAcessosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('deve criar o componente corretamente', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit e obterDadosAcesso', () => {
    it('deve carregar os dados de acesso na inicialização', () => {
      fixture.detectChanges();

      expect(mockControleAcessoService.obterGrupoAd).toHaveBeenCalledTimes(1);
      expect(component['papeis']).toEqual(obterGrupoAdResponse().data.grupoAds);
      expect(component.isLoading).toBe(false);
    });

    it('deve logar o erro se a obtenção de dados de acesso falhar', () => {
      mockControleAcessoService.obterGrupoAd = jest.fn().mockReturnValue(
        throwError(() => ({
          error: 'Erro ao carregar dados',
        }))
      );

      // Recria o componente para pegar o novo mock
      fixture = TestBed.createComponent(ControleAcessosComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();

      expect(component['papeis']).toEqual([]);
      expect(component.isLoading).toBe(false);
    });
  });

  describe('dado o método getQtdPermissoesSelecionadas', () => {
    it('deve retornar a contagem correta de permissões selecionadas', () => {
      const roles: Roles[] = [
        { id: 1, nome: 'Role 1', descricao: 'Desc 1', selecionado: true },
        { id: 2, nome: 'Role 2', descricao: 'Desc 2', selecionado: false },
        { id: 3, nome: 'Role 3', descricao: 'Desc 3', selecionado: true },
        { id: 4, nome: 'Role 4', descricao: 'Desc 4', selecionado: false },
      ];

      expect(component.getQtdPermissoesSelecionadas(roles)).toBe(2);
    });

    it('deve retornar 0 se nenhuma permissão estiver selecionada', () => {
      const roles: Roles[] = [
        { id: 1, nome: 'Role 1', descricao: 'Desc 1', selecionado: false },
        { id: 2, nome: 'Role 2', descricao: 'Desc 2', selecionado: false },
      ];

      expect(component.getQtdPermissoesSelecionadas(roles)).toBe(0);
    });
  });

  describe('dado o método onClickPapel', () => {
    it('deve definir o papel selecionado corretamente', () => {
      const papel: GrupoAds = { id: '3', descricao: 'Grupo C', roles: [] };

      component.onClickPapel(papel);

      expect(component.papelSelecionado).toEqual(papel);
    });
  });

  describe('dado o método salvarAlteracoes', () => {
    let obterDadosAcessoSpy: jest.SpyInstance;
    let salvarAteracaoGrupoAd$: Subject<ResponseAPI<null>>;

    beforeEach(() => {
      obterDadosAcessoSpy = jest.spyOn(component as any, 'obterDadosAcesso');

      salvarAteracaoGrupoAd$ = new Subject<ResponseAPI<null>>();

      jest
        .spyOn(TestBed.inject(ControleAcessoService), 'salvarAteracaoGrupoAd')
        .mockReturnValue(salvarAteracaoGrupoAd$.asObservable());
    });

    it('deve chamar o serviço de salvar, exibir notificação de sucesso e recarregar dados', () => {
      component.salvarAlteracoes();

      expect(component.isLoading).toBe(true);
      expect(mockControleAcessoService.salvarAteracaoGrupoAd).toHaveBeenCalledTimes(1);
      expect(mockControleAcessoService.salvarAteracaoGrupoAd).toHaveBeenCalledWith(
        obterGrupoAdResponse().data.grupoAds
      );

      // Emite o valor de sucesso e finaliza o observable
      salvarAteracaoGrupoAd$.next(salvarAteracaoGrupoAdResponse());
      salvarAteracaoGrupoAd$.complete();

      expect(component.isLoading).toBe(false);
      expect(component.papelSelecionado).toBeNull();
      expect(mockNotificationService.success).toHaveBeenCalledWith(
        salvarAteracaoGrupoAdResponse().message
      );
      expect(obterDadosAcessoSpy).toHaveBeenCalledTimes(1);
    });

    it('deve logar o erro e definir isLoading como false em caso de falha', () => {
      const errorResponse = { error: 'Erro ao salvar alterações' };

      component.salvarAlteracoes();

      expect(component.isLoading).toBe(true);
      expect(mockControleAcessoService.salvarAteracaoGrupoAd).toHaveBeenCalledTimes(1);
      expect(mockControleAcessoService.salvarAteracaoGrupoAd).toHaveBeenCalledWith(
        obterGrupoAdResponse().data.grupoAds
      );

      // Emite o erro e finaliza o observable
      salvarAteracaoGrupoAd$.error({ error: errorResponse });

      expect(component.isLoading).toBe(false);
      expect(mockNotificationService.success).not.toHaveBeenCalled();
      expect(obterDadosAcessoSpy).not.toHaveBeenCalled();
    });
  });
});
