import { NgClass } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ControleAcessoService } from '@app/core/services/controle-acesso/controle-acesso.service';
import { NotificationService } from '@app/core/services/notification/notification.service';
import { GrupoAds, Roles } from '@app/shared/models/controle-acesso.model';
import { finalize } from 'rxjs';

@Component({
  selector: 'app-controle-acessos',
  imports: [NgClass, FormsModule],
  templateUrl: './controle-acessos.component.html',
  styleUrl: './controle-acessos.component.scss',
})
export class ControleAcessosComponent implements OnInit {
  protected papeis: GrupoAds[] = [];

  isLoading = false;
  papelSelecionado: GrupoAds | null = null;

  protected readonly controleAcessoService = inject(ControleAcessoService);
  protected readonly notificationService = inject(NotificationService);

  ngOnInit(): void {
    this.obterDadosAcesso();
  }

  getQtdPermissoesSelecionadas(permissoes: Roles[]): number {
    return permissoes.filter(value => value.selecionado).length;
  }

  onClickPapel(papel: GrupoAds): void {
    this.papelSelecionado = papel;
  }

  salvarAlteracoes(): void {
    this.isLoading = true;

    this.controleAcessoService
      .salvarAteracaoGrupoAd(this.papeis)
      .pipe(finalize(() => (this.isLoading = false)))
      .subscribe({
        next: res => {
          this.papelSelecionado = null;

          this.notificationService.success(res.message);

          this.obterDadosAcesso();
        },
        error: ({ error }) => {
          console.error(error);
        },
      });
  }

  private obterDadosAcesso(): void {
    this.controleAcessoService.obterGrupoAd().subscribe({
      next: res => {
        this.papeis = res.data.grupoAds;
      },
      error: ({ error }) => {
        console.error(error);
      },
    });
  }
}
