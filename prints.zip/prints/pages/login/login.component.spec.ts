import { ChangeDetectorRef } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { AuthService } from '@app/core/services/auth/auth.service';
import { OidcSecurityService } from 'angular-auth-oidc-client';
import { environment } from '@env/environment';
import { LoginComponent } from './login.component';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let oidcSecurityServiceMock: jest.Mocked<Pick<OidcSecurityService, 'authorize' | 'logoff'>>;
  let mockAuthService: jest.Mocked<Pick<AuthService, 'bypassLogin'>>;
  let mockRouter: jest.Mocked<Pick<Router, 'navigate'>>;

  beforeEach(async () => {
    oidcSecurityServiceMock = {
      authorize: jest.fn(),
      logoff: jest.fn(),
    };

    mockAuthService = {
      bypassLogin: jest.fn(),
    };

    mockRouter = {
      navigate: jest.fn(),
    };

    await TestBed.configureTestingModule({
      imports: [LoginComponent],
      providers: [
        { provide: OidcSecurityService, useValue: oidcSecurityServiceMock },
        { provide: AuthService, useValue: mockAuthService },
        { provide: Router, useValue: mockRouter },
        { provide: ChangeDetectorRef, useValue: { detectChanges: jest.fn() } },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    environment.NG_LOCAL_AUTH_BYPASS = false;
  });

  it('deve criar o componente corretamente', () => {
    expect(component).toBeTruthy();
  });

  it('deve iniciar com imagesLoaded falso', () => {
    expect(component.imagesLoaded).toBe(false);
  });

  describe('login()', () => {
    it('deve chamar authorize do OIDC quando bypass está desativado', () => {
      environment.NG_LOCAL_AUTH_BYPASS = false;

      component.login();

      expect(oidcSecurityServiceMock.authorize).toHaveBeenCalled();
      expect(mockAuthService.bypassLogin).not.toHaveBeenCalled();
      expect(mockRouter.navigate).not.toHaveBeenCalled();
    });

    it('deve chamar bypassLogin e navegar para /app quando bypass está ativado', () => {
      environment.NG_LOCAL_AUTH_BYPASS = true;

      component.login();

      expect(mockAuthService.bypassLogin).toHaveBeenCalled();
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/app']);
      expect(oidcSecurityServiceMock.authorize).not.toHaveBeenCalled();
    });
  });

  it('deve chamar o método logoff ao executar o logout', () => {
    component.logout();
    expect(oidcSecurityServiceMock.logoff).toHaveBeenCalled();
  });

  it('deve carregar imagens e definir imagesLoaded como verdadeiro', () => {
    // Mock global Image
    const originalImage = global.Image;
    const imageInstances: any[] = [];

    global.Image = class {
      onload: any;
      onerror: any;
      src = '';
      constructor() {
        imageInstances.push(this);
      }
    } as any;

    // Reinicia o componente para disparar o ngOnInit com o mock do Image
    component.ngOnInit();

    expect(imageInstances.length).toBe(4);

    // Simula o carregamento de cada imagem
    imageInstances.forEach(img => img.onload());

    expect(component.imagesLoaded).toBe(true);

    // Restaura global Image
    global.Image = originalImage;
  });

  it('deve lidar com erro no carregamento de imagens e ainda assim contar como carregada', () => {
    const originalImage = global.Image;
    const imageInstances: any[] = [];

    global.Image = class {
      onload: any;
      onerror: any;
      src = '';
      constructor() {
        imageInstances.push(this);
      }
    } as any;

    component.ngOnInit();

    // Simula erro em uma imagem e sucesso nas outras
    imageInstances[0].onerror();
    imageInstances[1].onload();
    imageInstances[2].onload();
    imageInstances[3].onload();

    expect(component.imagesLoaded).toBe(true);

    global.Image = originalImage;
  });
});
