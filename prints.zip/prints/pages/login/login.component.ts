import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Spinner } from '@app/shared/components/spinner/spinner';
import { OidcSecurityService } from 'angular-auth-oidc-client';
import { environment } from '@env/environment';
import { AuthService } from '@app/core/services/auth/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [Spinner],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
})
export class LoginComponent implements OnInit {
  imagesLoaded = false;
  private readonly imagePaths = [
    'images/logo-cruzeiro.png',
    'images/btn-office.png',
    'images/star-overlay.png',
    'images/icon-arrow-right.png',
  ];

  constructor(
    private readonly oidcSecurityService: OidcSecurityService,
    private readonly authService: AuthService,
    private readonly router: Router,
    private readonly cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.preloadImages();
  }

  private preloadImages() {
    let loadedCount = 0;
    this.imagePaths.forEach(path => {
      const img = new Image();
      img.onload = () => this.onImageLoad(++loadedCount);
      img.onerror = () => this.onImageLoad(++loadedCount);
      img.src = path;
    });
  }

  private onImageLoad(count: number) {
    if (count === this.imagePaths.length) {
      this.imagesLoaded = true;
      this.cdr.detectChanges();
    }
  }

  login() {
    if (environment.NG_LOCAL_AUTH_BYPASS) {
      this.authService.bypassLogin();
      this.router.navigate(['/app']);

      return;
    }

    this.oidcSecurityService.authorize();
  }

  logout() {
    this.oidcSecurityService.logoff();
  }
}
