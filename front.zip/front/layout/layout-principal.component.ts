import { Component, computed, HostListener, inject, OnInit, signal, Type } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from '../core/services/auth/auth.service';
import { ErrorStateComponent } from '../shared/components/error-state/error-state';
import { NgComponentOutlet } from '@angular/common';
import { LucideArrowUpRight, LucideChartLine, LucideCloudUpload, LucideLogOut, LucideUpload } from '@lucide/angular';

interface MenuItem {
  path?: string;
  url?: string;
  label: string;
  helper?: string;
  icon: Type<unknown> | string;
  roles?: string[];
}

type MenuState = 'loading' | 'success' | 'error';

@Component({
  selector: 'app-layout-principal',
  standalone: true,
  imports: [
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
    ErrorStateComponent,
    LucideArrowUpRight,
    NgComponentOutlet,
  ],
  templateUrl: './layout-principal.component.html',
  styleUrl: './layout-principal.component.scss',
})
export class LayoutPrincipalComponent implements OnInit {
  private readonly router = inject(Router);
  private readonly authService = inject(AuthService);

  collapsed = true;
  menuState: MenuState = 'loading';
  readonly showUserMenu = signal(false);

  readonly hasGroupManagement = computed(
    () => this.authService.currentUserProfile()?.grupos.includes('Group_management') ?? false
  );

  readonly LucideLogOut = LucideLogOut;

  @HostListener('document:click')
  onDocumentClick(): void {
    this.showUserMenu.set(false);
  }

  toggleUserMenu(event: Event): void {
    event.stopPropagation();
    this.showUserMenu.update(v => !v);
  }

  irParaAdministracao(): void {
    this.showUserMenu.set(false);
    this.router.navigate(['/app/administracao']);
  }

  isString(value: unknown): value is string {
    return typeof value === 'string';
  }

  readonly menuItems: MenuItem[] = [
    {
      path: '/app/precos-praticados',
      label: 'Preços praticados',
      icon: LucideChartLine,
      roles: ['View_report'],
    },
    {
      path: '/app/upload',
      label: 'Importar Ciclo',
      icon: LucideUpload,
      roles: ['Edit_pricing'],
    },
    {
      path: '/app/publicacoes',
      label: 'Publicações',
      icon: LucideCloudUpload,
      roles: ['Approve_cycle'],
    },
    {
      path: '/app/historico',
      label: 'Histórico',
      icon: '/images/history.svg',
      roles: ['View_report', 'View_candidate', 'Edit_pricing', 'Approve_cycle', 'Group_management'],
    },
    /* {
      path: '/app/controle-acessos',
      label: 'Controle de Acessos',
      icon: '/images/icone-siaa.png',
      roles: ['Group_management'],
    }, */
  ];

  get userName(): string {
    return this.authService.currentUserProfile()?.nome ?? '';
  }

  get userInitials(): string {
    const nome = this.userName;

    if (!nome) {
      return '';
    }

    const parts = nome.trim().split(/\s+/);

    if (parts.length === 1) {
      return parts[0][0].toUpperCase();
    }

    return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
  }

  get filteredMenuItems(): MenuItem[] {
    const user = this.authService.currentUserProfile();
    if (!user) return [];

    return this.menuItems.filter(item => {
      if (!item.roles || item.roles.length === 0) return true;
      return item.roles.some(role => user.grupos.includes(role));
    });
  }

  readonly externalLinks: MenuItem[] = [
    {
      label: 'SIAA',
      icon: '/images/work.svg',
      url: 'https://siaa.cruzeirodosul.edu.br',
    },
  ];

  ngOnInit(): void {
    this.loadUserProfile();
  }

  loadUserProfile(): void {
    this.menuState = 'loading';
    this.authService.getUserProfile().subscribe({
      next: () => {
        this.menuState = 'success';
      },
      error: err => {
        console.error('Erro ao carregar perfil:', err);
        this.menuState = 'error';
      },
    });
  }

  reloadMenu(): void {
    this.loadUserProfile();
  }

  logout(): void {
    this.authService.clearToken();
    this.router.navigate(['/login']);
  }
}
