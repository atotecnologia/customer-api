import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LayoutPrincipalComponent } from './layout-principal.component';
import { provideRouter, Router } from '@angular/router';
import { AuthService } from '../core/services/auth/auth.service';
import { of, throwError } from 'rxjs';
import { signal, WritableSignal } from '@angular/core';
import { User } from '../shared/models/user.model';

describe('LayoutPrincipalComponent', () => {
  let component: LayoutPrincipalComponent;
  let fixture: ComponentFixture<LayoutPrincipalComponent>;
  let authServiceMock: Partial<AuthService>;
  let router: Router;
  let currentUserProfileSignal: WritableSignal<User | null>;

  beforeEach(async () => {
    currentUserProfileSignal = signal<User | null>({
      oid: '1',
      nome: 'Test Mock',
      email: 'test@test.com',
      grupos: ['Edit_pricing', 'Approve_cycle', 'View_report'],
    });

    authServiceMock = {
      clearToken: jest.fn(),
      getUserProfile: jest.fn(() =>
        of({ oid: '1', nome: 'Test', email: 'test@test.com', grupos: ['Edit_pricing'] })
      ),
      currentUserProfile: currentUserProfileSignal,
    };

    await TestBed.configureTestingModule({
      imports: [LayoutPrincipalComponent],
      providers: [provideRouter([]), { provide: AuthService, useValue: authServiceMock }],
    }).compileComponents();

    fixture = TestBed.createComponent(LayoutPrincipalComponent);
    component = fixture.componentInstance;
    router = TestBed.inject(Router);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set menuState to success on successful profile load', () => {
    component.loadUserProfile();
    expect(component.menuState).toBe('success');
  });

  it('should set menuState to error on profile load failure', () => {
    const consoleSpy = jest.spyOn(console, 'error').mockImplementation(() => {
      '';
    });
    (authServiceMock.getUserProfile as jest.Mock).mockReturnValue(
      throwError(() => new Error('error'))
    );
    component.loadUserProfile();
    expect(component.menuState).toBe('error');
    expect(consoleSpy).toHaveBeenCalled();
    consoleSpy.mockRestore();
  });

  it('should filter menu items based on user roles', () => {
    const filtered = component.filteredMenuItems;
    // Expected items: Importar Ciclo, Publicações, Histórico (Detalhes do Ciclo foi removido)
    expect(filtered.length).toBe(4);
    expect(filtered.map(i => i.label)).toContain('Importar Ciclo');
    expect(filtered.map(i => i.label)).toContain('Publicações');
    expect(filtered.map(i => i.label)).toContain('Histórico');
    expect(filtered.map(i => i.label)).toContain('Preços praticados');
    expect(filtered.map(i => i.label)).not.toContain('Detalhes do Ciclo');
  });

  it('deve exibir apenas Histórico e Preços praticados para usuário com role View_report', () => {
    currentUserProfileSignal.set({
      oid: '2',
      nome: 'View Report User',
      email: 'view@test.com',
      grupos: ['View_report'],
    });
    const filtered = component.filteredMenuItems;
    expect(filtered.map(i => i.label)).toContain('Histórico');
    expect(filtered.map(i => i.label)).toContain('Preços praticados');
    expect(filtered.map(i => i.label)).not.toContain('Importar Ciclo');
    expect(filtered.map(i => i.label)).not.toContain('Publicações');
  });

  it('deve exibir apenas Histórico para usuário com role View_candidate', () => {
    currentUserProfileSignal.set({
      oid: '3',
      nome: 'View Candidate User',
      email: 'candidate@test.com',
      grupos: ['View_candidate'],
    });
    const filtered = component.filteredMenuItems;
    expect(filtered.map(i => i.label)).toContain('Histórico');
    expect(filtered.map(i => i.label)).not.toContain('Preços praticados');
    expect(filtered.map(i => i.label)).not.toContain('Importar Ciclo');
    expect(filtered.map(i => i.label)).not.toContain('Publicações');
  });

  it('não deve exibir Histórico para usuário sem as roles necessárias', () => {
    currentUserProfileSignal.set({
      oid: '4',
      nome: 'No Access User',
      email: 'noaccess@test.com',
      grupos: [],
    });
    const filtered = component.filteredMenuItems;
    expect(filtered.map(i => i.label)).not.toContain('Histórico');
    expect(filtered.map(i => i.label)).not.toContain('Preços praticados');
  });

  it('should return empty menu if user is not logged in', () => {
    currentUserProfileSignal.set(null);
    expect(component.filteredMenuItems.length).toBe(0);
  });

  it('should show items without roles', () => {
    // Hack to add an item without roles to a readonly array for testing coverage
    const originalItems = [...component.menuItems];
    (component as any).menuItems = [
      ...originalItems,
      { label: 'Public Item', icon: '', path: '/public' },
    ];

    const filtered = component.filteredMenuItems;
    expect(filtered.map(i => i.label)).toContain('Public Item');

    // Restore
    (component as any).menuItems = originalItems;
  });

  it('should call loadUserProfile on reloadMenu', () => {
    const spy = jest.spyOn(component, 'loadUserProfile');
    component.reloadMenu();
    expect(spy).toHaveBeenCalled();
  });

  it('should clear token and navigate to login on logout', () => {
    const navigateSpy = jest.spyOn(router, 'navigate');
    component.logout();
    expect(authServiceMock.clearToken).toHaveBeenCalled();
    expect(navigateSpy).toHaveBeenCalledWith(['/login']);
  });

  it('should toggle collapsed property', () => {
    expect(component.collapsed).toBe(true);
    component.collapsed = false;
    expect(component.collapsed).toBe(false);
  });

  describe('userName', () => {
    it('deve retornar o nome do perfil do usuário', () => {
      expect(component.userName).toBe('Test Mock');
    });

    it('deve retornar string vazia quando o perfil não existe', () => {
      currentUserProfileSignal.set(null as any);

      expect(component.userName).toBe('');
    });
  });

  describe('userInitials', () => {
    it('deve retornar string vazia quando o nome é vazio', () => {
      currentUserProfileSignal.set({
        oid: '1',
        nome: '',
        email: 'test@test.com',
        grupos: [],
      });

      expect(component.userInitials).toBe('');
    });

    it('deve retornar a inicial do primeiro nome quando há apenas um nome', () => {
      currentUserProfileSignal.set({
        oid: '1',
        nome: 'teste',
        email: 'test@test.com',
        grupos: [],
      });

      expect(component.userInitials).toBe('T');
    });

    it('deve retornar as iniciais do primeiro e último nome', () => {
      currentUserProfileSignal.set({
        oid: '1',
        nome: 'mock usuário',
        email: 'test@test.com',
        grupos: [],
      });

      expect(component.userInitials).toBe('MU');
    });

    it('deve retornar as iniciais do primeiro e último nome em nomes compostos', () => {
      currentUserProfileSignal.set({
        oid: '1',
        nome: 'Maria Jose Santos Silva',
        email: 'test@test.com',
        grupos: [],
      });

      expect(component.userInitials).toBe('MS');
    });
  });
});
