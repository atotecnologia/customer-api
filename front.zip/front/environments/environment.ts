export const environment = {
  NG_BASE_BFF_URL: process.env['NG_BASE_BFF_URL'],
  NG_BASE_URL: process.env['NG_BASE_URL'],
  NG_PRODUCTION: process.env['NG_PRODUCTION'] === 'true',
  NG_LOCAL_AUTH_BYPASS: process.env['NG_LOCAL_AUTH_BYPASS'] === 'true',
  NG_AUTH_TENANT_ID: process.env['NG_AUTH_TENANT_ID'],
  NG_AUTH_CLIENT_ID: process.env['NG_AUTH_CLIENT_ID'],
  NG_AUTH_API_CLIENT_ID: process.env['NG_AUTH_API_CLIENT_ID'],
  // Intervalo (ms) do polling de status de publicação enquanto há publicação EM_PUBLICACAO.
  // Padrão: 15s (15000ms).
  pollingPublicacaoStatusMs: Number(process.env['NG_POLLING_PUBLICACAO_STATUS_MS']) || 15000,

  // Intervalo (ms) do polling de status quando não há publicação em andamento (cadência ociosa).
  // Padrão: 60s (60000ms).
  pollingPublicacaoStatusOciosoMs:
    Number(process.env['NG_POLLING_PUBLICACAO_STATUS_OCIOSO_MS']) || 60000,

  // Intervalo (ms) do polling do diagnóstico de upload (acompanha o processamento assíncrono).
  // Padrão: 3s (3000ms).
  pollingUploadStatusMs: Number(process.env['NG_POLLING_UPLOAD_STATUS_MS']) || 3000,

  endpoints: {
    listagemCiclos: '/api/v1/ciclos/listagem',
    uploadCiclo: '/api/v1/ciclos/upload',
    ciclo_dashboard: '/api/v1/ciclos/dashboard',
    grupoAds: '/api/v1/grupo-ads',
    user: '/api/v1/user',
    diagnosticoImportacao: '/api/v1/ciclos/upload/diagnostico',
    minhasImportacoes: '/api/v1/ciclos/minhasimportacoes',
    importacoes: '/api/v1/ciclos/importacoes',
    publicacaoStatus: '/api/v1/publicacao/status',
    publicacaoPublicar: '/api/v1/publicacao',
    minhasPublicacoes: '/api/v1/publicacao/historico',
    historicoListagem: '/api/v1/publicacao/historico/listagem',
    exportarPublicacao: '/api/v1/publicacao',
    administracaoGrupos: '/api/v1/administracao/grupos',
    administracaoUsuarios: '/api/v1/administracao/usuarios',
    administracaoPermissoes: '/api/v1/administracao/permissoes',
    administracaoPermissoesHistorico: '/api/v1/administracao/permissoes/historico',
  },
};
